package Projek_PBOL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class UbdateDataBooking extends JFrame {

    private JTextField txtBookingId, txtNamaBaru, txtJumlahTiketBaru;
    private JButton btnCari, btnUpdate, btnBack;
    private JTextArea txtDetail;
    private String flightId;
    private int jumlahTiketLama;
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "Delvitri";
    private static final String PASS = "180406";

    public UbdateDataBooking() {
        setTitle("Update Data Booking");
        setSize(500, 450);
        setLocationRelativeTo(null);

        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        Container contentPane = this.getContentPane();

        Color lightBlue = new Color(173, 216, 230);
        Color skyBlue = new Color(135, 206, 250);

        contentPane.setBackground(skyBlue);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelInput = new JPanel(new GridLayout(3, 2, 10, 10));
        panelInput.add(new JLabel("Booking ID:"));
        txtBookingId = new JTextField();
        panelInput.add(txtBookingId);

        panelInput.add(new JLabel("Nama Penumpang Baru:"));
        txtNamaBaru = new JTextField();
        panelInput.add(txtNamaBaru);

        panelInput.add(new JLabel("Jumlah Tiket Baru:"));
        txtJumlahTiketBaru = new JTextField();
        panelInput.add(txtJumlahTiketBaru);

        add(panelInput, BorderLayout.NORTH);

        // Detail booking
        txtDetail = new JTextArea();
        txtDetail.setEditable(false);
        txtDetail.setBackground(Color.LIGHT_GRAY);
        txtDetail.setFont(new Font("Arial", Font.PLAIN, 12));
        add(new JScrollPane(txtDetail), BorderLayout.CENTER);

        // Panel button
        JPanel panelButton = new JPanel();
        btnCari = new JButton("Cari Booking");
        btnUpdate = new JButton("Update Booking");
        btnUpdate.setEnabled(false);
        btnBack = new JButton("Kembali");
        panelButton.add(btnCari);
        panelButton.add(btnUpdate);
        panelButton.add(btnBack);
        add(panelButton, BorderLayout.SOUTH);

        // Event handlers
        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cariBooking();
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateBooking();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private void cariBooking() {
        String bookingId = txtBookingId.getText().trim();
        if (bookingId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan Booking ID terlebih dahulu!");
            return;
        }

        try ( Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

            String sql = "SELECT b.*, f.AIRLINE, f.DEPARTURE, f.DESTINATION, f.HARGA, f.JUMLAH_KURSI "
                    + "FROM BOOKING b JOIN FLIGHT f ON b.FLIGHT_ID = f.FLIGHT_ID "
                    + "WHERE b.BOOKING_ID = ?";

            try ( PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, bookingId);
                try ( ResultSet rs = pstmt.executeQuery()) {

                    if (rs.next()) {
                        flightId = rs.getString("FLIGHT_ID");
                        jumlahTiketLama = rs.getInt("TOTAL_PASSENGERS");

                        String detail = "=== DETAIL BOOKING ===\n"
                                + "Booking ID: " + rs.getString("BOOKING_ID") + "\n"
                                + "No Identitas: " + rs.getString("PASSENGER_IDENTITY") + "\n"
                                + "Flight ID: " + rs.getString("FLIGHT_ID") + "\n"
                                + "Maskapai: " + rs.getString("AIRLINE") + "\n"
                                + "Rute: " + rs.getString("DEPARTURE") + " -> " + rs.getString(
                                        "DESTINATION") + "\n"
                                + "Nama Penumpang: " + rs.getString("PASSENGER_NAME") + "\n"
                                + "Jumlah Penumpang: " + rs.getInt("TOTAL_PASSENGERS") + "\n"
                                + "Total Harga: Rp " + String.format("%,.0f", rs.getDouble(
                                        "TOTAL_PRICE")) + "\n"
                                + "Tanggal Booking: " + rs.getString("BOOKING_DATE");

                        txtDetail.setText(detail);
                        txtNamaBaru.setText(rs.getString("PASSENGER_NAME"));
                        txtJumlahTiketBaru.setText(String.valueOf(jumlahTiketLama));
                        btnUpdate.setEnabled(true);
                    } else {
                        txtDetail.setText("Booking dengan ID '" + bookingId + "' tidak ditemukan!");
                        btnUpdate.setEnabled(false);
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void updateBooking() {
        String bookingId = txtBookingId.getText().trim();
        String namaBaru = txtNamaBaru.getText().trim();
        String jumlahTiketBaruStr = txtJumlahTiketBaru.getText().trim();

        if (namaBaru.isEmpty() || jumlahTiketBaruStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
            return;
        }

        try {
            int jumlahTiketBaru = Integer.parseInt(jumlahTiketBaruStr);

            // Cek ketersediaan kursi
            try ( Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

                String checkSql = "SELECT JUMLAH_KURSI, HARGA FROM FLIGHT WHERE FLIGHT_ID = ?";
                try ( PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                    checkStmt.setString(1, flightId);
                    try ( ResultSet rs = checkStmt.executeQuery()) {

                        if (rs.next()) {
                            int availableSeats = rs.getInt("JUMLAH_KURSI");
                            double price = rs.getDouble("HARGA");
                            int selisihKursi = jumlahTiketBaru - jumlahTiketLama;

                            if (availableSeats < selisihKursi) {
                                JOptionPane.showMessageDialog(this,
                                        "Kursi tidak cukup!\n"
                                        + "Kursi tersedia: " + availableSeats + "\n"
                                        + "Kursi dibutuhkan: " + selisihKursi);
                                return;
                            }

                            double totalHargaBaru = price * jumlahTiketBaru;

                            int confirm = JOptionPane.showConfirmDialog(this,
                                    "Konfirmasi Update Booking:\n"
                                    + "Nama: " + namaBaru + "\n"
                                    + "Jumlah Tiket: " + jumlahTiketBaru + "\n"
                                    + "Total Harga Baru: Rp " + String.format("%,.0f", totalHargaBaru) + "\n\n"
                                    + "Apakah Anda yakin ingin mengupdate?",
                                    "Konfirmasi Update",
                                    JOptionPane.YES_NO_OPTION);

                            if (confirm == JOptionPane.YES_OPTION) {
                                conn.setAutoCommit(false);

                                String updateBookingSql = "UPDATE BOOKING SET PASSENGER_NAME = ?, TOTAL_PASSENGERS = ?,"
                                        + " TOTAL_PRICE = ? WHERE BOOKING_ID = ?";
                                try ( PreparedStatement updateBookingStmt = conn.prepareStatement(updateBookingSql)) {
                                    updateBookingStmt.setString(1, namaBaru);
                                    updateBookingStmt.setInt(2, jumlahTiketBaru);
                                    updateBookingStmt.setDouble(3, totalHargaBaru);
                                    updateBookingStmt.setString(4, bookingId);
                                    String updateFlightSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI - ? WHERE FLIGHT_ID = ?";
                                    try ( PreparedStatement updateFlightStmt = conn.prepareStatement(updateFlightSql)) {
                                        updateFlightStmt.setInt(1, selisihKursi);
                                        updateFlightStmt.setString(2, flightId);

                                        try {
                                            updateBookingStmt.executeUpdate();
                                            updateFlightStmt.executeUpdate();
                                            conn.commit();
                                            JOptionPane.showMessageDialog(this, "Booking berhasil diupdate!");
                                            jumlahTiketLama = jumlahTiketBaru;
                                            txtDetail.setText(""); // Reset detail
                                            btnUpdate.setEnabled(false);
                                        } catch (SQLException ex) {
                                            conn.rollback();
                                            JOptionPane.showMessageDialog(this, "Error saat transaksi: " + ex.getMessage());
                                            ex.printStackTrace();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Jumlah tiket harus berupa angka!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class UbdateDataBooking extends JFrame {
//    private JTextField txtBookingId, txtNamaBaru, txtJumlahTiketBaru;
//    private JButton btnCari, btnUpdate, btnBack;
//    private JTextArea txtDetail;
//    private String flightId;
//    private int jumlahTiketLama;
//    
//    // KREDENSIAL DB 
//    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
//    private static final String USER = "Delvitri";
//    private static final String PASS = "180406";
//    
//    public UbdateDataBooking() {
//        setTitle("Update Data Booking");
//        setSize(500, 450);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        // Panel input
//        JPanel panelInput = new JPanel(new GridLayout(3, 2, 10, 10));
//        panelInput.add(new JLabel("Booking ID:"));
//        txtBookingId = new JTextField();
//        panelInput.add(txtBookingId);
//        
//        panelInput.add(new JLabel("Nama Penumpang Baru:"));
//        txtNamaBaru = new JTextField();
//        panelInput.add(txtNamaBaru);
//        
//        panelInput.add(new JLabel("Jumlah Tiket Baru:"));
//        txtJumlahTiketBaru = new JTextField();
//        panelInput.add(txtJumlahTiketBaru);
//        
//        add(panelInput, BorderLayout.NORTH);
//        
//        // Detail booking
//        txtDetail = new JTextArea();
//        txtDetail.setEditable(false);
//        txtDetail.setBackground(Color.LIGHT_GRAY);
//        txtDetail.setFont(new Font("Arial", Font.PLAIN, 12));
//        add(new JScrollPane(txtDetail), BorderLayout.CENTER);
//        
//        // Panel button
//        JPanel panelButton = new JPanel();
//        btnCari = new JButton("Cari Booking");
//        btnUpdate = new JButton("Update Booking");
//        btnUpdate.setEnabled(false);
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnCari);
//        panelButton.add(btnUpdate);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Event handlers
//        btnCari.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                cariBooking();
//            }
//        });
//        
//        btnUpdate.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                updateBooking();
//            }
//        });
//        
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // new AdminMenu();  
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    private void cariBooking() {
//        String bookingId = txtBookingId.getText().trim();
//        if (bookingId.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Masukkan Booking ID terlebih dahulu!");
//            return;
//        }
//        
//        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
//            
//            // KOREKSI SQL: Mengganti PRICE -> HARGA dan AVAILABLE_SEATS -> JUMLAH_KURSI
//            String sql = "SELECT b.*, f.AIRLINE, f.DEPARTURE, f.DESTINATION, f.HARGA, f.JUMLAH_KURSI " +
//                         "FROM BOOKING b JOIN FLIGHT f ON b.FLIGHT_ID = f.FLIGHT_ID " +
//                         "WHERE b.BOOKING_ID = ?";
//            
//            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                pstmt.setString(1, bookingId);
//                try (ResultSet rs = pstmt.executeQuery()) {
//                
//                    if (rs.next()) {
//                        // KOREKSI NAMA KOLOM: Semua sudah UPPERCASE (sesuai DESCRIBE)
//                        flightId = rs.getString("FLIGHT_ID"); 
//                        jumlahTiketLama = rs.getInt("TOTAL_PASSENGERS");
//                        
//                        String detail = "=== DETAIL BOOKING ===\n" +
//                            "Booking ID: " + rs.getString("BOOKING_ID") + "\n" +
//                            "No Identitas: " + rs.getString("PASSENGER_IDENTITY") + "\n" + 
//                            "Flight ID: " + rs.getString("FLIGHT_ID") + "\n" +
//                            "Maskapai: " + rs.getString("AIRLINE") + "\n" +
//                            "Rute: " + rs.getString("DEPARTURE") + " -> " + rs.getString("DESTINATION") + "\n" +
//                            "Nama Penumpang: " + rs.getString("PASSENGER_NAME") + "\n" +
//                            "Jumlah Penumpang: " + rs.getInt("TOTAL_PASSENGERS") + "\n" +
//                            "Total Harga: Rp " + String.format("%,.0f", rs.getDouble("TOTAL_PRICE")) + "\n" +
//                            "Tanggal Booking: " + rs.getString("BOOKING_DATE");
//                        
//                        txtDetail.setText(detail);
//                        txtNamaBaru.setText(rs.getString("PASSENGER_NAME"));
//                        txtJumlahTiketBaru.setText(String.valueOf(jumlahTiketLama));
//                        btnUpdate.setEnabled(true);
//                    } else {
//                        txtDetail.setText("Booking dengan ID '" + bookingId + "' tidak ditemukan!");
//                        btnUpdate.setEnabled(false);
//                    }
//                }
//            }
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
//            ex.printStackTrace();
//        }
//    }
//    
//    private void updateBooking() {
//        String bookingId = txtBookingId.getText().trim();
//        String namaBaru = txtNamaBaru.getText().trim();
//        String jumlahTiketBaruStr = txtJumlahTiketBaru.getText().trim();
//        
//        if (namaBaru.isEmpty() || jumlahTiketBaruStr.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
//            return;
//        }
//        
//        try {
//            int jumlahTiketBaru = Integer.parseInt(jumlahTiketBaruStr);
//            
//            // Cek ketersediaan kursi
//            try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
//                
//                // KOREKSI SQL: Mengganti AVAILABLE_SEATS -> JUMLAH_KURSI dan PRICE -> HARGA
//                String checkSql = "SELECT JUMLAH_KURSI, HARGA FROM FLIGHT WHERE FLIGHT_ID = ?";
//                try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
//                    checkStmt.setString(1, flightId);
//                    try (ResultSet rs = checkStmt.executeQuery()) {
//                        
//                        if (rs.next()) {
//                            // KOREKSI NAMA KOLOM: Menggunakan JUMLAH_KURSI dan HARGA
//                            int availableSeats = rs.getInt("JUMLAH_KURSI");
//                            double price = rs.getDouble("HARGA"); 
//                            int selisihKursi = jumlahTiketBaru - jumlahTiketLama;
//                            
//                            if (availableSeats < selisihKursi) {
//                                JOptionPane.showMessageDialog(this,
//                                    "Kursi tidak cukup!\n" +
//                                    "Kursi tersedia: " + availableSeats + "\n" +
//                                    "Kursi dibutuhkan: " + selisihKursi);
//                                return;
//                            }
//                            
//                            double totalHargaBaru = price * jumlahTiketBaru;
//                            
//                            int confirm = JOptionPane.showConfirmDialog(this,
//                                "Konfirmasi Update Booking:\n" +
//                                "Nama: " + namaBaru + "\n" +
//                                "Jumlah Tiket: " + jumlahTiketBaru + "\n" +
//                                "Total Harga Baru: Rp " + String.format("%,.0f", totalHargaBaru) + "\n\n" +
//                                "Apakah Anda yakin ingin mengupdate?",
//                                "Konfirmasi Update",
//                                JOptionPane.YES_NO_OPTION);
//                            
//                            if (confirm == JOptionPane.YES_OPTION) {
//                                
//                                // Mulai Transaksi
//                                conn.setAutoCommit(false);
//                                
//                                // Update booking (Nama kolom di BOOKING sudah benar)
//                                String updateBookingSql = "UPDATE BOOKING SET PASSENGER_NAME = ?, TOTAL_PASSENGERS = ?, TOTAL_PRICE = ? WHERE BOOKING_ID = ?";
//                                try (PreparedStatement updateBookingStmt = conn.prepareStatement(updateBookingSql)) {
//                                    updateBookingStmt.setString(1, namaBaru);
//                                    updateBookingStmt.setInt(2, jumlahTiketBaru);
//                                    updateBookingStmt.setDouble(3, totalHargaBaru);
//                                    updateBookingStmt.setString(4, bookingId);
//                                    
//                                    // Update available seats
//                                    // KOREKSI SQL: Mengganti AVAILABLE_SEATS -> JUMLAH_KURSI
//                                    String updateFlightSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI - ? WHERE FLIGHT_ID = ?";
//                                    try (PreparedStatement updateFlightStmt = conn.prepareStatement(updateFlightSql)) {
//                                        updateFlightStmt.setInt(1, selisihKursi);
//                                        updateFlightStmt.setString(2, flightId);
//                                        
//                                        try {
//                                            updateBookingStmt.executeUpdate();
//                                            updateFlightStmt.executeUpdate();
//                                            conn.commit();
//                                            JOptionPane.showMessageDialog(this, "Booking berhasil diupdate!");
//                                            jumlahTiketLama = jumlahTiketBaru;
//                                            txtDetail.setText(""); // Reset detail
//                                            btnUpdate.setEnabled(false);
//                                        } catch (SQLException ex) {
//                                            conn.rollback();
//                                            JOptionPane.showMessageDialog(this, "Error saat transaksi: " + ex.getMessage());
//                                            ex.printStackTrace();
//                                        } 
//                                    }
//                                } 
//                            }
//                        }
//                    }
//                }
//            }
//        } catch (NumberFormatException ex) {
//            JOptionPane.showMessageDialog(this, "Jumlah tiket harus berupa angka!");
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
//            ex.printStackTrace();
//        }
//    }
//}
