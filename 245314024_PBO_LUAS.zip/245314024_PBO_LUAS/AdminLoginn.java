package Projek_PBOL;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminLoginn extends JFrame {

    JLabel lblTitle, lblUser, lblPas, lbEmail;
    JTextField txtUser, txtEmail;
    JPasswordField txtPas;
    JButton btnLogin, btnBack;

    public AdminLoginn() {
        // === Pengaturan Frame Dasar ===
        setTitle("LOGIN ADMIN TRAVELOKA");
        setSize(500, 300); // Ukuran disesuaikan agar mirip form login pengguna
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Menggunakan BorderLayout sebagai Layout Manager utama
        setLayout(new BorderLayout());

        Color skyBlue = new Color(135, 206, 250); 
        
        JPanel panelLeft = new JPanel();
        panelLeft.setLayout(new GridBagLayout()); // Digunakan untuk menempatkan label di tengah
        panelLeft.setBackground(skyBlue);
        panelLeft.setPreferredSize(new Dimension(180, 0)); // Lebar Tetap
        
        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
         
        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

       
         ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);
        
        lblTitle = new JLabel("LOGIN ADMIN");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));
        panelLeft.add(lblTitle);
        
        add(panelLeft, BorderLayout.WEST);

        JPanel panelRight = new JPanel();
        panelRight.setLayout(new BorderLayout()); 
        panelRight.setBackground(Color.WHITE);
        
        JPanel panelForm = new JPanel(new GridLayout(4, 2, 5, 10)); 
        panelForm.setBorder(BorderFactory.createEmptyBorder(30, 10, 10, 10)); // Padding
        panelForm.setBackground(Color.WHITE);

        // 1. Username
        lblUser = new JLabel("Username:");
        lblUser.setFont(new Font("Arial", Font.PLAIN, 14));
        txtUser = new JTextField();
        txtUser.setPreferredSize(new Dimension(150, 25));
        panelForm.add(lblUser);
        panelForm.add(txtUser);

        // 2. Password
        lblPas = new JLabel("Password:");
        lblPas.setFont(new Font("Arial", Font.PLAIN, 14));
        txtPas = new JPasswordField();
        txtPas.setPreferredSize(new Dimension(150, 25));
        panelForm.add(lblPas);
        panelForm.add(txtPas);

        // 3. Email
        lbEmail = new JLabel("Email:");
        lbEmail.setFont(new Font("Arial", Font.PLAIN, 14));
        txtEmail = new JTextField();
        txtEmail.setPreferredSize(new Dimension(150, 25));
        panelForm.add(lbEmail);
        panelForm.add(txtEmail);
        
        // 4. Baris Kosong (Spacer) agar tidak terlalu ke bawah
        panelForm.add(new JLabel(""));
        panelForm.add(new JLabel("")); 


        // Panel Tombol (di bagian Bawah panelRight)
        JPanel panelButtons = new JPanel(new GridLayout(1, 2, 10, 10));
        panelButtons.setBorder(BorderFactory.createEmptyBorder(0, 10, 20, 10)); 
        panelButtons.setBackground(Color.WHITE);

        btnLogin = new JButton("Login");
        btnBack = new JButton("Kembali");
     
        btnLogin.setPreferredSize(new Dimension(100, 35));
        btnBack.setPreferredSize(new Dimension(100, 35));
        
        panelButtons.add(btnLogin);
        panelButtons.add(btnBack);

        panelRight.add(panelForm, BorderLayout.CENTER);
        panelRight.add(panelButtons, BorderLayout.SOUTH);
        
        add(panelRight, BorderLayout.CENTER); // Tambahkan panelRight ke frame utama
        
         btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginAdmin();
            }
        });
    

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Travelokaa();
                dispose();
            }
        });

        // Pastikan JFrame terlihat
        setVisible(true);
    }
    
  
    private void loginAdmin() {
        String username = txtUser.getText().trim();
        String password = String.valueOf(txtPas.getPassword()).trim();
        String email = txtEmail.getText().trim();


        if (username.isEmpty() || password.isEmpty() || email.isEmpty()){
            JOptionPane.showMessageDialog(this, "Username, Password & Email harus diisi!");
            return;
        }
         if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")) {
             JOptionPane.showMessageDialog(this,
                         "Format email tidak valid!\nContoh: nama@gmail.com");
             return;
         }

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // untuk koneksi ke database
            conn = DriverManager.getConnection(
                         "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );
            // untuk memasukan user dan pasword 
            String sql = "SELECT * FROM ADMIN WHERE USERNAME = ? AND PASSWORD = ? AND Email = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, email);

            rs = pst.executeQuery();
// ketika login berhasil
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login berhasil!");
                new AdminMenu();
                dispose();
            } else {
                // jika login admin salah
                JOptionPane.showMessageDialog(this,
                         "Login gagal! Username, Password atau Email salah!\n\n");

            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                         "Error database: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class AdminLoginn extends JFrame {
//
//    private static final int FRAME_WIDIH = 400;
//    private static final int FRAME_HEIGHT = 250;
//    private static final int FRAME_X_ORIGINAL = 150;
//    private static final int FRAME_Y_ORIGINAL = 250;
//    JLabel lblTitle, lblUser, lblPas, lbEmail;
//    JTextField txtUser, txtEmail;
//    JPasswordField txtPas;
//    JButton btnLogin, btnBack;
//
//    public AdminLoginn() {
//        // untuk memberi nama pada jendela GUI dan ukuuran pada jendela GUI
//        setTitle("LOGIN ADMIN TRAVELOKA");
//        setSize(FRAME_WIDIH, FRAME_HEIGHT);
//        setLocationRelativeTo(null);
//
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new GridLayout(5, 2, 10, 10));
//
//        JPanel panelTitle = new JPanel();
//        lblTitle = new JLabel("Masukkan Username, Password, Email");
//        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
//        lblTitle.setFont(new Font("Arial", Font.BOLD, 14));
//        add(lblTitle);
//        add(panelTitle, BorderLayout.NORTH);
//
//        lblUser = new JLabel("Username:");
//        txtUser = new JTextField();
//        add(lblUser);
//        add(txtUser);
//
//        lblPas = new JLabel("Password:");
//
//        // masukin pasword tidak kelihatan
//        txtPas = new JPasswordField();
//        add(lblPas);
//        add(txtPas);
//        
//        lbEmail = new JLabel("Email:");
//        txtEmail = new JTextField();
//        add(lbEmail );
//        add(txtEmail);
//
//        btnLogin = new JButton("Login");
//        btnBack = new JButton("Kembali");
//
//        // dignakan untuk menampilkan setelah menekan tombol login dan back
//        add(btnLogin);
//        add(btnBack);
//
//        // GAMBAR UNTUK FRAME ICONNYA APLIKASI
//        ImageIcon logo = new ImageIcon(getClass().getResource("images/orang.jpeg"));
//        setIconImage(logo.getImage());
//
//        // gambar menjadi bagian di GUI
//        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
//         ImageIcon logologo = new ImageIcon(getClass().getResource("images/orang.jpeg"));
//        JLabel labelGambar = new JLabel(logo);
//        labelGambar.setHorizontalAlignment(JLabel.CENTER);
//        panelCenter.add(labelGambar, BorderLayout.CENTER);
//
//        // untuk login di bawah 
//        JPanel panelForm = new JPanel(new GridLayout(2, 2, 10, 10));
//
//        // === TOMBOL LOGIN ===
//        btnLogin.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                loginAdmin();
//            }
//        });
//
//        // === TOMBOL KEMBALI ===
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new Travelokaa();
//                dispose();
//            }
//        });
//
//        setVisible(true);
//
//    }
//// untuk memasukan yuser dan pasword berupa hurup dan angka.
//
//    private void loginAdmin() {
//        String username = txtUser.getText().trim();
//        String password = String.valueOf(txtPas.getPassword()).trim();
//        String email = txtEmail.getText().trim();
//
//
//        if (username.isEmpty() || password.isEmpty() || email.isEmpty()){
//            JOptionPane.showMessageDialog(this, "Username, Password & Email harus diisi!");
//            return;
//        }
//         if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")) {
//            JOptionPane.showMessageDialog(this,
//                    "Format email tidak valid!\nContoh: nama@gmail.com");
//            return;
//        }
//
//        Connection conn = null;
//        PreparedStatement pst = null;
//        ResultSet rs = null;
//
//        try {
//            // untuk koneksi ke database
//            conn = DriverManager.getConnection(
//                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            // untuk memasukan user dan pasword 
//            String sql = "SELECT * FROM ADMIN WHERE USERNAME = ? AND PASSWORD = ? AND Email = ?";
//            pst = conn.prepareStatement(sql);
//            pst.setString(1, username);
//            pst.setString(2, password);
//            pst.setString(3, email);
//
//            rs = pst.executeQuery();
//// ketika login berhasil
//            if (rs.next()) {
//                JOptionPane.showMessageDialog(this, "Login berhasil!");
//                new AdminMenu();
//                dispose();
//            } else {
//                // jika login admin salah
//                JOptionPane.showMessageDialog(this,
//                        "Login gagal! Username, Password atau Email salah!\n\n");
////                   + "Gunakan:\n" +
////                    "Username: Delvitri\n" + "Password: 180406"
//
//            }
//
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this,
//                    "Error database: " + ex.getMessage());
//            ex.printStackTrace();
//        } finally {
//            try {
//                if (rs != null) {
//                    rs.close();
//                }
//                if (pst != null) {
//                    pst.close();
//                }
//                if (conn != null) {
//                    conn.close();
//                }
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//        }
//    }
//}
