package Projek_PBOL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class HapusBooking extends JFrame {
    private JTextField txtBookingId;
    private JButton btnCari, btnHapus, btnBack;
    private JTextArea txtDetail;

    private String tempFlightId = null;
    private int tempTotalPassengers = 0;

    public HapusBooking() {
        setTitle("Hapus Data Booking (Pembatalan Pesanan)");
        setSize(500, 350);
        setLocationRelativeTo(null);

        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        Container contentPane = this.getContentPane();
        Color lightBlue = new Color(173, 216, 230);

        Color skyBlue = new Color(135, 206, 250);

        contentPane.setBackground(skyBlue);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel Input
        JPanel panelInput = new JPanel(new GridLayout(1, 3, 10, 10));
        txtBookingId = new JTextField();
        btnCari = new JButton("Cari Booking");
        panelInput.add(new JLabel("Booking ID:"));
        panelInput.add(txtBookingId);
        panelInput.add(btnCari);

        // Text Area Detail
        txtDetail = new JTextArea();
        txtDetail.setEditable(false);
        txtDetail.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(txtDetail);

        // Panel Button
        JPanel panelButton = new JPanel();
        btnHapus = new JButton("Hapus Booking");
        btnBack = new JButton("Kembali");
        btnHapus.setEnabled(false);
        panelButton.add(btnHapus);
        panelButton.add(btnBack);

        // Layout Utama
        add(panelInput, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelButton, BorderLayout.SOUTH);

        // Event handlers
        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cariBooking();
            }
        });

        btnHapus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                hapusBooking();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private void cariBooking() {
        String bookingId = txtBookingId.getText().trim();
        txtDetail.setText("");
        btnHapus.setEnabled(false);
        this.tempFlightId = null;
        this.tempTotalPassengers = 0; // Reset data sementara

        if (bookingId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Booking ID harus diisi!");
            return;
        }

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            // Baris 137: Nama tabel dan kolom harus UPPERCASE
            String sql = "SELECT b.*, f.AIRLINE FROM BOOKING b "
                    + "JOIN FLIGHT f ON b.FLIGHT_ID = f.FLIGHT_ID "
                    + "WHERE b.BOOKING_ID = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, bookingId);
            rs = pst.executeQuery();

            if (rs.next()) {
 
                String flightId = rs.getString("flight_id");
                int totalPassengers = rs.getInt("total_passengers");

                this.tempFlightId = flightId;
                this.tempTotalPassengers = totalPassengers;

                String detail = String.format(
                        "--- Detail Booking ---\n"
                        + "ID Booking: %s\n"
                        + "ID fligh: %s\n"
                        + "Maskapai: %s\n"
                        + "Nama Penumpang: %s\n"
                        + "Jumlah Penumpang: %d\n"
                        + "Total Bayar: Rp %,.2f\n",
                        rs.getString("booking_id"),
                        flightId,
                        rs.getString("airline"),
                        rs.getString("passenger_name"),
                        totalPassengers,
                        rs.getDouble("total_price")
                );
                txtDetail.setText(detail);
                btnHapus.setEnabled(true);
            } else {
                txtDetail.setText("Data booking dengan ID " + bookingId + " tidak ditemukan.");
                JOptionPane.showMessageDialog(this, "Booking ID tidak ditemukan!");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            // Tutup koneksi
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void hapusBooking() {

        if (this.tempFlightId == null || this.tempTotalPassengers == 0) {
            JOptionPane.showMessageDialog(this, "Silahkan cari data booking terlebih dahulu!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Apakah Anda yakin ingin membatalkan pesanan (Booking ID: " + txtBookingId.getText() + ")?",
                "Konfirmasi Pembatalan", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );
            conn.setAutoCommit(false);

            String updateSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI + ? WHERE FLIGHT_ID = ?";
            PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql);

            pstmtUpdate.setInt(1, this.tempTotalPassengers);
            pstmtUpdate.setString(2, this.tempFlightId);
            pstmtUpdate.executeUpdate();

            String deleteSql = "DELETE FROM booking WHERE booking_id = ?";
            PreparedStatement pstmtDelete = conn.prepareStatement(deleteSql);
            pstmtDelete.setString(1, txtBookingId.getText());
            int result = pstmtDelete.executeUpdate();

            if (result > 0) {
                conn.commit();
                JOptionPane.showMessageDialog(this, "Booking berhasil dibatalkan dan "
                        + this.tempTotalPassengers + " kursi dikembalikan.");

                // Reset form dan data sementara
                txtBookingId.setText("");
                txtDetail.setText("");
                btnHapus.setEnabled(false);
                this.tempFlightId = null;
                this.tempTotalPassengers = 0;
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(this, "Gagal menghapus data booking (Mungkin ID"
                        + " tidak ditemukan).");
            }

            pstmtUpdate.close();
            pstmtDelete.close();

        } catch (SQLException ex) {

            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this,
                    "Error database selama transaksi: " + ex.getMessage() + "\nTransaksi Dibatalkan (Rollback).");
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}

//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class HapusBooking extends JFrame {
//
//    private JTextField txtBookingId;
//    private JButton btnCari, btnHapus, btnBack;
//    private JTextArea txtDetail;
//    
//    // 🔥 ATRIBUT KELAS untuk menyimpan data booking sementara
//    private String tempFlightId = null;
//    private int tempTotalPassengers = 0;
//
//    public HapusBooking() {
//        setTitle("Hapus Data Booking (Pembatalan Pesanan)");
//        setSize(500, 350);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout(10, 10));
//
//        // Panel Input
//        JPanel panelInput = new JPanel(new GridLayout(1, 3, 10, 10));
//        txtBookingId = new JTextField();
//        btnCari = new JButton("Cari Booking");
//        panelInput.add(new JLabel("Booking ID:"));
//        panelInput.add(txtBookingId);
//        panelInput.add(btnCari);
//
//        // Text Area Detail
//        txtDetail = new JTextArea();
//        txtDetail.setEditable(false);
//        txtDetail.setFont(new Font("Monospaced", Font.PLAIN, 12));
//        JScrollPane scrollPane = new JScrollPane(txtDetail);
//
//        // Panel Button
//        JPanel panelButton = new JPanel();
//        btnHapus = new JButton("Hapus Booking");
//        btnBack = new JButton("Kembali");
//        btnHapus.setEnabled(false); // Nonaktifkan tombol hapus di awal
//        panelButton.add(btnHapus);
//        panelButton.add(btnBack);
//
//        // Layout Utama
//        add(panelInput, BorderLayout.NORTH);
//        add(scrollPane, BorderLayout.CENTER);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Event handlers
//        btnCari.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                cariBooking();
//            }
//        });
//        
//        btnHapus.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                hapusBooking();
//            }
//        });
//        
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new AdminMenu();
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//
//    private void cariBooking() {
//        String bookingId = txtBookingId.getText().trim();
//        txtDetail.setText("");
//        btnHapus.setEnabled(false);
//        this.tempFlightId = null; 
//        this.tempTotalPassengers = 0; // Reset data sementara
//        
//        if (bookingId.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Booking ID harus diisi!");
//            return;
//        }
//
//        Connection conn = null;
//        PreparedStatement pst = null;
//        ResultSet rs = null;
//
//        try {
//            conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//
//          // Baris 137: Nama tabel dan kolom harus UPPERCASE
//String sql = "SELECT b.*, f.AIRLINE FROM BOOKING b " +
//             "JOIN FLIGHT f ON b.FLIGHT_ID = f.FLIGHT_ID " +
//             "WHERE b.BOOKING_ID = ?";
//            pst = conn.prepareStatement(sql);
//            pst.setString(1, bookingId);
//            rs = pst.executeQuery();
//
//            if (rs.next()) {
//                // Ambil data yang akan disimpan ke atribut kelas
//                String flightId = rs.getString("flight_id");
//                int totalPassengers = rs.getInt("total_passengers");
//                
//                // 🔥 SIMPAN DATA KE ATRIBUT KELAS
//                this.tempFlightId = flightId;
//                this.tempTotalPassengers = totalPassengers;
//
//                // Tampilkan detail di JTextArea
//                String detail = String.format(
//                    "--- Detail Booking ---\n" +
//                    "ID Booking: %s\n" +
//                    "ID fligh: %s\n" +
//                    "Maskapai: %s\n" +
//                    "Nama Penumpang: %s\n" +
//                    "Jumlah Penumpang: %d\n" +
//                    "Total Bayar: Rp %,.2f\n",
//                    rs.getString("booking_id"),
//                    flightId,
//                    rs.getString("airline"),
//                    rs.getString("passenger_name"),
//                    totalPassengers,
//                    rs.getDouble("total_price")
//                );
//                txtDetail.setText(detail);
//                btnHapus.setEnabled(true);
//            } else {
//                txtDetail.setText("Data booking dengan ID " + bookingId + " tidak ditemukan.");
//                JOptionPane.showMessageDialog(this, "Booking ID tidak ditemukan!");
//            }
//
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
//            ex.printStackTrace();
//        } finally {
//            // Tutup koneksi
//            try {
//                if (rs != null) rs.close();
//                if (pst != null) pst.close();
//                if (conn != null) conn.close();
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//        }
//    }
//
//    private void hapusBooking() {
//        // Cek apakah data sudah dicari dan disimpan
//        if (this.tempFlightId == null || this.tempTotalPassengers == 0) {
//            JOptionPane.showMessageDialog(this, "Silahkan cari data booking terlebih dahulu!");
//            return;
//        }
//        
//        int confirm = JOptionPane.showConfirmDialog(this, 
//            "Apakah Anda yakin ingin membatalkan pesanan (Booking ID: " + txtBookingId.getText() + ")?",
//            "Konfirmasi Pembatalan", JOptionPane.YES_NO_OPTION);
//
//        if (confirm != JOptionPane.YES_OPTION) {
//            return;
//        }
//
//        Connection conn = null;
//        try {
//            conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            conn.setAutoCommit(false); // Mulai Transaksi
//
//            // 1. UPDATE jumlah kursi di tabel flight (mengembalikan kursi)
//          // 1. UPDATE jumlah kursi di tabel flight (mengembalikan kursi)
//// Ubah available_seats menjadi JUMLAH_KURSI (asumsi nama kolom Anda)
//String updateSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI + ? WHERE FLIGHT_ID = ?";
//            PreparedStatement pstmtUpdate = conn.prepareStatement(updateSql);
//            
//            // 🔥 Menggunakan atribut kelas yang sudah disimpan
//            pstmtUpdate.setInt(1, this.tempTotalPassengers); 
//            pstmtUpdate.setString(2, this.tempFlightId);
//            pstmtUpdate.executeUpdate();
//
//            // 2. Hapus data booking
//            String deleteSql = "DELETE FROM booking WHERE booking_id = ?";
//            PreparedStatement pstmtDelete = conn.prepareStatement(deleteSql);
//            pstmtDelete.setString(1, txtBookingId.getText());
//            int result = pstmtDelete.executeUpdate();
//
//            if (result > 0) {
//                conn.commit(); // Commit Transaksi
//                JOptionPane.showMessageDialog(this, "Booking berhasil dibatalkan dan " 
//                    + this.tempTotalPassengers + " kursi dikembalikan.");
//                
//                // Reset form dan data sementara
//                txtBookingId.setText("");
//                txtDetail.setText("");
//                btnHapus.setEnabled(false);
//                this.tempFlightId = null;
//                this.tempTotalPassengers = 0;
//            } else {
//                conn.rollback();
//                JOptionPane.showMessageDialog(this, "Gagal menghapus data booking (Mungkin ID tidak ditemukan).");
//            }
//            
//            pstmtUpdate.close();
//            pstmtDelete.close();
//
//        } catch (SQLException ex) {
//            // Rollback jika ada kesalahan
//            if (conn != null) {
//                try {
//                    conn.rollback();
//                } catch (SQLException rollbackEx) {
//                    rollbackEx.printStackTrace();
//                }
//            }
//            JOptionPane.showMessageDialog(this, 
//                "Error database selama transaksi: " + ex.getMessage() + "\nTransaksi Dibatalkan (Rollback).");
//            ex.printStackTrace();
//        } finally {
//            // Tutup koneksi
//            try {
//                if (conn != null) conn.close();
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//        }
//    }
//}
