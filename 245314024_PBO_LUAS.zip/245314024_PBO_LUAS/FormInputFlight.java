package Projek_PBOL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class FormInputFlight extends JFrame {

    private JTextField txtFlightId, txtAirline, txtDeparture, txtDestination,
            txtTanggalBerangkat, txtWaktuBerangkat,
            txtTanggalTiba, txtWaktuTiba,
            txtPrice, txtSeats;
    private JButton btnSubmit, btnBack;

    public FormInputFlight() {
        setTitle("Input Data Penerbangan");
        setSize(500, 600);
        setLocationRelativeTo(null);
        // GAMBAR UNTUK FRAME ICONNYA APLIKASI
        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        Container contentPane = this.getContentPane();

        Color lightBlue = new Color(173, 216, 230);

        Color skyBlue = new Color(135, 206, 250);

        contentPane.setBackground(skyBlue);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout(10, 10));

        JLabel lblTitle = new JLabel("Input Data Penerbangan");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));

        JPanel panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelTitle.setBackground(new Color(240, 240, 240)); // Warna yang netral
        panelTitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panelTitle.add(lblTitle);
        add(panelTitle, BorderLayout.NORTH);

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBackground(Color.WHITE);
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtFlightId = new JTextField(15);
        txtAirline = new JTextField(15);
        txtDeparture = new JTextField(15);
        txtDestination = new JTextField(15);
        txtTanggalBerangkat = new JTextField(15);
        txtWaktuBerangkat = new JTextField(15);
        txtTanggalTiba = new JTextField(15);
        txtWaktuTiba = new JTextField(15);
        txtPrice = new JTextField(15);
        txtSeats = new JTextField(15);

        int row = 0;
        row = addFormField(panelForm, gbc, row, "Flight ID:", txtFlightId);
        row = addFormField(panelForm, gbc, row, "Maskapai:", txtAirline);
        row = addFormField(panelForm, gbc, row, "Keberangkatan:", txtDeparture);
        row = addFormField(panelForm, gbc, row, "Tujuan:", txtDestination);
        row = addFormField(panelForm, gbc, row, "Tanggal Berangkat (YYYY-MM-DD):", txtTanggalBerangkat);
        row = addFormField(panelForm, gbc, row, "Waktu Berangkat (HH:MI):", txtWaktuBerangkat);
        row = addFormField(panelForm, gbc, row, "Tanggal Tiba (YYYY-MM-DD):", txtTanggalTiba);
        row = addFormField(panelForm, gbc, row, "Waktu Tiba (HH:MI):", txtWaktuTiba);
        row = addFormField(panelForm, gbc, row, "Harga:", txtPrice);
        row = addFormField(panelForm, gbc, row, "Kapasitas Penumpang:", txtSeats);
        add(panelForm, BorderLayout.CENTER);

        JPanel panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 15));
        panelButton.setBackground(new Color(240, 240, 240)); 

        btnSubmit = new JButton("Simpan");
        btnBack = new JButton("Kembali");

        panelButton.add(btnSubmit);
        panelButton.add(btnBack);

        add(panelButton, BorderLayout.SOUTH);

        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simpanFlight();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private int addFormField(JPanel panel, GridBagConstraints gbc, int row, String labelText, JComponent field) {

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel(labelText), gbc);

        // Kolom 1: Text Field (Memanjang Horizontal)
        gbc.gridx = 1;
        gbc.gridy = row;
        gbc.weightx = 1.0; // Field memanjang mengisi sisa ruang
        gbc.anchor = GridBagConstraints.WEST; // Rata Kiri
        panel.add(field, gbc);

        return row + 1; // Pindah ke baris berikutnya
    }

    private void simpanFlight() {
        try {

            String flightId = txtFlightId.getText();
            String airline = txtAirline.getText();
            String departure = txtDeparture.getText();
            String destination = txtDestination.getText();
            String tanggalBerangkat = txtTanggalBerangkat.getText();
            String waktuBerangkat = txtWaktuBerangkat.getText();
            String tanggalTiba = txtTanggalTiba.getText();
            String waktuTiba = txtWaktuTiba.getText();

            String hargaInput = txtPrice.getText().replace(".", "").replace(",", ".");
            double price = Double.parseDouble(hargaInput);
            int seats = Integer.parseInt(txtSeats.getText());

            if (flightId.isEmpty() || airline.isEmpty() || departure.isEmpty()
                    || destination.isEmpty() || tanggalBerangkat.isEmpty() || waktuBerangkat.isEmpty()
                    || tanggalTiba.isEmpty() || waktuTiba.isEmpty() || txtPrice.getText().isEmpty()
                    || txtSeats.getText().isEmpty()) {

                JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
                return;
            }

            if (!tanggalBerangkat.matches("\\d{4}-\\d{2}-\\d{2}") || !tanggalTiba.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Format tanggal harus YYYY-MM-DD (contoh: 2024-01-15)");
                return;
            }

            //  waktu (HH:MI)
            if (!waktuBerangkat.matches("\\d{2}:\\d{2}") || !waktuTiba.matches("\\d{2}:\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Format waktu harus HH:MI (contoh: 14:30)");
                return;
            }

            Connection conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            String sql = "INSERT INTO flight (FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, "
                    + "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, "
                    + "HARGA, JUMLAH_KURSI) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, flightId);
            pstmt.setString(2, airline);
            pstmt.setString(3, departure);
            pstmt.setString(4, destination);
            pstmt.setString(5, tanggalBerangkat);
            pstmt.setString(6, waktuBerangkat);
            pstmt.setString(7, tanggalTiba);
            pstmt.setString(8, waktuTiba);
            pstmt.setDouble(9, price);
            pstmt.setInt(10, seats);

            int result = pstmt.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Data penerbangan berhasil ditambahkan!");
                simpanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menambahkan data penerbangan!");
            }

            pstmt.close();
            conn.close();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Harga dan jumlah kursi harus berupa angka!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void simpanForm() {
        txtFlightId.setText("");
        txtAirline.setText("");
        txtDeparture.setText("");
        txtDestination.setText("");
        txtTanggalBerangkat.setText("");
        txtWaktuBerangkat.setText("");
        txtTanggalTiba.setText("");
        txtWaktuTiba.setText("");
        txtPrice.setText("");
        txtSeats.setText("");
    }
}

//
//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class FormInputFlight extends JFrame {
//
//    private JTextField txtFlightId, txtAirline, txtDeparture, txtDestination,
//            txtTanggalBerangkat, txtWaktuBerangkat, // Pisah tanggal & waktu
//            txtTanggalTiba, txtWaktuTiba, // Pisah tanggal & waktu  
//            txtPrice, txtSeats;
//    private JButton btnSubmit, btnBack;
//
//    public FormInputFlight() {
//        setTitle("Input Data Penerbangan");
//        setSize(400, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new GridLayout(11, 2, 10, 10)); // Row ditambah
//
//        // Komponen form
//        add(new JLabel("Flight ID:"));
//        txtFlightId = new JTextField();
//        add(txtFlightId);
//
//        add(new JLabel("Maskapai:"));
//        txtAirline = new JTextField();
//        add(txtAirline);
//
//        add(new JLabel("Keberangkatan:"));
//        txtDeparture = new JTextField();
//        add(txtDeparture);
//
//        add(new JLabel("Tujuan:"));
//        txtDestination = new JTextField();
//        add(txtDestination);
//
//        // TAMBAH INI - Tanggal & Waktu Berangkat
//        add(new JLabel("Tanggal Berangkat (YYYY-MM-DD):"));
//        txtTanggalBerangkat = new JTextField();
//        add(txtTanggalBerangkat);
//
//        add(new JLabel("Waktu Berangkat (HH:MI):"));
//        txtWaktuBerangkat = new JTextField();
//        add(txtWaktuBerangkat);
//
//        // TAMBAH INI - Tanggal & Waktu Tiba  
//        add(new JLabel("Tanggal Tiba (YYYY-MM-DD):"));
//        txtTanggalTiba = new JTextField();
//        add(txtTanggalTiba);
//
//        add(new JLabel("Waktu Tiba (HH:MI):"));
//        txtWaktuTiba = new JTextField();
//        add(txtWaktuTiba);
//
//        add(new JLabel("Harga:"));
//        txtPrice = new JTextField();
//        add(txtPrice);
//
//        add(new JLabel("kapasitas penumpang:"));
//        txtSeats = new JTextField();
//        add(txtSeats);
//
//        btnSubmit = new JButton("Simpan");
//        btnBack = new JButton("Kembali");
//
//        add(btnSubmit);
//        add(btnBack);
//
//        // Event handlers
//        btnSubmit.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                simpanFlight();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new AdminMenu();
//                dispose();
//            }
//        });
//
//        setVisible(true);
//    }
//
//   private void simpanFlight() {
//    try {
//        // --- 1. Ambil & Konversi Input ---
//        String flightId = txtFlightId.getText();
//        String airline = txtAirline.getText();
//        String departure = txtDeparture.getText();
//        String destination = txtDestination.getText();
//        String tanggalBerangkat = txtTanggalBerangkat.getText();
//        String waktuBerangkat = txtWaktuBerangkat.getText();
//        String tanggalTiba = txtTanggalTiba.getText();
//        String waktuTiba = txtWaktuTiba.getText();
//        
//        // Pembersihan input harga dan konversi
//        String hargaInput = txtPrice.getText().replace(".", "").replace(",", ".");
//        double price = Double.parseDouble(hargaInput);
//        int seats = Integer.parseInt(txtSeats.getText());
//
//        // --- 2. Validasi Input ---
//        if (flightId.isEmpty() || airline.isEmpty() || departure.isEmpty()
//                || destination.isEmpty() || tanggalBerangkat.isEmpty() || waktuBerangkat.isEmpty()
//                || tanggalTiba.isEmpty() || waktuTiba.isEmpty() || txtPrice.getText().isEmpty()
//                || txtSeats.getText().isEmpty()) {
//
//            JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
//            return;
//        }
//
//        // Validasi format tanggal (YYYY-MM-DD)
//        if (!tanggalBerangkat.matches("\\d{4}-\\d{2}-\\d{2}") || !tanggalTiba.matches("\\d{4}-\\d{2}-\\d{2}")) {
//            JOptionPane.showMessageDialog(this, "Format tanggal harus YYYY-MM-DD (contoh: 2024-01-15)");
//            return;
//        }
//
//        // Validasi format waktu (HH:MI)
//        if (!waktuBerangkat.matches("\\d{2}:\\d{2}") || !waktuTiba.matches("\\d{2}:\\d{2}")) {
//            JOptionPane.showMessageDialog(this, "Format waktu harus HH:MI (contoh: 14:30)");
//            return;
//        }
//
//        // --- 3. Koneksi dan Eksekusi SQL ---
//        Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//        );
//String sql = "INSERT INTO flight (FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, "
//                   + "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, "
//                   + "HARGA, JUMLAH_KURSI) " // <-- NAMA KOLOM DIPERBAIKI
//                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//
//        PreparedStatement pstmt = conn.prepareStatement(sql);
//        pstmt.setString(1, flightId);
//        pstmt.setString(2, airline);
//        pstmt.setString(3, departure);
//        pstmt.setString(4, destination);
//        pstmt.setString(5, tanggalBerangkat);
//        pstmt.setString(6, waktuBerangkat);
//        pstmt.setString(7, tanggalTiba);
//        pstmt.setString(8, waktuTiba);
//        pstmt.setDouble(9, price);
//        pstmt.setInt(10, seats);
//
//        int result = pstmt.executeUpdate(); // Eksekusi INSERT
//
//        // 🔥 Bagian yang Anda minta (Pengecekan Hasil) 🔥
//        if (result > 0) {
//            JOptionPane.showMessageDialog(this, "Data penerbangan berhasil ditambahkan!");
//            simpanForm();  // Membersihkan form
//        } else {
//            JOptionPane.showMessageDialog(this, "Gagal menambahkan data penerbangan!");
//        }
//
//        pstmt.close();
//        conn.close();
//
//    } catch (NumberFormatException ex) {
//        JOptionPane.showMessageDialog(this, "Harga dan jumlah kursi harus berupa angka!");
//    } catch (SQLException ex) {
//        JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
//        ex.printStackTrace();
//    }
//}
//
//    private void simpanForm() {
//        txtFlightId.setText("");
//        txtAirline.setText("");
//        txtDeparture.setText("");
//        txtDestination.setText("");
//        txtTanggalBerangkat.setText("");
//        txtWaktuBerangkat.setText("");
//        txtTanggalTiba.setText("");
//        txtWaktuTiba.setText("");
//        txtPrice.setText("");
//        txtSeats.setText("");
//    }
//}
