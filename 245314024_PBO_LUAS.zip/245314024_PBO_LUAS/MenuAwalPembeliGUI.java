package Projek_PBOL.images.projec_PBOL.pengguna;

import Projek_PBOL.Travelokaa;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MenuAwalPembeliGUI extends JFrame {
    private JMenuItem JMInputData, JMLihatFlight, JMPesanTiket, JMLihatBooking, JMBack;
    private JTextArea area;
    private JLabel labelGambar = new JLabel("SELAMAT DATANG DI MENU PENGGUNA", SwingConstants.CENTER); 

    public MenuAwalPembeliGUI() {
        setTitle("=== MENU PENGGUNA TRAVELOKA ===");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();
        JMenu menuData = new JMenu("MENU PEMBELI");

        JMInputData = new JMenuItem("Input Data Diri");
        JMLihatFlight = new JMenuItem("Lihat Jadwal Penerbangan");
        JMPesanTiket = new JMenuItem("Pesan Tiket");
        JMLihatBooking = new JMenuItem("Lihat Booking Saya");
        JMBack = new JMenuItem("Kembali ke Menu Utama");

        menuData.add(JMInputData);
        menuData.add(JMLihatFlight);
        menuData.add(JMPesanTiket);
        menuData.add(JMLihatBooking);
        menuData.addSeparator();
        menuData.add(JMBack);

        menuBar.add(menuData);
        setJMenuBar(menuBar);

        labelGambar.setFont(new Font("Arial", Font.BOLD, 18)); 

        try {

            ImageIcon biru = new ImageIcon(getClass().getResource("menupembeli.jpeg")); 
            
            ImageIcon logonya = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logonya);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        add(labelGambar, BorderLayout.CENTER);

            if (biru != null && biru.getImageLoadStatus() == MediaTracker.COMPLETE) {
                labelGambar = new JLabel(biru);
            } else {
                System.err.println("Gagal memuat gambar resource, menggunakan pesan teks.");
            }
        } catch (Exception e) {
            System.err.println("Exception saat memuat gambar: " + e.getMessage());
        }
        
        labelGambar.setHorizontalAlignment(JLabel.CENTER); 
        add(labelGambar, BorderLayout.CENTER);
       
        JMInputData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new inputDataDiri();
               //setVisible(false);
            }
        });
        
        // 2. LIHAT JADWAL PENERBANGAN
        JMLihatFlight.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                 new jadwalPenerbangan();
            }
        });
        
        // 3. PESAN TIKET
        JMPesanTiket.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (!Session.isLoggedIn()) { 
                    JOptionPane.showMessageDialog(null,
                        "Anda harus mengisi DATA DIRI dulu sebelum bisa memesan tiket!",
                        "Peringatan",
                        JOptionPane.WARNING_MESSAGE);
                    return; 
                }
                new pesanTiketGUI(); 
                dispose();
            }
        });

        JMLihatBooking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LihatBookingPembeliGUI(); 
                dispose();
            }
        });
        JMBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Travelokaa();
                dispose();
            }
        });
        
        setVisible(true);
    }
}
///package Projek_PBOL.images.projec_PBOL.pengguna;
//
//import Projek_PBOL.Travelokaa;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//
//public class MenuAwalPembeliGUI extends JFrame {
//    private JMenuItem JMInputData, JMLihatFlight, JMPesanTiket, JMLihatBooking, JMBack;
//    private JTextArea area;
//
//    public MenuAwalPembeliGUI() {
//        setTitle("=== MENU PENGGUNA TRAVELOKA ===");
//        setSize(700, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        
//        // Menu bar
//        JMenuBar menuBar = new JMenuBar();
//        JMenu menuData = new JMenu("MENU PEMBELI");
//
//        JMInputData = new JMenuItem("Input Data Diri");
//        JMLihatFlight = new JMenuItem("Lihat Jadwal Penerbangan");
//        JMPesanTiket = new JMenuItem("Pesan Tiket");
//        JMLihatBooking = new JMenuItem("Lihat Booking Saya");
//        JMBack = new JMenuItem("Kembali ke Menu Utama");
//
//        menuData.add(JMInputData);
//        menuData.add(JMLihatFlight);
//        menuData.add(JMPesanTiket);
//        menuData.add(JMLihatBooking);
//        menuData.addSeparator();
//        menuData.add(JMBack);
//
//        menuBar.add(menuData);
//        setJMenuBar(menuBar);
//
//        // area
//        area = new JTextArea("Selamat datang di Traveloka!\n\nSilakan pilih menu pada bar di atas.");
//        area.setEditable(false);
//        area.setFont(new Font("Arial", Font.PLAIN, 16));
//        add(new JScrollPane(area), BorderLayout.CENTER);
//       
//        // ======================= ACTION LISTENER =======================
//        
//        // 1. INPUT DATA DIRI
//        JMInputData.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new inputDataDiri();
//                dispose();
//            }
//        });
//        
//        // 2. LIHAT JADWAL PENERBANGAN
//        JMLihatFlight.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new jadwalPenerbangan();
//                // Tidak perlu dispose() agar menu tetap terbuka
//            }
//        });
//        
//        // 3. PESAN TIKET
//JMPesanTiket.addActionListener(new ActionListener() {
//    public void actionPerformed(ActionEvent e) {
//
//        // CEK APAKAH USER SUDAH INPUT DATA DIRI
//        if (!Session.isLoggedIn()) {
//            JOptionPane.showMessageDialog(null,
//                "Anda harus mengisi DATA DIRI dulu sebelum bisa memesan tiket!",
//                "Peringatan",
//                JOptionPane.WARNING_MESSAGE);
//            return; // Jangan lanjut
//        }
//
//        // Jika data diri SUDAH ada
//        new pesanTiketGUI();
//        dispose();
//    }
//});
//
//        
//        // 4. LIHAT BOOKING SAYA
//        JMLihatBooking.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new LihatBookingPembeliGUI();
//                dispose();
//            }
//        });
//        
//        // 5. KEMBALI KE MENU UTAMA
//        JMBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new Travelokaa();
//                dispose();
//            }
//        });
//        // ==============================================================
//        
//        setVisible(true);
//    }
//}