package Projek_PBOL.images.projec_PBOL.pengguna;

import Projek_PBOL.AdminMenu;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.*;

public class LihatBookingPembeliGUI extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnBack, btnRefresh;

    public LihatBookingPembeliGUI() {
        if (!Session.isLoggedIn()) {
            JOptionPane.showMessageDialog(null, "Anda harus LOGIN terlebih dahulu!",
                    "Akses Ditolak", JOptionPane.WARNING_MESSAGE);
            // new loginPengguna(); 
            dispose();
            return;
        }
         ImageIcon logo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);
        Container contentPane = this.getContentPane();

        Color lightBlue = new Color(173, 216, 230);
        Color skyBlue = new Color(135, 206, 250);

        contentPane.setBackground(skyBlue);

        setLayout(new GridLayout(7, 2, 10, 10));
        setTitle("Lihat Booking Saya");
        setSize(1300, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] columnNames = {
            "Booking ID",
            "No Identitas",
            "Nama Penumpang",
            "Email Pembeli",
            "No Telepon",
            "Kode Flight",
            "Tujuan",
            "Tgl Berangkat",
            "Waktu Berangkat",
            "Tgl Tiba",
            "Waktu Tiba",
            "Jumlah Tiket",
            "Total Pembayaran",
            "Tanggal Booking"
        };
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBottom = new JPanel(new FlowLayout());
        btnRefresh = new JButton("Refresh Data");
        btnBack = new JButton("Kembali");
        panelBottom.add(btnRefresh);
        panelBottom.add(btnBack);
        add(panelBottom, BorderLayout.SOUTH);

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MenuAwalPembeliGUI();
                dispose();
            }
        });

        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadBookingData();
            }
        });
        loadBookingData();

        setVisible(true);
    }

    // METHOD UNTUK MENGAMBIL NO_IDENTITAS DARI DB
    private String getNoIdentitasDariDB(String idPengguna) {
        String noIdentitas = null;
        try ( Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
            String sql = "SELECT NO_IDENTITAS FROM PEMBELI WHERE ID_PENGGUNA = ?";
            try ( PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, idPengguna);
                try ( ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        noIdentitas = rs.getString("NO_IDENTITAS");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error DB saat mengambil identitas: " + e.getMessage());
            e.printStackTrace();
        }
        return noIdentitas;
    }

    // METHOD UNTUK DATA BOOKING (14 KOLOM)
    private void loadBookingData() {
        tableModel.setRowCount(0);

        String idPengguna = Session.getUserID();
        if (idPengguna == null) {
            return;
        }

        String noIdentitasAktif = getNoIdentitasDariDB(idPengguna);
        if (noIdentitasAktif == null) {
            JOptionPane.showMessageDialog(this, "Data pembeli tidak ditemukan! "
                    + "Harap lengkapi data diri di menu Data Diri.");
            return;
        }

        try ( Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {

            String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, P.EMAIL_PEMBELI, "
                    + "P.NO_TELP, B.FLIGHT_ID, "
                    + "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, "
                    + "F.DESTINATION, F.TANGGAL_BERANGKAT, F.WAKTU_BERANGKAT, F.TANGGAL_TIBA, F.WAKTU_TIBA "
                    + "FROM BOOKING B "
                    + "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID "
                    + "JOIN PEMBELI P ON B.PASSENGER_IDENTITY = P.NO_IDENTITAS "
                    + "WHERE B.PASSENGER_IDENTITY = ? "
                    + "ORDER BY B.BOOKING_DATE DESC";

            try ( PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, noIdentitasAktif);

                try ( ResultSet rs = pstmt.executeQuery()) {

                    // Format Rupiah
                    DecimalFormatSymbols symbols = new DecimalFormatSymbols();
                    symbols.setGroupingSeparator('.');
                    symbols.setDecimalSeparator(',');
                    DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);

                    int rowCount = 0;
                    while (rs.next()) {

                        String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
                        String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
                        String tglTiba = rs.getString("TANGGAL_TIBA");
                        String waktuTiba = rs.getString("WAKTU_TIBA");
                        String bookingDateStr = rs.getString("BOOKING_DATE");

                        Object[] row = new Object[]{
                            rs.getString("BOOKING_ID"),
                            rs.getString("PASSENGER_IDENTITY"),
                            rs.getString("PASSENGER_NAME"),
                            rs.getString("EMAIL_PEMBELI"),
                            rs.getString("NO_TELP"),
                            rs.getString("FLIGHT_ID"),
                            rs.getString("DESTINATION"),
                            tglBerangkat,
                            waktuBerangkat,
                            tglTiba,
                            waktuTiba,
                            rs.getInt("TOTAL_PASSENGERS"),
                            formatter.format(rs.getDouble("TOTAL_PRICE")),
                            bookingDateStr
                        };
                        tableModel.addRow(row);
                        rowCount++;
                    }

                    if (rowCount == 0) {
                        JOptionPane.showMessageDialog(this, "Anda belum memiliki"
                                + " riwayat booking.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

//// KODE YANG SUDAH ANDA KOREKSI SUDAH TEPAT UNTUK LIHATBOOKINGPEMBELIGUI
//package Projek_PBOL.images.projec_PBOL.pengguna;
//
//import Projek_PBOL.images.projec_PBOL.pengguna.Session;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.sql.*;
//import java.text.DecimalFormat;
//import java.text.DecimalFormatSymbols;
//
//public class LihatBookingPembeliGUI extends JFrame {
//    
//    // ... (Atribut dan inisialisasi GUI tetap sama) ...
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JButton btnBack, btnRefresh;
//
//    public LihatBookingPembeliGUI() {
//        if (!Session.isLoggedIn()) {
//            JOptionPane.showMessageDialog(null, "Anda harus LOGIN terlebih dahulu!", "Akses Ditolak", JOptionPane.WARNING_MESSAGE);
//            // new loginPengguna(); 
//            dispose();
//            return;
//        }
//
//        setTitle("Lihat Booking Saya");
//        setSize(1300, 500); 
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        // DEFINISI KOLOM (TOTAL 14 KOLOM)
//        String[] columnNames = {
//            "Booking ID", 
//            "No Identitas", 
//            "Nama Penumpang", 
//            "Email Pembeli", 
//            "No Telepon", 
//            "Kode Flight", 
//            "Tujuan", 
//            "Tgl Berangkat", 
//            "Waktu Berangkat", 
//            "Tgl Tiba", 
//            "Waktu Tiba", 
//            "Jumlah Tiket", 
//            "Total Pembayaran", 
//            "Tanggal Booking" 
//        };
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//        
//        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); 
//
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//
//        JPanel panelBottom = new JPanel(new FlowLayout());
//        btnRefresh = new JButton("Refresh Data");
//        btnBack = new JButton("Kembali");
//        panelBottom.add(btnRefresh);
//        panelBottom.add(btnBack);
//        add(panelBottom, BorderLayout.SOUTH);
//
//        btnBack.addActionListener(e -> {
//            // new MenuAwalPembeliGUI(); 
//            dispose();
//        });
//        
//        btnRefresh.addActionListener(e -> loadBookingData());
//
//        loadBookingData();
//
//        setVisible(true);
//    }
//    
//    // METHOD UNTUK MENGAMBIL NO_IDENTITAS DARI DB
//    private String getNoIdentitasDariDB(String idPengguna) {
//        String noIdentitas = null;
//        try (Connection conn = DriverManager.getConnection(
//            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//            String sql = "SELECT NO_IDENTITAS FROM PEMBELI WHERE ID_PENGGUNA = ?"; 
//            try (PreparedStatement pst = conn.prepareStatement(sql)) {
//                pst.setString(1, idPengguna);
//                try (ResultSet rs = pst.executeQuery()) {
//                    if (rs.next()) {
//                        noIdentitas = rs.getString("NO_IDENTITAS");
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(this, "Error DB saat mengambil identitas: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return noIdentitas;
//    }
//
//
//    // METHOD UNTUK MEMUAT DATA BOOKING (14 KOLOM)
//    private void loadBookingData() {
//        tableModel.setRowCount(0);
//
//        String idPengguna = Session.getUserID();
//        if (idPengguna == null) return; 
//
//        String noIdentitasAktif = getNoIdentitasDariDB(idPengguna);
//        if (noIdentitasAktif == null) {
//            JOptionPane.showMessageDialog(this, "Data pembeli tidak ditemukan! Harap lengkapi data diri di menu Data Diri.");
//            return;
//        }
//
//        try (Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//            
//            // QUERY SQL: Mengambil 14 kolom. JOIN dengan PEMBELI menggunakan NO_IDENTITAS
//            // Kolom P.EMAIL_PEMBELI dan P.NO_TELP sudah dikoreksi agar sesuai dengan asumsi PEMBELI
//            String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, P.EMAIL_PEMBELI, P.NO_TELP, B.FLIGHT_ID, " +
//                         "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, " +
//                         "F.DESTINATION, F.TANGGAL_BERANGKAT, F.WAKTU_BERANGKAT, F.TANGGAL_TIBA, F.WAKTU_TIBA " +
//                         "FROM BOOKING B " +
//                         "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID " +
//                         "JOIN PEMBELI P ON B.PASSENGER_IDENTITY = P.NO_IDENTITAS " + 
//                         "WHERE B.PASSENGER_IDENTITY = ? " +
//                         "ORDER BY B.BOOKING_DATE DESC";
//
//            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                pstmt.setString(1, noIdentitasAktif);
//
//                try (ResultSet rs = pstmt.executeQuery()) {
//
//                    // Format Rupiah
//                    DecimalFormatSymbols symbols = new DecimalFormatSymbols();
//                    symbols.setGroupingSeparator('.');
//                    symbols.setDecimalSeparator(',');
//                    DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);
//
//                    int rowCount = 0;
//                    while (rs.next()) {
//                        
//                        String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
//                        String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
//                        String tglTiba = rs.getString("TANGGAL_TIBA");
//                        String waktuTiba = rs.getString("WAKTU_TIBA");
//                        String bookingDateStr = rs.getString("BOOKING_DATE");
//
//                        // Memasukkan 14 data ke dalam row (HARUS SAMA DENGAN columnNames)
//                        Object[] row = new Object[]{
//                            rs.getString("BOOKING_ID"),
//                            rs.getString("PASSENGER_IDENTITY"), 
//                            rs.getString("PASSENGER_NAME"),
//                            rs.getString("EMAIL_PEMBELI"),
//                            rs.getString("NO_TELP"), 
//                            rs.getString("FLIGHT_ID"),
//                            rs.getString("DESTINATION"),
//                            tglBerangkat, 
//                            waktuBerangkat,
//                            tglTiba,
//                            waktuTiba,
//                            rs.getInt("TOTAL_PASSENGERS"),
//                            formatter.format(rs.getDouble("TOTAL_PRICE")),
//                            bookingDateStr
//                        };
//                        tableModel.addRow(row);
//                        rowCount++;
//                    }
//
//                    if (rowCount == 0) {
//                        JOptionPane.showMessageDialog(this, "Anda belum memiliki riwayat booking.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}
