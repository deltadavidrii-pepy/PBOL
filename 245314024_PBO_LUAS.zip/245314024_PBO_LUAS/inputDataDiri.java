
package Projek_PBOL.images.projec_PBOL.pengguna;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class inputDataDiri extends JFrame {
    private JTextField txtNama, txtNoIdentitas, txtAlamat, txtNoHP, txtEmail;
    private JComboBox<String> comboJenisKelamin;
    private JButton btnSimpan, btnBack;
    

    public inputDataDiri() {
        setTitle("Input Data Diri Pembeli");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        ImageIcon logo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);
        
        Container contentPane = this.getContentPane();

        
       Color skyBlue = new Color(135, 206, 250);
        contentPane.setBackground(skyBlue);

        setLayout(new BorderLayout(10, 10));
       JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10)); 
    inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    inputPanel.setBackground(skyBlue);
    add(inputPanel, BorderLayout.CENTER);
    
       inputPanel.add(new JLabel("Nama Lengkap:"));
        txtNama = new JTextField();
        inputPanel.add(txtNama);

       inputPanel.add(new JLabel("Nomor Identitas:"));
        txtNoIdentitas = new JTextField();
        inputPanel.add(txtNoIdentitas);

      inputPanel.add(new JLabel("Jenis Kelamin:"));
        comboJenisKelamin = new JComboBox<>(new String[]{"Laki-laki", "Perempuan"});
        inputPanel.add(comboJenisKelamin);

       inputPanel.add(new JLabel("Alamat:"));
        txtAlamat = new JTextField();
        inputPanel.add(txtAlamat);
        
       inputPanel.add(new JLabel("No HP:"));
        txtNoHP = new JTextField();
        inputPanel.add(txtNoHP);

        inputPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        inputPanel.add(txtEmail);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 3));
        add(inputPanel, BorderLayout.CENTER);

        btnSimpan = new JButton("Simpan Data");
        btnBack = new JButton("Kembali");
buttonPanel.add(btnSimpan);
        buttonPanel.add( btnBack);
        
        add(buttonPanel, BorderLayout.SOUTH);
        tampilkanDataLama(); 

        // Event handlers
       btnSimpan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                simpanDataDiri();
            }
        });
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Di sini bisa memanggil MenuAwalPembeliGUI()
                new MenuAwalPembeliGUI();
                dispose(); // Atau tutup jendela
            }
        });

        setVisible(true);
    }

private void tampilkanDataLama() {
    String idPengguna = Session.getUserID();
    if (idPengguna == null) return;

    try (Connection conn = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {

        String sqlPembeli = "SELECT NO_IDENTITAS, NAMA, ALAMAT, JENIS_KELAMIN, NO_TELP, EMAIL_PEMBELI " + 
                            "FROM PEMBELI WHERE ID_PENGGUNA = ?";
        
        try (PreparedStatement pst = conn.prepareStatement(sqlPembeli)) {
            pst.setString(1, idPengguna);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    txtNama.setText(rs.getString("NAMA")); 
                    txtNoIdentitas.setText(rs.getString("NO_IDENTITAS"));
                    txtAlamat.setText(rs.getString("ALAMAT"));
                    txtNoHP.setText(rs.getString("NO_TELP")); 
                    txtEmail.setText(rs.getString("EMAIL_PEMBELI")); 
                    
                    String jk = rs.getString("JENIS_KELAMIN");
                    if (jk != null && jk.equalsIgnoreCase("Perempuan")) {
                        comboJenisKelamin.setSelectedItem("Perempuan");
                    } else {
                        comboJenisKelamin.setSelectedItem("Laki-laki");
                    }
                }
            }
        }
    } catch (SQLException ex) {
        System.err.println("Error memuat data lama: " + ex.getMessage());
        JOptionPane.showMessageDialog(this, 
            "Gagal memuat data diri: ORA-00904: " + ex.getMessage(), 
            "SQL Error PEMBELI", 
            JOptionPane.ERROR_MESSAGE);
    }
}
private void simpanDataDiri() {
    Connection conn = null;
    try {
        String nama = txtNama.getText().trim();
        String noIdentitas = txtNoIdentitas.getText().trim();
        String noHP = txtNoHP.getText().trim();
        String emailPembeli = txtEmail.getText().trim();
        String alamat = txtAlamat.getText().trim();
        String jenisKelamin = (String) comboJenisKelamin.getSelectedItem();
        
        String idPengguna = Session.getUserID();
            
        // Validasi wajib
        if (nama.isEmpty() || noIdentitas.isEmpty() || noHP.isEmpty() || alamat.isEmpty() || emailPembeli.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi!", 
                    "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (idPengguna == null) {
            JOptionPane.showMessageDialog(this, "Sesi pengguna tidak ditemukan.", "Error", 
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406");
        conn.setAutoCommit(false);
        String updatePenggunaSql = "UPDATE PENGGUNA SET NAME = ?, NO_TELEPON = ?, EMAIL = ? WHERE ID = ?";
        try (PreparedStatement updateStmt = conn.prepareStatement(updatePenggunaSql)) {
            updateStmt.setString(1, nama);       
            updateStmt.setString(2, noHP);         
            updateStmt.setString(3, emailPembeli); 
            updateStmt.setString(4, idPengguna);
            updateStmt.executeUpdate();
        }
        String checkSql = "SELECT COUNT(*) FROM PEMBELI WHERE ID_PENGGUNA = ?";
        boolean dataExists;
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setString(1, idPengguna);
            try (ResultSet rs = checkStmt.executeQuery()) {
                rs.next();
                dataExists = rs.getInt(1) > 0;
            }
        }
            
        String buyerSql;
        
        if (dataExists) {
            buyerSql = "UPDATE PEMBELI SET NO_IDENTITAS=?, NAMA=?, JENIS_KELAMIN=?, ALAMAT=?, "
                    + ""
                    + "EMAIL_PEMBELI=?, NO_TELP=? WHERE ID_PENGGUNA=?";
        } else {
            buyerSql = "INSERT INTO PEMBELI (NO_IDENTITAS, NAMA, JENIS_KELAMIN, ALAMAT, EMAIL_PEMBELI,"
                    + " NO_TELP, ID_PENGGUNA) VALUES (?, ?, ?, ?, ?, ?, ?)";
        }
            
        try (PreparedStatement buyerStmt = conn.prepareStatement(buyerSql)) {
            buyerStmt.setString(1, noIdentitas);  
            buyerStmt.setString(2, nama);         
            buyerStmt.setString(3, jenisKelamin); 
            buyerStmt.setString(4, alamat);       
            buyerStmt.setString(5, emailPembeli); 
            buyerStmt.setString(6, noHP);         
            buyerStmt.setString(7, idPengguna); 
            buyerStmt.executeUpdate();
        }
            
        conn.commit();
        JOptionPane.showMessageDialog(this, "Data berhasil disimpan dan diperbarui!", 
                "Sukses", JOptionPane.INFORMATION_MESSAGE);
        dispose();
            
    } catch (SQLException ex) {
        try {
            if (conn != null) conn.rollback(); 
        } catch (SQLException e) { 
        }
            
        String errorMessage = "Error Database (Simpan Data): " + ex.getMessage();
        JOptionPane.showMessageDialog(this, errorMessage, "SQL Error", 
                JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    } finally {
        // 5. Tutup koneksi
        try {
            if (conn != null) conn.close(); 
        } catch (SQLException e) {
        }
    }
}
}

//
//
//package Projek_PBOL.images.projec_PBOL.pengguna;
//
//import Projek_PBOL.images.projec_PBOL.pengguna.Session;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class inputDataDiri extends JFrame {
//    private JTextField txtNama, txtNoIdentitas, txtAlamat, txtNoHP, txtEmail;
//    private JComboBox<String> comboJenisKelamin;
//    private JButton btnSimpan, btnBack;
//    
//
//    public inputDataDiri() {
//        setTitle("Input Data Diri Pembeli");
//        setSize(500, 400);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new GridLayout(7, 2, 10, 10));
//
//        // Inisialisasi Komponen GUI (INI TIDAK DIUBAH)
//        add(new JLabel("Nama Lengkap:"));
//        txtNama = new JTextField();
//        add(txtNama);
//
//        add(new JLabel("Nomor Identitas:"));
//        txtNoIdentitas = new JTextField();
//        add(txtNoIdentitas);
//
//        add(new JLabel("Jenis Kelamin:"));
//        comboJenisKelamin = new JComboBox<>(new String[]{"Laki-laki", "Perempuan"});
//        add(comboJenisKelamin);
//
//        add(new JLabel("Alamat:"));
//        txtAlamat = new JTextField();
//        add(txtAlamat);
//
//        add(new JLabel("No HP:"));
//        txtNoHP = new JTextField();
//        add(txtNoHP);
//
//        add(new JLabel("Email:"));
//        txtEmail = new JTextField();
//        add(txtEmail);
//
//        btnSimpan = new JButton("Simpan Data");
//        btnBack = new JButton("Kembali");
//
//        add(btnSimpan);
//        add(btnBack);
//
//        tampilkanDataLama(); // Memuat data lama saat form dibuka
//
//        // Event handlers
//        btnSimpan.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                simpanDataDiri();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new MenuAwalPembeliGUI();
//                
//            }
//        });
//
//        setVisible(true);
//    }
//
//    // ----------------------------------------
//    // --- KOREKSI METHOD tampilkanDataLama() ---
//    // ----------------------------------------
//
//// KOREKSI METHOD tampilkanDataLama()
//private void tampilkanDataLama() {
//    String idPengguna = Session.getUserID();
//    if (idPengguna == null) return;
//
//    try (Connection conn = DriverManager.getConnection(
//        "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//
//        // 🌟 HILANGKAN TANDA KUTIP GANDA PADA SEMUA NAMA KOLOM
//        String sqlPembeli = "SELECT NO_IDENTITAS, NAMA, ALAMAT, JENIS_KELAMIN, NO_TELP, EMAIL_PEMBELI " + 
//                            "FROM PEMBELI WHERE ID_PENGGUNA = ?";
//        
//        try (PreparedStatement pst = conn.prepareStatement(sqlPembeli)) {
//            pst.setString(1, idPengguna);
//            try (ResultSet rs = pst.executeQuery()) {
//                if (rs.next()) {
//                    txtNama.setText(rs.getString("NAMA")); 
//                    txtNoIdentitas.setText(rs.getString("NO_IDENTITAS"));
//                    txtAlamat.setText(rs.getString("ALAMAT"));
//                    txtNoHP.setText(rs.getString("NO_TELP")); 
//                    txtEmail.setText(rs.getString("EMAIL_PEMBELI")); 
//                    
//                    String jk = rs.getString("JENIS_KELAMIN");
//                    if (jk != null && jk.equalsIgnoreCase("Perempuan")) {
//                        comboJenisKelamin.setSelectedItem("Perempuan");
//                    } else {
//                        comboJenisKelamin.setSelectedItem("Laki-laki");
//                    }
//                }
//            }
//        }
//    } catch (SQLException ex) {
//        System.err.println("Error memuat data lama: " + ex.getMessage());
//        JOptionPane.showMessageDialog(this, 
//            "Gagal memuat data diri: ORA-00904: " + ex.getMessage(), 
//            "SQL Error PEMBELI", 
//            JOptionPane.ERROR_MESSAGE);
//    }
//}
//  // KOREKSI LENGKAP METHOD simpanDataDiri()
//private void simpanDataDiri() {
//    Connection conn = null;
//    try {
//        // 1. Ambil data dari form (kolom input)
//        String nama = txtNama.getText().trim();
//        String noIdentitas = txtNoIdentitas.getText().trim();
//        String noHP = txtNoHP.getText().trim();
//        String emailPembeli = txtEmail.getText().trim();
//        String alamat = txtAlamat.getText().trim();
//        String jenisKelamin = (String) comboJenisKelamin.getSelectedItem();
//        
//        // Asumsi Session.getUserID() ada di class ini atau sudah di-import
//        String idPengguna = Session.getUserID();
//            
//        // Validasi wajib
//        if (nama.isEmpty() || noIdentitas.isEmpty() || noHP.isEmpty() || alamat.isEmpty() || emailPembeli.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Semua field harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
//            return;
//        }
//        if (idPengguna == null) {
//            JOptionPane.showMessageDialog(this, "Sesi pengguna tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
//            return;
//        }
//
//        // 2. Koneksi dan Mulai Transaksi
//        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406");
//        conn.setAutoCommit(false); // Memulai transaksi
//
//        // === QUERY 1: UPDATE tabel PENGGUNA ===
//        // Kolom PENGGUNA yang diperbarui: NAME, NO_TELEPON, EMAIL (SEMUA TANPA TANDA KUTIP GANDA)
//        String updatePenggunaSql = "UPDATE PENGGUNA SET NAME = ?, NO_TELEPON = ?, EMAIL = ? WHERE ID = ?";
//        try (PreparedStatement updateStmt = conn.prepareStatement(updatePenggunaSql)) {
//            updateStmt.setString(1, nama);         // Untuk kolom NAME di PENGGUNA
//            updateStmt.setString(2, noHP);         // Untuk kolom NO_TELEPON di PENGGUNA
//            updateStmt.setString(3, emailPembeli); // Untuk kolom EMAIL di PENGGUNA
//            updateStmt.setString(4, idPengguna);
//            updateStmt.executeUpdate();
//        }
//
//        // === QUERY 2: Cek data di tabel PEMBELI (Untuk menentukan INSERT atau UPDATE) ===
//        String checkSql = "SELECT COUNT(*) FROM PEMBELI WHERE ID_PENGGUNA = ?";
//        boolean dataExists;
//        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
//            checkStmt.setString(1, idPengguna);
//            try (ResultSet rs = checkStmt.executeQuery()) {
//                rs.next();
//                dataExists = rs.getInt(1) > 0;
//            }
//        }
//            
//        String buyerSql;
//        // Kolom di PEMBELI: NO_IDENTITAS, NAMA, JENIS_KELAMIN, ALAMAT, EMAIL_PEMBELI, NO_TELP
//        
//        if (dataExists) {
//            // UPDATE PEMBELI (SEMUA TANPA TANDA KUTIP GANDA)
//            buyerSql = "UPDATE PEMBELI SET NO_IDENTITAS=?, NAMA=?, JENIS_KELAMIN=?, ALAMAT=?, EMAIL_PEMBELI=?, NO_TELP=? WHERE ID_PENGGUNA=?";
//        } else {
//            // INSERT PEMBELI (SEMUA TANPA TANDA KUTIP GANDA)
//            buyerSql = "INSERT INTO PEMBELI (NO_IDENTITAS, NAMA, JENIS_KELAMIN, ALAMAT, EMAIL_PEMBELI, NO_TELP, ID_PENGGUNA) VALUES (?, ?, ?, ?, ?, ?, ?)";
//        }
//            
//        try (PreparedStatement buyerStmt = conn.prepareStatement(buyerSql)) {
//            // BINDING SESUAI URUTAN KOLOM PEMBELI
//            buyerStmt.setString(1, noIdentitas);  
//            buyerStmt.setString(2, nama);         
//            buyerStmt.setString(3, jenisKelamin); 
//            buyerStmt.setString(4, alamat);       
//            buyerStmt.setString(5, emailPembeli); 
//            buyerStmt.setString(6, noHP);         
//            buyerStmt.setString(7, idPengguna);   // ID_PENGGUNA (di WHERE/INSERT)
//            
//            buyerStmt.executeUpdate();
//        }
//            
//        // 3. Commit Transaksi
//        conn.commit();
//        JOptionPane.showMessageDialog(this, "Data berhasil disimpan dan diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
//        dispose();
//            
//    } catch (SQLException ex) {
//        // 4. Rollback jika ada error SQL
//        try {
//            if (conn != null) conn.rollback(); 
//        } catch (SQLException e) { /* ignore */ }
//            
//        String errorMessage = "Error Database (Simpan Data): " + ex.getMessage();
//        JOptionPane.showMessageDialog(this, errorMessage, "SQL Error", JOptionPane.ERROR_MESSAGE);
//        ex.printStackTrace();
//    } finally {
//        // 5. Tutup koneksi
//        try {
//            if (conn != null) conn.close(); 
//        } catch (SQLException e) { /* ignore */ }
//    }
//}
//}