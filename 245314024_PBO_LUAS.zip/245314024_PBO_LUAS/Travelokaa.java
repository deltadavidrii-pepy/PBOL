package Projek_PBOL;
import Projek_PBOL.images.projec_PBOL.pengguna.MenuAwalPembeliGUI;
import Projek_PBOL.images.projec_PBOL.pengguna.loginPengguna;
import java.awt.BorderLayout;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Travelokaa extends JFrame {
    public Travelokaa() {

        setTitle(" ============================\t SELAMAT DATA DI TRAVELOKA \t========================================");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        ImageIcon logo = new ImageIcon(getClass().getResource("traveloka.jpeg"));
        setIconImage(logo.getImage());

        ImageIcon logonya = new ImageIcon(getClass().getResource("travelokaGUI.jpeg"));
        JLabel labelGambar = new JLabel(logonya);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        add(labelGambar, BorderLayout.CENTER);

        JPanel panelTombol = new JPanel();
        JLabel labelPilih = new JLabel("Silahkan Pilih Mode: ");
        labelPilih.setFont(new Font("Arial", Font.BOLD, 16));

        JButton tombolAdmin = new JButton("ADMIN");
        JButton tombolUser = new JButton("PENGGUNA/SEBAGAI PEMBELI TIKET");


        tombolAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminLoginn();
                dispose();
            }
        });

        tombolUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new loginPengguna();
                dispose();
            }
        });

        panelTombol.add(labelPilih);
        panelTombol.add(tombolAdmin);
        panelTombol.add(tombolUser);

        add(panelTombol, BorderLayout.SOUTH);

        setVisible(true);

        System.out.println("==DATABASE TRAVELOKA==");
        System.out.println("==========================");

        System.out.println("Mencoba membuat koneksi ke database....");
        Connection conn = getConnection();
        try {
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public Connection getConnection() {
        String host = "localhost";
        String port = "1521";
        String db = "XE";
        String usr = "Delvitri";
        String pwd = "180406";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Maaf, driver class tidak ditemukan!");
            System.out.println(ex.getMessage());
        }

        Connection conn = null;

        try {
            conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@" + host + ":" + port + ":" + db,
                    usr, pwd
            );
        } catch (SQLException ex) {
            System.out.println("Maaf, koneksi tidak berhasil!");
            System.out.println(ex.getMessage());
        }

        if (conn != null) {
            System.out.println("Koneksi ke database berhasil terbentuk");
        } else {
            System.out.println("Maaf, koneksi ke database gagal");
        }

        return conn;
    }

    public static void main(String[] args) {
        new Travelokaa();
    }
}












//        setTitle("Traveloka Tiket");
//        setSize(700, 500);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        JMenuBar menuBar = new JMenuBar();
//        JMenu menuUtama = new JMenu("Menu Utama");
//
//        menuUser = new JMenuItem("Input Data User");
//        menuFlight = new JMenuItem("Input Data Flight");
//        menuBooking = new JMenuItem("Pesan Tiket");
//        menuLihatBooking = new JMenuItem("Lihat Daftar Booking");
//        menuExit = new JMenuItem("Keluar");
//
//        // Tambahkan ke Menu Utama
//        menuUtama.add(menuUser);
//        menuUtama.add(menuFlight);
//        menuUtama.add(menuBooking);
//        menuUtama.add(menuLihatBooking);
//        menuUtama.add(menuExit);
//
//        // Tambahkan Menu Utama ke Menu Bar
//        menuBar.add(menuUtama);
//
//        // Set Menu Bar
//        setJMenuBar(menuBar);
//
//        // Tambahkan Area Teks
//        area = new JTextArea();
//        add(area, BorderLayout.CENTER);
//
//        // Event Handling - Anonymous Class
//        menuUser.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                area.setText("Menu Input Data User terbuka...");
//            }
//        });
//
//        menuFlight.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                area.setText("Menu Input Data Flight terbuka...");
//            }
//        });
//
//        menuBooking.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                area.setText("Menu Pemesanan Tiket terbuka...");
//            }
//        });
//
//        menuLihatBooking.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                area.setText("Menampilkan daftar Booking...");
//            }
//        });
//
//        menuExit.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                System.exit(0);
//            }
//        });
//
//        setVisible(true);
//    }
//    }
