package Projek_PBOL.images.projec_PBOL.pengguna;

public class Session {

    private static String userID = null;

    public static void setUserID(String id) {
        userID = id;
    }

    public static String getUserID() {
        return userID;
    }

    public static boolean isLoggedIn() {
        return userID != null;
    }

    public static void logout() {
        userID = null;
    }
}





