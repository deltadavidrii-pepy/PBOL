package Projek_PBOL.images.projec_PBOL.pengguna;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class pesanTiketGUI extends JFrame {

    // ... (DEKLARASI VARIABEL tetap sama) ...
    private JTextField txtNamaPassenger, txtKodeFlight, txtJumlahTiket, txtTotal;
    private JTextField txtNoIdentitasPenumpang;
    private JButton btnCariFlight, btnHitung, btnKonfirmasi, btnBack, btnReset, btnDetailFlight;

    private double hargaPerTiket = 0;
    private int availableSeats = 0;
    private String kodeFlightTerpilih = null;
    private String tanggalBerangkatTerpilih = null;
    
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "Delvitri";
    private static final String PASS = "180406";
    // ...

    public pesanTiketGUI() {

        String idPengguna = Session.getUserID();
        if (idPengguna == null) {
            
              // GAMBAR UNTUK FRAME ICONNYA APLIKASI
        ImageIcon logo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        setIconImage(logo.getImage());
        
        // GAMBAR UNTUK FRAME ICONNYA APLIKASI
        ImageIcon logonya = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logonya);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        add(labelGambar, BorderLayout.CENTER);
        
            JOptionPane.showMessageDialog(null, "Session kosong! Silakan login ulang.");
            dispose();
            return;
        }

        setTitle("Pesan Tiket Penerbangan (User: " + idPengguna + ")");
        setSize(700, 480); // Ukuran yang lebih lebar untuk layout baru
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // 1. Tentukan Warna Background (Biru Muda)
        Color skyBlue = new Color(135, 206, 250); 
        getContentPane().setBackground(skyBlue);
        setLayout(new BorderLayout(15, 15)); // Menggunakan BorderLayout utama

        // ==========================================================
        // 2. PANEL INPUT (Menggunakan GridBagLayout untuk penempatan rapi)
        // ==========================================================
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(skyBlue);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 10, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5); // Padding
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Data input
        String[] labels = {
            "No Identitas Penumpang:", "Nama Penumpang:", "Kode Flight:", 
            "Jumlah Tiket:", "Total Pembayaran:"
        };
        JComponent[] fields = new JComponent[5];
        
        txtNoIdentitasPenumpang = new JTextField(20);
        txtNamaPassenger = new JTextField(20);
        txtKodeFlight = new JTextField(10);
        txtJumlahTiket = new JTextField(20);
        txtTotal = new JTextField(20);
        txtTotal.setEditable(false);
        txtTotal.setText("-");

        // Kombinasi Kode Flight + Tombol Cari (mirip layout lama)
        JPanel panelKode = new JPanel(new BorderLayout());
        panelKode.setBackground(skyBlue);
        btnCariFlight = new JButton("Cari");
        panelKode.add(txtKodeFlight, BorderLayout.CENTER);
        panelKode.add(btnCariFlight, BorderLayout.EAST);
        
        fields[0] = txtNoIdentitasPenumpang;
        fields[1] = txtNamaPassenger;
        fields[2] = panelKode; // Component spesial
        fields[3] = txtJumlahTiket;
        fields[4] = txtTotal;
        
        // Menambahkan Label dan Field ke inputPanel
        for (int i = 0; i < labels.length; i++) {
            // Label (Kolom 0)
            gbc.gridx = 0;
            gbc.weightx = 0;
            gbc.anchor = GridBagConstraints.WEST;
            inputPanel.add(new JLabel(labels[i]), gbc);

            // Field (Kolom 1)
            gbc.gridx = 1;
            gbc.weightx = 1.0; // Biarkan field mengisi ruang
            inputPanel.add(fields[i], gbc);
        }

        // ==========================================================
        // 3. PANEL TOMBOL (Dikelompokkan di bawah input)
        // ==========================================================
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10)); // FlowLayout untuk tombol
        buttonPanel.setBackground(skyBlue); 
        
        btnDetailFlight = new JButton("Detail Flight");
        btnReset = new JButton("Reset");
        btnHitung = new JButton("Hitung");
        btnKonfirmasi = new JButton("Konfirmasi");
        btnBack = new JButton("Kembali");
        
        buttonPanel.add(btnDetailFlight);
        buttonPanel.add(btnReset);
        buttonPanel.add(btnHitung);
        buttonPanel.add(btnKonfirmasi);
        buttonPanel.add(btnBack);

        // ==========================================================
        // 4. SUSUN FRAME UTAMA
        // ==========================================================
        add(inputPanel, BorderLayout.CENTER); // Panel Input di tengah
        add(buttonPanel, BorderLayout.SOUTH); // Panel Tombol di bawah

        // ==================== EVENT LISTENER ====================
        btnCariFlight.addActionListener(e -> cariFlight());
        btnHitung.addActionListener(e -> hitungTotal());
        btnDetailFlight.addActionListener(e -> showDetailFlightDialog());
        btnReset.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> {
            // Panggil MenuAwalPembeliGUI
            new MenuAwalPembeliGUI(); 
            // Tutup jendela pesanTiketGUI
            dispose(); 
        });
        btnKonfirmasi.addActionListener(e -> konfirmasiPesanan());

        setVisible(true);
    }

    // ==========================================================
    // METHOD: cariFlight()
    // Mengambil data HARGA, JUMLAH_KURSI, dan DETAIL FLIGHT
    // ==========================================================
    private void cariFlight() {
        String kode = txtKodeFlight.getText().trim();
        if (kode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan kode flight!");
            return;
        }

        // Ambil data penting untuk booking (HARGA, JUMLAH_KURSI, TANGGAL_BERANGKAT)
        String sql = "SELECT HARGA, JUMLAH_KURSI, AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT FROM FLIGHT WHERE FLIGHT_ID = ?";

        try ( Connection conn = DriverManager.getConnection(URL, USER, PASS);  PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, kode);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                hargaPerTiket = rs.getDouble("HARGA");
                availableSeats = rs.getInt("JUMLAH_KURSI");

                // >>> SIMPAN DATA PENTING KE VARIABEL CLASS <<<
                kodeFlightTerpilih = kode;
                tanggalBerangkatTerpilih = rs.getString("TANGGAL_BERANGKAT");

                JOptionPane.showMessageDialog(this,
                        "Flight ditemukan:\n"
                        + "Maskapai: " + rs.getString("AIRLINE") + "\n"
                        + "Rute: " + rs.getString("DEPARTURE") + " → " + rs.getString("DESTINATION") + "\n"
                        + "Kursi tersedia: " + availableSeats,
                        "Flight Ditemukan", JOptionPane.INFORMATION_MESSAGE);
            } else {
                hargaPerTiket = 0;
                availableSeats = 0;
                kodeFlightTerpilih = null;
                tanggalBerangkatTerpilih = null;
                JOptionPane.showMessageDialog(this, "Flight tidak ditemukan!");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error DB (cariFlight): " + ex.getMessage());
            hargaPerTiket = 0;
            availableSeats = 0;
            kodeFlightTerpilih = null;
            tanggalBerangkatTerpilih = null;
        }
    }

    // ==========================================================
    // METHOD: hitungTotal() (Tidak ada perubahan)
    // ==========================================================
    private void hitungTotal() {
        if (hargaPerTiket == 0 || availableSeats == 0 || kodeFlightTerpilih == null) {
            JOptionPane.showMessageDialog(this, "Cari flight yang tersedia dulu!");
            return;
        }

        try {
            int jumlah = Integer.parseInt(txtJumlahTiket.getText().trim());

            if (jumlah <= 0) {
                JOptionPane.showMessageDialog(this, "Jumlah tiket harus lebih dari nol!", "Error Input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (jumlah > availableSeats) {
                JOptionPane.showMessageDialog(this, "Maaf, kursi hanya tersedia: " + availableSeats, "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }

            txtTotal.setText("Rp " + String.format("%,.0f", hargaPerTiket * jumlah));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah harus angka!");
        }
    }

    // ==========================================================
    // METHOD: showDetailFlightDialog() (Diperbaiki koneksi dan variabel)
    // ==========================================================
    private void showDetailFlightDialog() {
        String kode = txtKodeFlight.getText().trim();
        if (kode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan kode flight!");
            return;
        }

        String sql = "SELECT FLIGHT_ID, HARGA, JUMLAH_KURSI, AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA "
                + "FROM FLIGHT WHERE FLIGHT_ID = ?";

        try ( Connection conn = DriverManager.getConnection(URL, USER, PASS);  PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, kode);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String detail = "Kode: " + rs.getString("FLIGHT_ID")
                        + "\nMaskapai: " + rs.getString("AIRLINE")
                        + "\nRute: " + rs.getString("DEPARTURE") + " -> " + rs.getString("DESTINATION")
                        + "\nBerangkat: " + rs.getString("TANGGAL_BERANGKAT") + " " + rs.getString("WAKTU_BERANGKAT")
                        + "\nTiba: " + rs.getString("TANGGAL_TIBA") + " " + rs.getString("WAKTU_TIBA")
                        + "\nHarga: Rp " + String.format("%,.0f", rs.getDouble("HARGA"))
                        + "\nKursi Tersedia: " + rs.getInt("JUMLAH_KURSI");
                JOptionPane.showMessageDialog(this, detail, "Detail Flight", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Flight tidak ditemukan.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error DB (showDetail): " + ex.getMessage());
        }
    }

    // ==========================================================
    // METHOD: konfirmasiPesanan() (LOGIKA UTAMA)
    // Menggunakan Transaksi 3 Langkah: Cek Pembeli -> Insert Pembeli -> Insert Booking
    // ==========================================================
    private void konfirmasiPesanan() {
        String noIdentitasInput = txtNoIdentitasPenumpang.getText().trim();
        String nama = txtNamaPassenger.getText().trim();
        String jumlahStr = txtJumlahTiket.getText().trim();
        String totalStr = txtTotal.getText().trim();
        String idPenggunaLogin = Session.getUserID();

        // 1. Validasi Input dan Data Flight
        if (noIdentitasInput.isEmpty() || nama.isEmpty() || kodeFlightTerpilih == null || jumlahStr.isEmpty() || totalStr.equals("-")) {
            JOptionPane.showMessageDialog(this, "Semua data harus diisi, dan Flight harus dicari/dihitung.", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Connection conn = null;
        try {
            int jumlah = Integer.parseInt(jumlahStr);
            double totalHarga = hargaPerTiket * jumlah;
            String bookingId = "BKG" + System.currentTimeMillis();

            // Validasi kursi terakhir
            if (jumlah > availableSeats) {
                JOptionPane.showMessageDialog(this, "Maaf, kursi hanya tersedia: " + availableSeats, "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 2. Koneksi dan Mulai Transaksi
            conn = DriverManager.getConnection(URL, USER, PASS);
            conn.setAutoCommit(false); // Memulai transaksi

            // =======================================================
            // LANGKAH A: CEK DAN INSERT PEMBELI BARU (Untuk mencegah ORA-02292)
            // =======================================================
            String checkSql = "SELECT COUNT(*) FROM PEMBELI WHERE NO_IDENTITAS = ?";
            boolean pembeliExists;
            try ( PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, noIdentitasInput);
                try ( ResultSet rs = checkStmt.executeQuery()) {
                    rs.next();
                    pembeliExists = rs.getInt(1) > 0;
                }
            }

            if (!pembeliExists) {
                // Asumsi: Saat memesan tiket, Pembeli Baru harus terkait dengan ID_PENGGUNA yang sedang login.
                // Kolom PEMBELI: NO_IDENTITAS, NAMA, ID_PENGGUNA. (Kolom lain bisa ditambahkan nanti)
                String insertPembeliSql = "INSERT INTO PEMBELI (NO_IDENTITAS, NAMA, ID_PENGGUNA) VALUES (?, ?, ?)";
                try ( PreparedStatement insertPembeliStmt = conn.prepareStatement(insertPembeliSql)) {
                    insertPembeliStmt.setString(1, noIdentitasInput);
                    insertPembeliStmt.setString(2, nama);
                    insertPembeliStmt.setString(3, idPenggunaLogin); // Penaut ke akun yang login
                    insertPembeliStmt.executeUpdate();
                }
            } else {
                // Opsional: Jika Pembeli sudah ada, kita bisa update namanya jika berbeda
                String updateNamaSql = "UPDATE PEMBELI SET NAMA = ? WHERE NO_IDENTITAS = ?";
                try ( PreparedStatement updateNamaStmt = conn.prepareStatement(updateNamaSql)) {
                    updateNamaStmt.setString(1, nama);
                    updateNamaStmt.setString(2, noIdentitasInput);
                    updateNamaStmt.executeUpdate();
                }
            }

            // =======================================================
            // LANGKAH B: INSERT ke tabel BOOKING
            // =======================================================
            String insertBookingSql = "INSERT INTO BOOKING (BOOKING_ID, PASSENGER_IDENTITY, PASSENGER_NAME, FLIGHT_ID, TOTAL_PASSENGERS, TOTAL_PRICE, BOOKING_DATE) "
                    + "VALUES (?, ?, ?, ?, ?, ?, SYSDATE)";

            try ( PreparedStatement pst = conn.prepareStatement(insertBookingSql)) {
                pst.setString(1, bookingId);
                pst.setString(2, noIdentitasInput);
                pst.setString(3, nama);
                pst.setString(4, kodeFlightTerpilih); // DARI variabel class yang sudah dicari
                pst.setInt(5, jumlah);
                pst.setDouble(6, totalHarga);
                pst.executeUpdate();
            }

            // =======================================================
            // LANGKAH C: UPDATE jumlah kursi di tabel FLIGHT
            // =======================================================
            String updateFlightSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI - ? WHERE FLIGHT_ID = ?";
            try ( PreparedStatement updateFlightStmt = conn.prepareStatement(updateFlightSql)) {
                updateFlightStmt.setInt(1, jumlah);
                updateFlightStmt.setString(2, kodeFlightTerpilih);
                updateFlightStmt.executeUpdate();
            }

            conn.commit(); // Commit transaksi
            availableSeats -= jumlah; // Update status kursi di GUI tanpa refresh
            JOptionPane.showMessageDialog(this, "Booking berhasil!\nID Booking: " + bookingId, "Sukses", JOptionPane.INFORMATION_MESSAGE);

            showCetakTiketDialog(bookingId, kodeFlightTerpilih, nama, noIdentitasInput, jumlah);
            clearForm();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah tiket harus berupa angka.", "Error Input", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            try {
                if (conn != null) {
                    conn.rollback(); // Rollback jika ada error
                }
            } catch (SQLException rollbackEx) {
            }

            JOptionPane.showMessageDialog(this,
                    "Gagal menyimpan booking (Error DB): " + ex.getMessage(),
                    "SQL Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException closeEx) {
            }
        }
    }

    // ==========================================================
    // METHOD: showCetakTiketDialog() (Diperbaiki variabel dinamis)
    // ==========================================================
    private void showCetakTiketDialog(String bookingId, String kodeFlight, String namaPenumpang,
            String noIdentitas, int jumlahTiket) {

        String sql = "SELECT AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, HARGA "
                + "FROM FLIGHT WHERE FLIGHT_ID = ?";

        try ( Connection conn = DriverManager.getConnection(URL, USER, PASS);  PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, kodeFlight);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                String maskapai = rs.getString("AIRLINE");
                String asal = rs.getString("DEPARTURE");
                String tujuan = rs.getString("DESTINATION");
                String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
                String jamBerangkat = rs.getString("WAKTU_BERANGKAT");
                String tglTiba = rs.getString("TANGGAL_TIBA");
                String jamTiba = rs.getString("WAKTU_TIBA");

                // === FORMAT MIRIP GAMBAR DI ATAS ===
                String detailTiket = "====================================\n"
                        + "        E-TICKET RESMI\n"
                        + "====================================\n"
                        + "ID Booking     : " + bookingId + "\n"
                        + "No. Identitas  : " + noIdentitas + "\n"
                        + "Penumpang      : " + namaPenumpang + "\n"
                        + "Jml Tiket      : " + jumlahTiket + "\n"
                        + "====================================\n"
                        + "Kode Flight    : " + kodeFlight + "\n"
                        + "Maskapai       : " + maskapai + "\n"
                        + "Dari (Asal)    : " + asal + "\n"
                        + "Ke (Tujuan)    : " + tujuan + "\n"
                        + "====================================\n"
                        + "Keberangkatan\n"
                        + "Tgl Berangkat  : " + tglBerangkat + "\n"
                        + "Jam Berangkat  : " + jamBerangkat + "\n"
                        + "Kedatangan\n"
                        + "Tgl Tiba       : " + tglTiba + "\n"
                        + "Jam Tiba       : " + jamTiba + "\n"
                        + "====================================\n"
                        + "Simpan ID Booking Anda untuk Check-in.\n";

                JOptionPane.showMessageDialog(this, detailTiket, "Cetak Tiket Anda", JOptionPane.PLAIN_MESSAGE);

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error DB (Cetak Tiket): " + ex.getMessage());
        }
    }

    private void clearForm() {
        txtNoIdentitasPenumpang.setText("");
        txtNamaPassenger.setText("");
        txtKodeFlight.setText("");
        txtJumlahTiket.setText("");
        txtTotal.setText("-");

        // Reset variabel class untuk memastikan harus cari flight lagi
        hargaPerTiket = 0;
        availableSeats = 0;
        kodeFlightTerpilih = null;
        tanggalBerangkatTerpilih = null;
    }
}

//package Projek_PBOL.images.projec_PBOL.pengguna;
//
//import javax.swing.*;
//import java.awt.*;
//import java.sql.*;
//
//public class pesanTiketGUI extends JFrame {
//
//    // ==========================================================
//    // 1. DEKLARASI VARIABEL GUI
//    // ==========================================================
//    private JTextField txtNamaPassenger, txtKodeFlight, txtJumlahTiket, txtTotal;
//    private JTextField txtNoIdentitasPenumpang; 
//    private JButton btnCariFlight, btnHitung, btnKonfirmasi, btnBack, btnReset, btnDetailFlight;
//
//    // ==========================================================
//    // 2. DEKLARASI VARIABEL DATA TRANSAKSI
//    // ==========================================================
//    private double hargaPerTiket = 0;
//    private int availableSeats = 0;
//    private String kodeFlightTerpilih = null;
//    private String tanggalBerangkatTerpilih = null;
//    // Asumsi: Class Session sudah tersedia
//    
//    // Kredensial DB
//    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
//    private static final String USER = "Delvitri";
//    private static final String PASS = "180406";
//
//
//    public pesanTiketGUI() {
//
//        String idPengguna = Session.getUserID();
//        if (idPengguna == null) {
//            JOptionPane.showMessageDialog(null, "Session kosong! Silakan login ulang.");
//            dispose();
//            return;
//        }
//
//        setTitle("Pesan Tiket Penerbangan (User: " + idPengguna + ")");
//        setSize(520, 430);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new GridLayout(7, 2, 10, 10));
//
//        // TAMPILKAN NOMOR IDENTITAS PENUMPANG (INPUT FIELD BARU)
//        add(new JLabel("No Identitas Penumpang:"));
//        txtNoIdentitasPenumpang = new JTextField();
//        add(txtNoIdentitasPenumpang);
//
//        // Nama Penumpang (Asumsi: Untuk No Identitas yang bersangkutan)
//        add(new JLabel("Nama Penumpang:"));
//        txtNamaPassenger = new JTextField();
//        add(txtNamaPassenger);
//
//        // Kode flight
//        add(new JLabel("Kode Flight:"));
//        JPanel panelKode = new JPanel(new BorderLayout());
//        txtKodeFlight = new JTextField();
//        btnCariFlight = new JButton("Cari");
//        panelKode.add(txtKodeFlight, BorderLayout.CENTER);
//        panelKode.add(btnCariFlight, BorderLayout.EAST);
//        add(panelKode);
//
//        // Jumlah tiket
//        add(new JLabel("Jumlah Tiket:"));
//        txtJumlahTiket = new JTextField();
//        add(txtJumlahTiket);
//
//        // Total pembayaran
//        add(new JLabel("Total Pembayaran:"));
//        txtTotal = new JTextField("-");
//        txtTotal.setEditable(false);
//        add(txtTotal);
//
//        // Tombol
//        btnDetailFlight = new JButton("Detail Flight");
//        btnReset = new JButton("Reset");
//        btnHitung = new JButton("Hitung");
//        btnKonfirmasi = new JButton("Konfirmasi");
//        btnBack = new JButton("Kembali");
//
//        add(btnDetailFlight);
//        add(btnReset);
//        add(btnHitung);
//        add(btnKonfirmasi);
//        add(new JLabel(""));
//        add(btnBack); 
//
//        // ==================== EVENT LISTENER ====================
//        btnCariFlight.addActionListener(e -> cariFlight());
//        btnHitung.addActionListener(e -> hitungTotal());
//        btnDetailFlight.addActionListener(e -> showDetailFlightDialog()); 
//        btnReset.addActionListener(e -> clearForm());
//        btnBack.addActionListener(e -> { dispose(); }); 
//        btnKonfirmasi.addActionListener(e -> konfirmasiPesanan());
//
//        setVisible(true);
//    }
//    
//    // ==========================================================
//    // METHOD: cariFlight()
//    // Mengambil data HARGA, JUMLAH_KURSI, dan DETAIL FLIGHT
//    // ==========================================================
//    private void cariFlight() {
//        String kode = txtKodeFlight.getText().trim();
//        if (kode.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Masukkan kode flight!");
//            return;
//        }
//
//        // Ambil data penting untuk booking (HARGA, JUMLAH_KURSI, TANGGAL_BERANGKAT)
//        String sql = "SELECT HARGA, JUMLAH_KURSI, AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT FROM FLIGHT WHERE FLIGHT_ID = ?";
//         
//        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
//             PreparedStatement pst = conn.prepareStatement(sql)) {
//
//            pst.setString(1, kode);
//            ResultSet rs = pst.executeQuery();
//
//            if (rs.next()) {
//                hargaPerTiket = rs.getDouble("HARGA"); 
//                availableSeats = rs.getInt("JUMLAH_KURSI"); 
//                
//                // >>> SIMPAN DATA PENTING KE VARIABEL CLASS <<<
//                kodeFlightTerpilih = kode;
//                tanggalBerangkatTerpilih = rs.getString("TANGGAL_BERANGKAT");
//                
//                JOptionPane.showMessageDialog(this,
//                                "Flight ditemukan:\n" +
//                                "Maskapai: " + rs.getString("AIRLINE") + "\n" + 
//                                "Rute: " + rs.getString("DEPARTURE") + " → " + rs.getString("DESTINATION") + "\n" + 
//                               "Kursi tersedia: " + availableSeats, 
//                                "Flight Ditemukan", JOptionPane.INFORMATION_MESSAGE);
//            } else {
//                hargaPerTiket = 0; 
//                availableSeats = 0; 
//                kodeFlightTerpilih = null;
//                tanggalBerangkatTerpilih = null;
//                JOptionPane.showMessageDialog(this, "Flight tidak ditemukan!");
//            }
//
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error DB (cariFlight): " + ex.getMessage());
//            hargaPerTiket = 0;
//            availableSeats = 0;
//            kodeFlightTerpilih = null;
//            tanggalBerangkatTerpilih = null;
//        }
//    }
//         
//    // ==========================================================
//    // METHOD: hitungTotal() (Tidak ada perubahan)
//    // ==========================================================
//    private void hitungTotal() {
//        if (hargaPerTiket == 0 || availableSeats == 0 || kodeFlightTerpilih == null) {
//            JOptionPane.showMessageDialog(this, "Cari flight yang tersedia dulu!");
//            return;
//        }
//
//        try {
//            int jumlah = Integer.parseInt(txtJumlahTiket.getText().trim());
//            
//            if (jumlah <= 0) {
//                JOptionPane.showMessageDialog(this, "Jumlah tiket harus lebih dari nol!", "Error Input", JOptionPane.ERROR_MESSAGE);
//                return;
//            }
//            if (jumlah > availableSeats) {
//                 JOptionPane.showMessageDialog(this, "Maaf, kursi hanya tersedia: " + availableSeats, "Validasi", JOptionPane.WARNING_MESSAGE);
//                 return;
//            }
//            
//            txtTotal.setText("Rp " + String.format("%,.0f", hargaPerTiket * jumlah));
//        } catch (NumberFormatException e) {
//            JOptionPane.showMessageDialog(this, "Jumlah harus angka!");
//        }
//    }
//
//    // ==========================================================
//    // METHOD: showDetailFlightDialog() (Diperbaiki koneksi dan variabel)
//    // ==========================================================
//    private void showDetailFlightDialog() {
//        String kode = txtKodeFlight.getText().trim();
//        if (kode.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Masukkan kode flight!");
//            return;
//        }
//
//        String sql = "SELECT FLIGHT_ID, HARGA, JUMLAH_KURSI, AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA "
//                    + "FROM FLIGHT WHERE FLIGHT_ID = ?";
//        
//        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
//             PreparedStatement pst = conn.prepareStatement(sql)) {
//             pst.setString(1, kode);
//             ResultSet rs = pst.executeQuery();
//             
//             if (rs.next()) {
//                 String detail = "Kode: " + rs.getString("FLIGHT_ID") + 
//                                 "\nMaskapai: " + rs.getString("AIRLINE") +
//                                 "\nRute: " + rs.getString("DEPARTURE") + " -> " + rs.getString("DESTINATION") +
//                                 "\nBerangkat: " + rs.getString("TANGGAL_BERANGKAT") + " " + rs.getString("WAKTU_BERANGKAT") +
//                                 "\nTiba: " + rs.getString("TANGGAL_TIBA") + " " + rs.getString("WAKTU_TIBA") +
//                                 "\nHarga: Rp " + String.format("%,.0f", rs.getDouble("HARGA")) +
//                                 "\nKursi Tersedia: " + rs.getInt("JUMLAH_KURSI");
//                 JOptionPane.showMessageDialog(this, detail, "Detail Flight", JOptionPane.INFORMATION_MESSAGE);
//             } else {
//                 JOptionPane.showMessageDialog(this, "Flight tidak ditemukan.");
//             }
//             
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error DB (showDetail): " + ex.getMessage());
//        }
//    }
//
//    // ==========================================================
//    // METHOD: konfirmasiPesanan() (LOGIKA UTAMA)
//    // Menggunakan Transaksi 3 Langkah: Cek Pembeli -> Insert Pembeli -> Insert Booking
//    // ==========================================================
//    private void konfirmasiPesanan() {
//        String noIdentitasInput = txtNoIdentitasPenumpang.getText().trim();
//        String nama = txtNamaPassenger.getText().trim();
//        String jumlahStr = txtJumlahTiket.getText().trim();
//        String totalStr = txtTotal.getText().trim();
//        String idPenggunaLogin = Session.getUserID();
//
//        // 1. Validasi Input dan Data Flight
//        if (noIdentitasInput.isEmpty() || nama.isEmpty() || kodeFlightTerpilih == null || jumlahStr.isEmpty() || totalStr.equals("-")) {
//            JOptionPane.showMessageDialog(this, "Semua data harus diisi, dan Flight harus dicari/dihitung.", "Validasi", JOptionPane.WARNING_MESSAGE);
//            return;
//        }
//
//        Connection conn = null;
//        try {
//            int jumlah = Integer.parseInt(jumlahStr);
//            double totalHarga = hargaPerTiket * jumlah;
//            String bookingId = "BKG" + System.currentTimeMillis(); 
//             
//            // Validasi kursi terakhir
//            if (jumlah > availableSeats) {
//                 JOptionPane.showMessageDialog(this, "Maaf, kursi hanya tersedia: " + availableSeats, "Validasi", JOptionPane.WARNING_MESSAGE);
//                 return;
//            }
//
//            // 2. Koneksi dan Mulai Transaksi
//            conn = DriverManager.getConnection(URL, USER, PASS);
//            conn.setAutoCommit(false); // Memulai transaksi
//            
//            // =======================================================
//            // LANGKAH A: CEK DAN INSERT PEMBELI BARU (Untuk mencegah ORA-02292)
//            // =======================================================
//            String checkSql = "SELECT COUNT(*) FROM PEMBELI WHERE NO_IDENTITAS = ?";
//            boolean pembeliExists;
//            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
//                checkStmt.setString(1, noIdentitasInput);
//                try (ResultSet rs = checkStmt.executeQuery()) {
//                    rs.next();
//                    pembeliExists = rs.getInt(1) > 0;
//                }
//            }
//
//            if (!pembeliExists) {
//                // Asumsi: Saat memesan tiket, Pembeli Baru harus terkait dengan ID_PENGGUNA yang sedang login.
//                // Kolom PEMBELI: NO_IDENTITAS, NAMA, ID_PENGGUNA. (Kolom lain bisa ditambahkan nanti)
//                String insertPembeliSql = "INSERT INTO PEMBELI (NO_IDENTITAS, NAMA, ID_PENGGUNA) VALUES (?, ?, ?)";
//                try (PreparedStatement insertPembeliStmt = conn.prepareStatement(insertPembeliSql)) {
//                    insertPembeliStmt.setString(1, noIdentitasInput);
//                    insertPembeliStmt.setString(2, nama);
//                    insertPembeliStmt.setString(3, idPenggunaLogin); // Penaut ke akun yang login
//                    insertPembeliStmt.executeUpdate();
//                }
//            } else {
//                // Opsional: Jika Pembeli sudah ada, kita bisa update namanya jika berbeda
//                String updateNamaSql = "UPDATE PEMBELI SET NAMA = ? WHERE NO_IDENTITAS = ?";
//                 try (PreparedStatement updateNamaStmt = conn.prepareStatement(updateNamaSql)) {
//                    updateNamaStmt.setString(1, nama);
//                    updateNamaStmt.setString(2, noIdentitasInput);
//                    updateNamaStmt.executeUpdate();
//                }
//            }
//
//            // =======================================================
//            // LANGKAH B: INSERT ke tabel BOOKING
//            // =======================================================
//            String insertBookingSql = "INSERT INTO BOOKING (BOOKING_ID, PASSENGER_IDENTITY, PASSENGER_NAME, FLIGHT_ID, TOTAL_PASSENGERS, TOTAL_PRICE, BOOKING_DATE) "
//                       + "VALUES (?, ?, ?, ?, ?, ?, SYSDATE)";
//             
//            try (PreparedStatement pst = conn.prepareStatement(insertBookingSql)) {
//                pst.setString(1, bookingId);
//                pst.setString(2, noIdentitasInput); 
//                pst.setString(3, nama);             
//                pst.setString(4, kodeFlightTerpilih); // DARI variabel class yang sudah dicari
//                pst.setInt(5, jumlah);
//                pst.setDouble(6, totalHarga);
//                pst.executeUpdate();
//            }
//
//            // =======================================================
//            // LANGKAH C: UPDATE jumlah kursi di tabel FLIGHT
//            // =======================================================
//            String updateFlightSql = "UPDATE FLIGHT SET JUMLAH_KURSI = JUMLAH_KURSI - ? WHERE FLIGHT_ID = ?";
//            try (PreparedStatement updateFlightStmt = conn.prepareStatement(updateFlightSql)) {
//                updateFlightStmt.setInt(1, jumlah);
//                updateFlightStmt.setString(2, kodeFlightTerpilih);
//                updateFlightStmt.executeUpdate();
//            }
//
//            conn.commit(); // Commit transaksi
//            availableSeats -= jumlah; // Update status kursi di GUI tanpa refresh
//            JOptionPane.showMessageDialog(this, "Booking berhasil!\nID Booking: " + bookingId, "Sukses", JOptionPane.INFORMATION_MESSAGE);
//
//            showCetakTiketDialog(bookingId, kodeFlightTerpilih, nama, noIdentitasInput, jumlah); 
//            clearForm();
//
//        } catch (NumberFormatException e) {
//            JOptionPane.showMessageDialog(this, "Jumlah tiket harus berupa angka.", "Error Input", JOptionPane.ERROR_MESSAGE);
//        } catch (SQLException ex) {
//            try {
//                if (conn != null) conn.rollback(); // Rollback jika ada error
//            } catch (SQLException rollbackEx) {}
//             
//            JOptionPane.showMessageDialog(this, 
//                "Gagal menyimpan booking (Error DB): " + ex.getMessage(), 
//                "SQL Error", JOptionPane.ERROR_MESSAGE);
//            ex.printStackTrace();
//        } finally {
//            try {
//                if (conn != null) conn.close();
//            } catch (SQLException closeEx) {}
//        }
//    }
//         
//    // ==========================================================
//    // METHOD: showCetakTiketDialog() (Diperbaiki variabel dinamis)
//    // ==========================================================
//    private void showCetakTiketDialog(String bookingId, String kodeFlight, String namaPenumpang,
//             String noIdentitas, int jumlahTiket) {
//            
//        String sql = "SELECT AIRLINE, DEPARTURE, DESTINATION, TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, HARGA " 
//                   + "FROM FLIGHT WHERE FLIGHT_ID = ?";
//        
//        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
//             PreparedStatement pst = conn.prepareStatement(sql)) {
//
//            pst.setString(1, kodeFlight);
//            ResultSet rs = pst.executeQuery();
//
//            if (rs.next()) {
//                double harga = rs.getDouble("HARGA");
//                double total = harga * jumlahTiket;
//                // ... [Tampilkan detail tiket] ...
//                
//                String detailTiket = "=== TIKET PENERBANGAN ELEKTRONIK ===\n"
//                                         + "===================================\n"
//                                         + "ID Booking   : " + bookingId + "\n"
//                                         + "No. Identitas: " + noIdentitas + "\n" 
//                                         + "Nama Penumpang: " + namaPenumpang + "\n"
//                                         + "Kode Flight  : " + kodeFlight + "\n"
//                                         + "Maskapai     : " + rs.getString("AIRLINE") + "\n"
//                                         + "Rute         : " + rs.getString("DEPARTURE") + " → " + rs.getString("DESTINATION") + "\n"
//                                         + "Waktu Berangkat: " + rs.getString("TANGGAL_BERANGKAT") + " " + rs.getString("WAKTU_BERANGKAT") + "\n"
//                                         + "Waktu Tiba   : " + rs.getString("TANGGAL_TIBA") + " " + rs.getString("WAKTU_TIBA") + "\n"
//                                         + "Jumlah Tiket : " + jumlahTiket + "\n"
//                                         + "Harga Total  : Rp " + String.format("%,.0f", total) + "\n";
//
//                JOptionPane.showMessageDialog(this, detailTiket, "Cetak Tiket Anda", JOptionPane.PLAIN_MESSAGE);
//                 
//            } 
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error DB (Cetak Tiket): " + ex.getMessage());
//        }
//    }
//         
//    // ==========================================================
//    // METHOD: clearForm() (Tambahan reset variabel class)
//    // ==========================================================
//    private void clearForm() {
//        txtNoIdentitasPenumpang.setText(""); 
//        txtNamaPassenger.setText("");
//        txtKodeFlight.setText("");
//        txtJumlahTiket.setText("");
//        txtTotal.setText("-");
//        
//        // Reset variabel class untuk memastikan harus cari flight lagi
//        hargaPerTiket = 0;
//        availableSeats = 0;
//        kodeFlightTerpilih = null;
//        tanggalBerangkatTerpilih = null;
//    }
//}
