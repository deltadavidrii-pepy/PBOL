package Projek_PBOL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class HapusDataFlight extends JFrame {
    private JTextField txtFlightId;
    private JButton btnCari, btnHapus, btnBack;
    private JTextArea txtDetail;

    public HapusDataFlight() {
        setTitle("Hapus Data Penerbangan");
        setSize(500, 400);
        setLocationRelativeTo(null);
        try {
            ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
            setIconImage(logo.getImage());
        } catch (Exception ex) {
            System.err.println("Error loading icon: " + ex.getMessage());
        }

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel input
        JPanel panelInput = new JPanel(new GridLayout(2, 2, 10, 10));
        panelInput.add(new JLabel("Flight ID:"));
        txtFlightId = new JTextField();
        panelInput.add(txtFlightId);

        btnCari = new JButton("Cari Flight");
        panelInput.add(btnCari);
        panelInput.add(new JLabel());

        add(panelInput, BorderLayout.NORTH);

        // Detail flight
        txtDetail = new JTextArea();
        txtDetail.setEditable(false);
        txtDetail.setBackground(Color.LIGHT_GRAY);
        txtDetail.setFont(new Font("Arial", Font.PLAIN, 12));
        add(new JScrollPane(txtDetail), BorderLayout.CENTER);

        JPanel panelButton = new JPanel();
        btnHapus = new JButton("Hapus Flight");
        btnHapus.setEnabled(false);
        btnBack = new JButton("Kembali");
        panelButton.add(btnHapus);
        panelButton.add(btnBack);
        add(panelButton, BorderLayout.SOUTH);

        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cariFlight();
            }
        });

        btnHapus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                hapusFlight();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private void cariFlight() {
        String flightId = txtFlightId.getText().trim();
        if (flightId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan Flight ID terlebih dahulu!");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            String sql = "SELECT * FROM FLIGHT WHERE FLIGHT_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, flightId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String detail = "=== DETAIL PENERBANGAN ===\n"
                        + "Flight ID: " + rs.getString("FLIGHT_ID") + "\n"
                        + "Maskapai: " + rs.getString("AIRLINE") + "\n"
                        + "Keberangkatan: " + rs.getString("DEPARTURE") + "\n"
                        + "Tujuan: " + rs.getString("DESTINATION") + "\n"
                        + "Tanggal Berangkat: " + rs.getString("TANGGAL_BERANGKAT") + "\n"
                        + "Waktu Berangkat: " + rs.getString("WAKTU_BERANGKAT") + "\n"
                        + "Tanggal Tiba: " + rs.getString("TANGGAL_TIBA") + "\n"
                        + "Waktu Tiba: " + rs.getString("WAKTU_TIBA") + "\n"
                        + "Harga: Rp " + String.format("%,.0f", rs.getDouble("HARGA")) + "\n"
                        + "Kursi Tersedia: " + rs.getInt("JUMLAH_KURSI");

                txtDetail.setText(detail);
                btnHapus.setEnabled(true);
            } else {
                txtDetail.setText("Flight dengan ID '" + flightId + "' tidak ditemukan!");
                btnHapus.setEnabled(false);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error Database: Pastikan Nama"
                    + " Kolom Sudah Benar! " + ex.getMessage());
        }
    }

    private void hapusFlight() {
        String flightId = txtFlightId.getText().trim();

        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            String checkSql = "SELECT COUNT(*) FROM BOOKING WHERE FLIGHT_ID = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, flightId);
            ResultSet rs = checkStmt.executeQuery();
            rs.next();
            int bookingCount = rs.getInt(1);

            if (bookingCount > 0) {
                JOptionPane.showMessageDialog(this,
                        "Tidak dapat menghapus flight!\n"
                        + "Masih ada " + bookingCount + " booking yang terkait dengan flight ini.\n"
                        + "Hapus booking terlebih dahulu.");

                rs.close();
                checkStmt.close();
                conn.close();
                return;
            }

            rs.close();
            checkStmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat memeriksa booking: " + ex.getMessage());
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Apakah Anda yakin ingin menghapus flight ini?\n"
                + "Flight ID: " + flightId + "\n"
                + "Tindakan ini tidak dapat dibatalkan!",
                "Konfirmasi Hapus",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                Connection conn = DriverManager.getConnection(
                        "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
                );

                String deleteSql = "DELETE FROM FLIGHT WHERE FLIGHT_ID = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                deleteStmt.setString(1, flightId);

                int result = deleteStmt.executeUpdate();

                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "Flight berhasil dihapus!");
                    txtDetail.setText("");
                    txtFlightId.setText("");
                    btnHapus.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal menghapus flight!");
                }

                deleteStmt.close();
                conn.close();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
            }
        }
    }
}

//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class HapusDataFlight extends JFrame {
//    private JTextField txtFlightId;
//    private JButton btnCari, btnHapus, btnBack;
//    private JTextArea txtDetail;
//    
//    public HapusDataFlight() {
//        setTitle("Hapus Data Penerbangan");
//        setSize(500, 400);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//        
//        // Panel input
//        JPanel panelInput = new JPanel(new GridLayout(2, 2, 10, 10));
//        panelInput.add(new JLabel("Flight ID:"));
//        txtFlightId = new JTextField();
//        panelInput.add(txtFlightId);
//        
//        btnCari = new JButton("Cari Flight");
//        panelInput.add(btnCari);
//        panelInput.add(new JLabel()); // spacer
//        
//        add(panelInput, BorderLayout.NORTH);
//        
//        // Detail flight
//        txtDetail = new JTextArea();
//        txtDetail.setEditable(false);
//        txtDetail.setBackground(Color.LIGHT_GRAY);
//        txtDetail.setFont(new Font("Arial", Font.PLAIN, 12));
//        add(new JScrollPane(txtDetail), BorderLayout.CENTER);
//        
//        // Panel button
//        JPanel panelButton = new JPanel();
//        btnHapus = new JButton("Hapus Flight");
//        btnHapus.setEnabled(false);
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnHapus);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Event handlers
//        btnCari.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                cariFlight();
//            }
//        });
//        
//        btnHapus.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                hapusFlight();
//            }
//        });
//        
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new AdminMenu();
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    private void cariFlight() {
//        String flightId = txtFlightId.getText().trim();
//        if (flightId.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Masukkan Flight ID terlebih dahulu!");
//            return;
//        }
//        
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            
//            String sql = "SELECT * FROM flight WHERE flight_id = ?";
//            PreparedStatement pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, flightId);
//            ResultSet rs = pstmt.executeQuery();
//            
//            if (rs.next()) {
//                String detail = "=== DETAIL PENERBANGAN ===\n" +
//                               "Flight ID: " + rs.getString("flight_id") + "\n" +
//                               "Maskapai: " + rs.getString("airline") + "\n" +
//                               "Keberangkatan: " + rs.getString("departure") + "\n" +
//                               "Tujuan: " + rs.getString("destination") + "\n" +
//                               "Waktu Berangkat: " + rs.getString("departure_time") + "\n" +
//                               "Waktu Tiba: " + rs.getString("arrival_time") + "\n" +
//                               "Harga: Rp " + String.format("%,.0f", rs.getDouble("price")) + "\n" +
//                               "Kursi Tersedia: " + rs.getInt("available_seats");
//                
//                txtDetail.setText(detail);
//                btnHapus.setEnabled(true);
//            } else {
//                txtDetail.setText("Flight dengan ID '" + flightId + "' tidak ditemukan!");
//                btnHapus.setEnabled(false);
//            }
//            
//            rs.close();
//            pstmt.close();
//            conn.close();
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
//        }
//    }
//    
//    private void hapusFlight() {
//        String flightId = txtFlightId.getText().trim();
//        
//        // Cek apakah ada booking yang terkait
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            
//            String checkSql = "SELECT COUNT(*) FROM booking WHERE flight_id = ?";
//            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
//            checkStmt.setString(1, flightId);
//            ResultSet rs = checkStmt.executeQuery();
//            rs.next();
//            int bookingCount = rs.getInt(1);
//            
//            if (bookingCount > 0) {
//                JOptionPane.showMessageDialog(this,
//                    "Tidak dapat menghapus flight!\n" +
//                    "Masih ada " + bookingCount + " booking yang terkait dengan flight ini.\n" +
//                    "Hapus booking terlebih dahulu.");
//                return;
//            }
//            
//            rs.close();
//            checkStmt.close();
//            conn.close();
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
//            return;
//        }
//        
//        int confirm = JOptionPane.showConfirmDialog(this,
//            "Apakah Anda yakin ingin menghapus flight ini?\n" +
//            "Flight ID: " + flightId + "\n" +
//            "Tindakan ini tidak dapat dibatalkan!",
//            "Konfirmasi Hapus",
//            JOptionPane.YES_NO_OPTION);
//        
//        if (confirm == JOptionPane.YES_OPTION) {
//            try {
//                Connection conn = DriverManager.getConnection(
//                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//                );
//                
//                String deleteSql = "DELETE FROM flight WHERE flight_id = ?";
//                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
//                deleteStmt.setString(1, flightId);
//                
//                int result = deleteStmt.executeUpdate();
//                
//                if (result > 0) {
//                    JOptionPane.showMessageDialog(this, "Flight berhasil dihapus!");
//                    txtDetail.setText("");
//                    txtFlightId.setText("");
//                    btnHapus.setEnabled(false);
//                } else {
//                    JOptionPane.showMessageDialog(this, "Gagal menghapus flight!");
//                }
//                
//                deleteStmt.close();
//                conn.close();
//                
//            } catch (SQLException ex) {
//                JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
//            }
//        }
//    }
//}
