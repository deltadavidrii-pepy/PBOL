package Projek_PBOL;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class LihatBookingAdmin extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnBack;
    private JButton btnRefresh;

    public LihatBookingAdmin() {

        setTitle("Lihat Semua Booking untuk Pembeli - Admin");
        setSize(1300, 500);
        setLocationRelativeTo(null);

        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] columnNames = {
            "Booking ID",
            "No Identitas",
            "Nama Penumpang",
            "Email Pembeli",
            "No Telepon",
            "Kode Flight",
            "Tujuan",
            "Tgl Berangkat",
            "Waktu Berangkat",
            "Tgl Tiba",
            "Waktu Tiba",
            "Jumlah Tiket",
            "Total Pembayaran",
            "Tanggal Booking"
        };
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelButton = new JPanel();
        btnRefresh = new JButton("Refresh Data");
        btnBack = new JButton("Kembali");
        panelButton.add(btnRefresh);
        panelButton.add(btnBack);
        add(panelButton, BorderLayout.SOUTH);

        loadBookingData();

        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadBookingData();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadBookingData() {

        tableModel.setRowCount(0);

        try ( Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {

            String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, P.EMAIL_PEMBELI,"
                    + " P.NO_TELP, B.FLIGHT_ID, "
                    + "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, "
                    + "F.DESTINATION, F.TANGGAL_BERANGKAT, F.WAKTU_BERANGKAT, F.TANGGAL_TIBA, F.WAKTU_TIBA "
                    + "FROM BOOKING B "
                    + "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID "
                    + "LEFT JOIN PEMBELI P ON B.PASSENGER_IDENTITY = P.NO_IDENTITAS "
                    + // <-- PERUBAHAN UTAMA DI SINI
                    "ORDER BY B.BOOKING_DATE DESC";

            try ( PreparedStatement pstmt = conn.prepareStatement(sql)) {

                try ( ResultSet rs = pstmt.executeQuery()) {

                    // Format Rupiah
                    DecimalFormatSymbols symbols = new DecimalFormatSymbols();
                    symbols.setGroupingSeparator('.');
                    symbols.setDecimalSeparator(',');
                    DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);

                    int rowCount = 0;
                    while (rs.next()) {
                        String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
                        String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
                        String tglTiba = rs.getString("TANGGAL_TIBA");
                        String waktuTiba = rs.getString("WAKTU_TIBA");

                        Object[] row = new Object[]{
                            rs.getString("BOOKING_ID"),
                            rs.getString("PASSENGER_IDENTITY"),
                            rs.getString("PASSENGER_NAME"),
                            rs.getString("EMAIL_PEMBELI"),
                            rs.getString("NO_TELP"),
                            rs.getString("FLIGHT_ID"),
                            rs.getString("DESTINATION"),
                            (tglBerangkat != null) ? tglBerangkat : "",
                            (waktuBerangkat != null) ? waktuBerangkat : "",
                            (tglTiba != null) ? tglTiba : "",
                            (waktuTiba != null) ? waktuTiba : "",
                            rs.getInt("TOTAL_PASSENGERS"),
                            formatter.format(rs.getDouble("TOTAL_PRICE")),
                            rs.getString("BOOKING_DATE")
                        };
                        tableModel.addRow(row);
                        rowCount++;
                    }
                    if (rowCount == 0) {
                        JOptionPane.showMessageDialog(this, "Tidak ada riwayat booking"
                                + " ditemukan.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
            e.printStackTrace();
        }
    }
}//package Projek_PBOL;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//import java.text.DecimalFormat;
//import java.text.DecimalFormatSymbols;
//
//public class LihatBookingAdmin extends JFrame {
//
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JButton btnBack;
//    private JButton btnRefresh;
//    
//    // Asumsi class AdminMenu ada di package Projek_PBOL
//    // import Projek_PBOL.AdminMenu; // Pastikan ini di-import jika perlu
//
//    public LihatBookingAdmin() {
//
//        setTitle("Lihat Semua Booking untuk Pembeli - Admin");
//        setSize(1300, 500); // Ukuran diperbesar untuk menampung kolom baru
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//        
//        // 1. DEFINISI KOLOM UNTUK ADMIN (Menampilkan semua detail)
//    // LihatBookingAdmin (Sekitar baris 33)
//String[] columnNames = {
//    "Booking ID",         // 1
//    "No Identitas",       // 2
//    "Nama Penumpang",     // 3
//    "Email Pembeli",  
//    "No Telepon",
//    "Kode Flight",        // 5
//    "Tujuan",             // 6
//    "Tgl Berangkat",      // 7
//    "Waktu Berangkat",    // 8
//    "Tgl Tiba",           // 9
//    "Waktu Tiba",         // 10
//    "Jumlah Tiket",       // 11
//    "Total Pembayaran",   // 12
//    "Tanggal Booking"     // 13
//};
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//        // Pengaturan lebar tabel
//        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); 
//
//        
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//        
//        // Tombol
//        JPanel panelButton = new JPanel();
//        btnRefresh = new JButton("Refresh Data");
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnRefresh);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Load data booking dari database
//        loadBookingData();
//        
//        btnRefresh.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                loadBookingData();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // Ganti dengan class Menu Admin yang benar
//                 new AdminMenu(); 
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    // =================================================================
//    // METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin)
//    // =================================================================
// // =================================================================
//// METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin) - KOREKSI FINAL
//// =================================================================
//private void loadBookingData() {
//    // Hapus semua baris data lama
//    tableModel.setRowCount(0);
//    
//    // HAPUS: Cek noIdentitasAktif (tidak diperlukan untuk Admin)
//    // HAPUS: String idPengguna = Session.getUserID();
//    // HAPUS: String noIdentitasAktif = getNoIdentitasDariDB(idPengguna);
//    // HAPUS: if (noIdentitasAktif == null) { ... }
//
//    try (Connection conn = DriverManager.getConnection(
//            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//        
//      // LihatBookingAdmin.loadBookingData() (Sekitar baris 108)
//// QUERY KOREKSI UNTUK ADMIN: Tambahkan kolom EMAIL_PEMBELI dan JOIN
//// LihatBookingAdmin.loadBookingData() (Sekitar baris 117-123)
//
//// Ganti kode query Anda menjadi:
//String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, P.EMAIL_PEMBELI, P.NO_TELP, B.FLIGHT_ID, " +
//             "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, " +
//             "F.DESTINATION, F.TANGGAL_BERANGKAT, F.WAKTU_BERANGKAT, F.TANGGAL_TIBA, F.WAKTU_TIBA " +
//             "FROM BOOKING B " +
//             "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID " +
//             "LEFT JOIN PEMBELI P ON B.PASSENGER_IDENTITY = P.NO_IDENTITAS " + // <-- PERUBAHAN UTAMA DI SINI
//             "ORDER BY B.BOOKING_DATE DESC";
//
//        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//            
//            // HAPUS: pstmt.setString(1, noIdentitasAktif); // Tidak ada parameter '?' lagi
//
//            try (ResultSet rs = pstmt.executeQuery()) {
//
//                // Format Rupiah
//                DecimalFormatSymbols symbols = new DecimalFormatSymbols();
//                symbols.setGroupingSeparator('.');
//                symbols.setDecimalSeparator(',');
//                DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);
//
//                // HAPUS: SimpleDateFormat tidak diperlukan karena kita mengambil string
//                // HAPUS: java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");
//                // HAPUS: java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm");
//
//                int rowCount = 0;
//                while (rs.next()) {
//                    // Ambil 4 kolom string terpisah dari hasil query
//                    String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
//                    String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
//                    String tglTiba = rs.getString("TANGGAL_TIBA");
//                    String waktuTiba = rs.getString("WAKTU_TIBA");
//                  
//                    
//                   // LihatBookingAdmin.loadBookingData() (Di dalam loop while)
//Object[] row = new Object[]{
//            // Index 0-3
//            rs.getString("BOOKING_ID"),
//            rs.getString("PASSENGER_IDENTITY"),
//            rs.getString("PASSENGER_NAME"),
//            rs.getString("EMAIL_PEMBELI"),
//            rs.getString("NO_TELP"),
//            rs.getString("FLIGHT_ID"),
//            rs.getString("DESTINATION"),
//            (tglBerangkat != null) ? tglBerangkat : "",
//            (waktuBerangkat != null) ? waktuBerangkat : "",
//            (tglTiba != null) ? tglTiba : "",
//            (waktuTiba != null) ? waktuTiba : "",
//            
//            // Index 10 (Jumlah Tiket)
//            rs.getInt("TOTAL_PASSENGERS"),
//            
//            // Index 11 (Total Pembayaran)
//            formatter.format(rs.getDouble("TOTAL_PRICE")),
//            
//            // Index 12 (Tanggal Booking)
//            rs.getString("BOOKING_DATE")
//        };
//        tableModel.addRow(row);
//                    rowCount++;
//                }
//                if (rowCount == 0) {
//                    JOptionPane.showMessageDialog(this, "Tidak ada riwayat booking ditemukan.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
//                }
//            }
//        }
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
//        e.printStackTrace();
//    }
//}
//}

//SALAH
//package Projek_PBOL;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//import java.text.DecimalFormat;
//import java.text.DecimalFormatSymbols;
//
//public class LihatBookingAdmin extends JFrame {
//
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JButton btnBack;
//    private JButton btnRefresh;
//    
//    // Asumsi class AdminMenu ada di package Projek_PBOL
//    // import Projek_PBOL.AdminMenu; // Pastikan ini di-import jika perlu
//
//    public LihatBookingAdmin() {
//
//        setTitle("Lihat Semua Booking untuk Pembeli - Admin");
//        setSize(1300, 500); // Ukuran diperbesar untuk menampung kolom baru
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//        
//        // 1. DEFINISI KOLOM UNTUK ADMIN (Menampilkan semua detail)
//    // LihatBookingAdmin (Sekitar baris 33)
//String[] columnNames = {
//    "Booking ID",         // 1
//    "No Identitas",       // 2
//    "Nama Penumpang",     // 3
//    "Email Pembeli",      // 4 <-- HARUS ADA DI URUTAN INI
//    "Kode Flight",        // 5
//    "Tujuan",             // 6
//    "Tgl Berangkat",      // 7
//    "Waktu Berangkat",    // 8
//    "Tgl Tiba",           // 9
//    "Waktu Tiba",         // 10
//    "Jumlah Tiket",       // 11
//    "Total Pembayaran",   // 12
//    "Tanggal Booking"     // 13
//};
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//        // Pengaturan lebar tabel
//        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); 
//
//        
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//        
//        // Tombol
//        JPanel panelButton = new JPanel();
//        btnRefresh = new JButton("Refresh Data");
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnRefresh);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Load data booking dari database
//        loadBookingData();
//        
//        btnRefresh.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                loadBookingData();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // Ganti dengan class Menu Admin yang benar
//                 new AdminMenu(); 
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    // =================================================================
//    // METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin)
//    // =================================================================
// // =================================================================
//// METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin) - KOREKSI FINAL
//// =================================================================
//private void loadBookingData() {
//    // Hapus semua baris data lama
//    tableModel.setRowCount(0);
//    
//    // HAPUS: Cek noIdentitasAktif (tidak diperlukan untuk Admin)
//    // HAPUS: String idPengguna = Session.getUserID();
//    // HAPUS: String noIdentitasAktif = getNoIdentitasDariDB(idPengguna);
//    // HAPUS: if (noIdentitasAktif == null) { ... }
//
//    try (Connection conn = DriverManager.getConnection(
//            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//        
//      // LihatBookingAdmin.loadBookingData() (Sekitar baris 108)
//// QUERY KOREKSI UNTUK ADMIN: Tambahkan kolom EMAIL_PEMBELI dan JOIN
//// LihatBookingAdmin.loadBookingData() (Sekitar baris 117-123)
//
//// Ganti kode query Anda menjadi:
//String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, P.EMAIL_PEMBELI, B.FLIGHT_ID, " +
//             "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, " +
//             "F.DESTINATION, F.TANGGAL_BERANGKAT, F.WAKTU_BERANGKAT, F.TANGGAL_TIBA, F.WAKTU_TIBA " +
//             "FROM BOOKING B " +
//             "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID " +
//             "LEFT JOIN PEMBELI P ON B.PASSENGER_IDENTITY = P.NO_IDENTITAS " + // <-- PERUBAHAN UTAMA DI SINI
//             "ORDER BY B.BOOKING_DATE DESC";
//
//        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//            
//            // HAPUS: pstmt.setString(1, noIdentitasAktif); // Tidak ada parameter '?' lagi
//
//            try (ResultSet rs = pstmt.executeQuery()) {
//
//                // Format Rupiah
//                DecimalFormatSymbols symbols = new DecimalFormatSymbols();
//                symbols.setGroupingSeparator('.');
//                symbols.setDecimalSeparator(',');
//                DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);
//
//                // HAPUS: SimpleDateFormat tidak diperlukan karena kita mengambil string
//                // HAPUS: java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");
//                // HAPUS: java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm");
//
//                int rowCount = 0;
//                while (rs.next()) {
//                    // Ambil 4 kolom string terpisah dari hasil query
//                    String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
//                    String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
//                    String tglTiba = rs.getString("TANGGAL_TIBA");
//                    String waktuTiba = rs.getString("WAKTU_TIBA");
//                  
//                    
//                   // LihatBookingAdmin.loadBookingData() (Di dalam loop while)
//Object[] row = new Object[]{
//            // Index 0-3
//            rs.getString("BOOKING_ID"),
//            rs.getString("PASSENGER_IDENTITY"),
//            rs.getString("PASSENGER_NAME"),
//            rs.getString("EMAIL_PEMBELI"), // <-- DATA EMAIL ADA DI SINI (Index 3)
//            
//            // Index 4-9
//            rs.getString("FLIGHT_ID"),
//            rs.getString("DESTINATION"),
//            (tglBerangkat != null) ? tglBerangkat : "",
//            (waktuBerangkat != null) ? waktuBerangkat : "",
//            (tglTiba != null) ? tglTiba : "",
//            (waktuTiba != null) ? waktuTiba : "",
//            
//            // Index 10 (Jumlah Tiket)
//            rs.getInt("TOTAL_PASSENGERS"),
//            
//            // Index 11 (Total Pembayaran)
//            formatter.format(rs.getDouble("TOTAL_PRICE")),
//            
//            // Index 12 (Tanggal Booking)
//            rs.getString("BOOKING_DATE")
//        };
//        tableModel.addRow(row);
//                    rowCount++;
//                }
//                if (rowCount == 0) {
//                    JOptionPane.showMessageDialog(this, "Tidak ada riwayat booking ditemukan.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
//                }
//            }
//        }
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
//        e.printStackTrace();
//    }
//}
//}
//TIDAK PERLU
//package Projek_PBOL;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//import java.text.DecimalFormat;
//import java.text.DecimalFormatSymbols;
//
//public class LihatBookingAdmin extends JFrame {
//
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JButton btnBack;
//    private JButton btnRefresh;
//    
//    // Asumsi class AdminMenu ada di package Projek_PBOL
//    // import Projek_PBOL.AdminMenu; // Pastikan ini di-import jika perlu
//
//    public LihatBookingAdmin() {
//
//        setTitle("Lihat Semua Booking untuk Pembeli - Admin");
//        setSize(1300, 500); // Ukuran diperbesar untuk menampung kolom baru
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//        
//        // 1. DEFINISI KOLOM UNTUK ADMIN (Menampilkan semua detail)
//      String[] columnNames = {
//            "Booking ID", 
//            "No Identitas", 
//            "Nama Penumpang", 
//            "Kode Flight", 
//            "Tujuan", 
//            "Tgl Berangkat", 
//            "Waktu Berangkat", 
//            "Tgl Tiba", 
//            "Waktu Tiba", 
//            "Jumlah Tiket", 
//            "Total Pembayaran",
//            "Tanggal Booking" 
//        }; 
//        
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//        // Pengaturan lebar tabel
//        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); 
//
//        
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//        
//        // Tombol
//        JPanel panelButton = new JPanel();
//        btnRefresh = new JButton("Refresh Data");
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnRefresh);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//        
//        // Load data booking dari database
//        loadBookingData();
//        
//        btnRefresh.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                loadBookingData();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // Ganti dengan class Menu Admin yang benar
//                 new AdminMenu(); 
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    // =================================================================
//    // METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin)
//    // =================================================================
// // =================================================================
//// METHOD UNTUK MEMUAT DATA BOOKING (LihatBookingAdmin) - KOREKSI FINAL
//// =================================================================
//private void loadBookingData() {
//    // Hapus semua baris data lama
//    tableModel.setRowCount(0);
//    
//    // HAPUS: Cek noIdentitasAktif (tidak diperlukan untuk Admin)
//    // HAPUS: String idPengguna = Session.getUserID();
//    // HAPUS: String noIdentitasAktif = getNoIdentitasDariDB(idPengguna);
//    // HAPUS: if (noIdentitasAktif == null) { ... }
//
//    try (Connection conn = DriverManager.getConnection(
//            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406")) {
//        
//        // QUERY KOREKSI UNTUK ADMIN: Menghapus klausa WHERE
//        String sql = "SELECT B.BOOKING_ID, B.PASSENGER_IDENTITY, B.PASSENGER_NAME, B.FLIGHT_ID, " +
//                    "B.TOTAL_PASSENGERS, B.TOTAL_PRICE, B.BOOKING_DATE, " +
//                    "F.DESTINATION, " +
//                    "F.TANGGAL_BERANGKAT, " +  // Kolom Tgl Berangkat
//                    "F.WAKTU_BERANGKAT, " +    // Kolom Waktu Berangkat
//                    "F.TANGGAL_TIBA, " +      // Kolom Tgl Tiba
//                    "F.WAKTU_TIBA " +         // Kolom Waktu Tiba
//                    "FROM BOOKING B " +
//                    "JOIN FLIGHT F ON B.FLIGHT_ID = F.FLIGHT_ID " +
//                    "ORDER BY B.BOOKING_DATE DESC";
//
//        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//            
//            // HAPUS: pstmt.setString(1, noIdentitasAktif); // Tidak ada parameter '?' lagi
//
//            try (ResultSet rs = pstmt.executeQuery()) {
//
//                // Format Rupiah
//                DecimalFormatSymbols symbols = new DecimalFormatSymbols();
//                symbols.setGroupingSeparator('.');
//                symbols.setDecimalSeparator(',');
//                DecimalFormat formatter = new DecimalFormat("Rp #,###.00", symbols);
//
//                // HAPUS: SimpleDateFormat tidak diperlukan karena kita mengambil string
//                // HAPUS: java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");
//                // HAPUS: java.text.SimpleDateFormat timeFormat = new java.text.SimpleDateFormat("HH:mm");
//
//                int rowCount = 0;
//                while (rs.next()) {
//                    // Ambil 4 kolom string terpisah dari hasil query
//                    String tglBerangkat = rs.getString("TANGGAL_BERANGKAT");
//                    String waktuBerangkat = rs.getString("WAKTU_BERANGKAT");
//                    String tglTiba = rs.getString("TANGGAL_TIBA");
//                    String waktuTiba = rs.getString("WAKTU_TIBA");
//                    
//                    // Memasukkan 12 data (harus urut sesuai columnNames)
//                    Object[] row = new Object[]{
//                        rs.getString("BOOKING_ID"),
//                        rs.getString("PASSENGER_IDENTITY"), 
//                        rs.getString("PASSENGER_NAME"),
//                        rs.getString("FLIGHT_ID"),
//                        rs.getString("DESTINATION"),
//                        (tglBerangkat != null) ? tglBerangkat : "", 
//                        (waktuBerangkat != null) ? waktuBerangkat : "",
//                        (tglTiba != null) ? tglTiba : "",
//                        (waktuTiba != null) ? waktuTiba : "",
//                        rs.getInt("TOTAL_PASSENGERS"),
//                        formatter.format(rs.getDouble("TOTAL_PRICE")),
//                        rs.getString("BOOKING_DATE")
//                    };
//                    tableModel.addRow(row);
//                    rowCount++;
//                }
//                if (rowCount == 0) {
//                    JOptionPane.showMessageDialog(this, "Tidak ada riwayat booking ditemukan.", "Info Booking", JOptionPane.INFORMATION_MESSAGE);
//                }
//            }
//        }
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(this, "Error memuat data booking: " + e.getMessage());
//        e.printStackTrace();
//    }
//}
//}
