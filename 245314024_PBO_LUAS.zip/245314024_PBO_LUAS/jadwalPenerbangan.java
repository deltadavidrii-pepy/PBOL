package Projek_PBOL.images.projec_PBOL.pengguna;

import Projek_PBOL.Travelokaa;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class jadwalPenerbangan extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtAsal, txtTujuan, txtTanggal;
    private JButton btnCari, btnBack;

    public jadwalPenerbangan() {
        setTitle("Lihat Jadwal Penerbangan- Pembeli");
        setSize(1000, 500);
        setLocationRelativeTo(null);
        
        ImageIcon logo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);
        Container contentPane = this.getContentPane();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color skyBlue = new Color(135, 206, 250);
        contentPane.setBackground(skyBlue);
        setLayout(new BorderLayout(10, 10));
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.setBackground(skyBlue);
        add(inputPanel, BorderLayout.CENTER);
        JPanel panelSearch = new JPanel(new GridLayout(1, 4, 10, 10));
        panelSearch.add(new JLabel("Asal:"));
        txtAsal = new JTextField();
        panelSearch.add(txtAsal);

        panelSearch.add(new JLabel("Tujuan:"));
        txtTujuan = new JTextField();
        panelSearch.add(txtTujuan);

        panelSearch.add(new JLabel("Tanggal keberangkatan (YYYY-MM-DD):"));
        txtTanggal = new JTextField();
        panelSearch.add(txtTanggal);

        btnCari = new JButton("Cari");
        panelSearch.add(btnCari);

        add(panelSearch, BorderLayout.NORTH);

        String[] columnNames = {
            "Kode Flight", "Maskapai", "Asal", "Tujuan",
            "Tanggal Berangkat", "Waktu Berangkat",
            "Tanggal Tiba", "Waktu Tiba",
            "Harga", "Kursi Tersedia"
        };
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Panel button
        JPanel panelButton = new JPanel();
        btnBack = new JButton("Kembali ke menu");
        panelButton.add(btnBack);
        add(panelButton, BorderLayout.SOUTH);
        loadFlightData("", "", "");

        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String asal = txtAsal.getText().trim();
                String tujuan = txtTujuan.getText().trim();
                String tanggal = txtTanggal.getText().trim();
                loadFlightData(asal, tujuan, tanggal);
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // new MenuAwalPembeliGUI(); 
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadFlightData(String asal, String tujuan, String tanggal) {
        tableModel.setRowCount(0);
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            StringBuilder sql = new StringBuilder(
                    "SELECT FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, "
                    + "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, "
                    + "HARGA, JUMLAH_KURSI "
                    + "FROM FLIGHT WHERE 1=1 AND JUMLAH_KURSI > 0"
            );
            if (!asal.isEmpty()) {
                sql.append(" AND UPPER(DEPARTURE) LIKE UPPER('%").append(asal).append("%')");
            }
            if (!tujuan.isEmpty()) {
                sql.append(" AND UPPER(DESTINATION) LIKE UPPER('%").append(tujuan).append("%')");
            }
            if (!tanggal.isEmpty()) {
                sql.append(" AND TANGGAL_BERANGKAT = '").append(tanggal).append("'");
            }

            sql.append(" ORDER BY TANGGAL_BERANGKAT, WAKTU_BERANGKAT");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql.toString());

            int rowCount = 0;
            while (rs.next()) {
                int kursiKosong = rs.getInt("JUMLAH_KURSI");
                String statusKursi;

                if (kursiKosong > 10) {
                    statusKursi = kursiKosong + " kursi tersedia";
                } else if (kursiKosong > 0) {
                    statusKursi = "Hanya " + kursiKosong + " kursi tersisa";
                } else {
                    statusKursi = "Penuh";
                }

                Object[] rowData = {
                    rs.getString("FLIGHT_ID"),
                    rs.getString("AIRLINE"),
                    rs.getString("DEPARTURE"),
                    rs.getString("DESTINATION"),
                    rs.getString("TANGGAL_BERANGKAT"),
                    rs.getString("WAKTU_BERANGKAT"),
                    rs.getString("TANGGAL_TIBA"),
                    rs.getString("WAKTU_TIBA"),
                    String.format("Rp %,.0f", rs.getDouble("HARGA")),
                    statusKursi
                };
                tableModel.addRow(rowData);
                rowCount++;
            }

            if (rowCount == 0) {
                JOptionPane.showMessageDialog(this,
                        "Tidak ada data penerbangan yang ditemukan dengan kriteria tersebut.",
                        "Info",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}

//package Projek_PBOL.images.projec_PBOL.pengguna;
//
//import Projek_PBOL.Travelokaa;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class jadwalPenerbangan extends JFrame {
//
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JTextField txtAsal, txtTujuan, txtTanggal;
//    private JButton btnCari, btnBack;
//
//    public jadwalPenerbangan() {
//        setTitle("Lihat Jadwal Penerbangan- Pembeli");
//        setSize(1000, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        // Panel pencarian
//        JPanel panelSearch = new JPanel(new GridLayout(1, 4, 10, 10));
//        panelSearch.add(new JLabel("Asal:"));
//        txtAsal = new JTextField();
//        panelSearch.add(txtAsal);
//
//        panelSearch.add(new JLabel("Tujuan:"));
//        txtTujuan = new JTextField();
//        panelSearch.add(txtTujuan);
//
//        panelSearch.add(new JLabel("Tanggal keberangkatan (YYYY-MM-DD):"));
//        txtTanggal = new JTextField();
//        panelSearch.add(txtTanggal);
//
//        btnCari = new JButton("Cari");
//        panelSearch.add(btnCari);
//
//        add(panelSearch, BorderLayout.NORTH);
//
//        String[] columnNames = {
//            "Kode Flight", "Maskapai", "Asal", "Tujuan", 
//            "Tanggal Berangkat", "Waktu Berangkat", 
//            "Tanggal Tiba", "Waktu Tiba", 
//            "Harga", "Kursi Tersedia" // Label ini tetap sama di GUI
//        };
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//
//        // Panel button
//        JPanel panelButton = new JPanel();
//        btnBack = new JButton("Kembali ke menu");
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//
//        // Load data awal
//        loadFlightData("", "", "");
//
//        // Event handlers
//        btnCari.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                String asal = txtAsal.getText().trim();
//                String tujuan = txtTujuan.getText().trim();
//                String tanggal = txtTanggal.getText().trim();
//                loadFlightData(asal, tujuan, tanggal);
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // new MenuAwalPembeliGUI(); 
//                dispose();
//            }
//        });
//
//        setVisible(true);
//    }
//
//    private void loadFlightData(String asal, String tujuan, String tanggal) {
//        tableModel.setRowCount(0); // Selalu bersihkan data lama
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//
//           StringBuilder sql = new StringBuilder(
//    "SELECT FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, " + 
//    "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, " + 
//    "HARGA, JUMLAH_KURSI " + // Hapus 'AVAILABLESEATS' / 'AVAILABLE_SEATS'
//    "FROM FLIGHT WHERE 1=1 AND JUMLAH_KURSI > 0" // Hapus 'AVAILABLESEATS'
//);
//
//            // Klausa WHERE sudah benar karena menggunakan DEPARTURE, DESTINATION
//            if (!asal.isEmpty()) {
//                sql.append(" AND UPPER(DEPARTURE) LIKE UPPER('%").append(asal).append("%')");
//            }
//            if (!tujuan.isEmpty()) {
//                sql.append(" AND UPPER(DESTINATION) LIKE UPPER('%").append(tujuan).append("%')");
//            }
//            if (!tanggal.isEmpty()) {
//                sql.append(" AND TANGGAL_BERANGKAT = '").append(tanggal).append("'");
//            }
//
//            sql.append(" ORDER BY TANGGAL_BERANGKAT, WAKTU_BERANGKAT");
//
//            // --- EKSEKUSI QUERY ---
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(sql.toString());
//
//            int rowCount = 0;
//            while (rs.next()) {
//                // Pengambilan data di sini sudah benar, karena menggunakan nama kolom yang sudah dikoreksi di query SELECT
//                int kursiKosong = rs.getInt("JUMLAH_KURSI"); 
//                String statusKursi;
//
//                if (kursiKosong > 10) {
//                    statusKursi = kursiKosong + " kursi tersedia";
//                } else if (kursiKosong > 0) {
//                    statusKursi = "Hanya " + kursiKosong + " kursi tersisa";
//                } else {
//                    statusKursi = "Penuh";
//                }
//
//                Object[] rowData = {
//                    rs.getString("FLIGHT_ID"),
//                    rs.getString("AIRLINE"),
//                    rs.getString("DEPARTURE"),
//                    rs.getString("DESTINATION"),
//                    rs.getString("TANGGAL_BERANGKAT"),
//                    rs.getString("WAKTU_BERANGKAT"),
//                    rs.getString("TANGGAL_TIBA"),
//                    rs.getString("WAKTU_TIBA"),
//                    String.format("Rp %,.0f", rs.getDouble("HARGA")),
//                    statusKursi 
//                };
//                tableModel.addRow(rowData);
//                rowCount++;
//            }
//            
//            if (rowCount == 0) {
//                JOptionPane.showMessageDialog(this, 
//                    "Tidak ada data penerbangan yang ditemukan dengan kriteria tersebut.", 
//                    "Info", 
//                    JOptionPane.INFORMATION_MESSAGE);
//            }
//            
//            rs.close();
//            stmt.close();
//            conn.close();
//
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
//            ex.printStackTrace();
//        }
//    }
//}
