package Projek_PBOL;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class AdminMenu extends JFrame {
    JMenuItem JMInput, JMBooking, JMDataFlight, JMUbdateBooking, JMUpdateDataFLIGHT,
            JMHapusBooking, JMHapDataFligh, JMBack;
   JTextArea area;

    public AdminMenu() {
        
        
        setTitle("MENU ADMIN TRAVELOKA");
        setSize(700, 500);
        setLocationRelativeTo(null);

setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(10, 1, 10, 10));
        
        
 // GAMBAR UNTUK FRAME ICONNYA APLIKASI
        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        // gambar menjadi bagian di GUI
        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
         ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        
        JMenuBar menuBar = new JMenuBar();
        JMenu menuData = new JMenu("MENU ADMIN");
       
        JMInput = new JMenuItem("Input Data Flight");
        JMDataFlight = new JMenuItem("lihat semua Data  penerbangan ");
        JMBooking = new JMenuItem("Lihat Semua Booking- Admin");
       
        JMUbdateBooking = new JMenuItem("ubdate booking flight ");
        JMUpdateDataFLIGHT = new JMenuItem("ubdate data flight ");
        JMHapusBooking = new JMenuItem("Hapus Booking ");
        JMHapDataFligh = new JMenuItem("Hapus Data flight  ");
        JMBack = new JMenuItem(" Kembali ke Menu Utama");
 
        menuData.add(JMInput);            
        menuData.add(JMDataFlight);       
        menuData.add(JMBooking);          
        menuData.add(JMUbdateBooking);

        menuData.add(JMUpdateDataFLIGHT); 
        menuData.add(JMHapusBooking);     
        menuData.add(JMHapDataFligh);     
        menuData.add(JMBack);
        
        menuBar.add(menuData);
        setJMenuBar(menuBar);
        
        area = new JTextArea();
        area.setText("Program Traveloka siap.\n klik menu di atas untuk menjalankan perintah.");
        add(new JScrollPane(area), BorderLayout.CENTER);
        setVisible(true);
        // 1. input flight
        JMInput.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new FormInputFlight();
                dispose();
            }
        });
        // 2. liat inputan data flight/ penerbangan
        JMDataFlight.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new DataFlightAdminn();
                dispose();
            }
        });

        //  3. input liat bookingan dari pembeli (MENGUBAH DATA PESANAN)
        JMBooking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LihatBookingAdmin();
                dispose();
            }
        });
        // 5. inputan untuk ubdate/ubah data pesanan/ booking
        JMUbdateBooking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new UbdateDataBooking();
                dispose();
            }
        });
        // 6. inputan untuk ubdate/ubah data penerbangan/flight ( MENGUBAH INFORMAI PENERBANGAN)
        JMUpdateDataFLIGHT.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new UbdateDataFlight();
                dispose();
            }
        });
        //7. inputan untuk hapus data bookingan ( hapus data pesanan tiket dari penumpang)
        JMHapusBooking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HapusBooking();
                dispose();
            }
        });

        //8. inputan untuk hapus data bookingan (menghapus jadwal penerbangan dari sistem)
        JMHapDataFligh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HapusDataFlight();
                dispose();
            }
        });

        // untuk back
        JMBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Travelokaa();
                dispose();
            }
        });

        setVisible(true);
    }
}//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//public class AdminMenu extends JFrame {
//    JMenuItem JMInput, JMBooking, JMDataFlight, JMUbdateBooking, JMUpdateDataFLIGHT,
//            JMHapusBooking, JMHapDataFligh, JMBack;
//   JTextArea area;
//
//    public AdminMenu() {
//        
//        
//        setTitle("MENU ADMIN TRAVELOKA");
//        setSize(700, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new GridLayout(10, 1, 10, 10));
//
//        
//        JMenuBar menuBar = new JMenuBar();
//        JMenu menuData = new JMenu("MENU ADMIN");
//       
//        JMInput = new JMenuItem("Input Data Flight");
//        JMDataFlight = new JMenuItem("lihat semua Data  penerbangan ");
//        JMBooking = new JMenuItem("Lihat Semua Booking- Admin");
//       
//        JMUbdateBooking = new JMenuItem("ubdate booking flight ");
//        JMUpdateDataFLIGHT = new JMenuItem("ubdate data flight ");
//        JMHapusBooking = new JMenuItem("Hapus Booking ");
//        JMHapDataFligh = new JMenuItem("Hapus Data flight  ");
//        JMBack = new JMenuItem(" Kembali ke Menu Utama");
// 
//        menuData.add(JMInput);            
//        menuData.add(JMDataFlight);       
//        menuData.add(JMBooking);          
//        menuData.add(JMUbdateBooking);
//
//        menuData.add(JMUpdateDataFLIGHT); 
//        menuData.add(JMHapusBooking);     
//        menuData.add(JMHapDataFligh);     
//        menuData.add(JMBack);
//        
//        menuBar.add(menuData);
//        setJMenuBar(menuBar);
//        
//        area = new JTextArea();
//        area.setText("Program Traveloka siap.\n klik menu di atas untuk menjalankan perintah.");
//        add(new JScrollPane(area), BorderLayout.CENTER);
//        setVisible(true);
//        // 1. input flight
//        JMInput.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new FormInputFlight();
//                dispose();
//            }
//        });
//        // 2. liat inputan data flight/ penerbangan
//        JMDataFlight.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new DataFlightAdminn();
//                dispose();
//            }
//        });
//
//        //  3. input liat bookingan dari pembeli (MENGUBAH DATA PESANAN)
//        JMBooking.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new LihatBookingAdmin();
//                dispose();
//            }
//        });
//        // 5. inputan untuk ubdate/ubah data pesanan/ booking
//        JMUbdateBooking.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new UbdateDataBooking();
//                dispose();
//            }
//        });
//        // 6. inputan untuk ubdate/ubah data penerbangan/flight ( MENGUBAH INFORMAI PENERBANGAN)
//        JMUpdateDataFLIGHT.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new UbdateDataFlight();
//                dispose();
//            }
//        });
//        //7. inputan untuk hapus data bookingan ( hapus data pesanan tiket dari penumpang)
//        JMHapusBooking.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new HapusBooking();
//                dispose();
//            }
//        });
//
//        //8. inputan untuk hapus data bookingan (menghapus jadwal penerbangan dari sistem)
//        JMHapDataFligh.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new HapusDataFlight();
//                dispose();
//            }
//        });
//
//        // untuk back
//        JMBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new Travelokaa();
//                dispose();
//            }
//        });
//
//        setVisible(true);
//    }
//}
