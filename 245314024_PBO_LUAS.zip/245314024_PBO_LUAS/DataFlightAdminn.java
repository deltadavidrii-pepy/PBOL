package Projek_PBOL;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DataFlightAdminn extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnRefresh, btnBack;

    public DataFlightAdminn() {
        setTitle("Jadwal Semua Penerbangan - Admin");
        setSize(1000, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // GAMBAR UNTUK FRAME ICONNYA APLIKASI
        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        // gambar menjadi bagian di GUI
        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        // Title
        JLabel lblTitle = new JLabel("DATA SEMUA PENERBANGAN", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        add(lblTitle, BorderLayout.NORTH);

        // Table model
        String[] columnNames = {
            "Flight ID", "Maskapai", "Keberangkatan", "Tujuan",
            "Tanggal Berangkat", "Waktu Berangkat",
            "Tanggal Tiba", "Waktu Tiba",
            "Harga", "Kursi Tersedia"
        };
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Panel button
        JPanel panelButton = new JPanel();
        btnRefresh = new JButton("Refresh Data");
        btnBack = new JButton("Kembali");
        panelButton.add(btnRefresh);
        panelButton.add(btnBack);
        add(panelButton, BorderLayout.SOUTH);

        loadFlightData();

        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadFlightData();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadFlightData() {
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );
            String sql = "SELECT FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, "
                    + "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, "
                    + "HARGA, JUMLAH_KURSI "
                    + "FROM flight ORDER BY FLIGHT_ID";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            tableModel.setRowCount(0);

            while (rs.next()) {
                Object[] rowData = {
                    rs.getString("FLIGHT_ID"),
                    rs.getString("AIRLINE"),
                    rs.getString("DEPARTURE"),
                    rs.getString("DESTINATION"),
                    rs.getString("TANGGAL_BERANGKAT"),
                    rs.getString("WAKTU_BERANGKAT"),
                    rs.getString("TANGGAL_TIBA"),
                    rs.getString("WAKTU_TIBA"),
                    "Rp " + rs.getString("HARGA"),
                    rs.getString("JUMLAH_KURSI")
                };
                tableModel.addRow(rowData);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat memuat data: " + ex.getMessage());
        }
    }

}

//package Projek_PBOL;
//
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class DataFlightAdminn extends JFrame {
//
//    private JTable table;
//    private DefaultTableModel tableModel;
//    private JButton btnRefresh, btnBack;
//
//    public DataFlightAdminn() {
//        setTitle("Jadwal Semua Penerbangan - Admin");
//        setSize(1000, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        // Title
//        JLabel lblTitle = new JLabel("DATA SEMUA PENERBANGAN", JLabel.CENTER);
//        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
//        add(lblTitle, BorderLayout.NORTH);
//
//        // Table model
//        String[] columnNames = {
//            "Flight ID", "Maskapai", "Keberangkatan", "Tujuan",
//            "Tanggal Berangkat", "Waktu Berangkat",
//            "Tanggal Tiba", "Waktu Tiba",
//            "Harga", "Kursi Tersedia"
//        };
//        tableModel = new DefaultTableModel(columnNames, 0);
//        table = new JTable(tableModel);
//
//        JScrollPane scrollPane = new JScrollPane(table);
//        add(scrollPane, BorderLayout.CENTER);
//
//        // Panel button
//        JPanel panelButton = new JPanel();
//        btnRefresh = new JButton("Refresh Data");
//        btnBack = new JButton("Kembali");
//        panelButton.add(btnRefresh);
//        panelButton.add(btnBack);
//        add(panelButton, BorderLayout.SOUTH);
//
//        // Load data
//        loadFlightData();
//
//        // Event handlers
//        btnRefresh.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                loadFlightData();
//            }
//        });
//
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                // Asumsi class AdminMenu ada dan bisa dipanggil
//                new AdminMenu(); 
//                dispose();
//            }
//        });
//
//        setVisible(true);
//    }
//
//    private void loadFlightData() {
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//   String sql = "SELECT FLIGHT_ID, AIRLINE, DEPARTURE, DESTINATION, " +
//             "TANGGAL_BERANGKAT, WAKTU_BERANGKAT, TANGGAL_TIBA, WAKTU_TIBA, " +
//             "HARGA, JUMLAH_KURSI " + 
//             "FROM flight ORDER BY FLIGHT_ID";
//            
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(sql); // executeQuery() digunakan untuk SELECT
//            
//            tableModel.setRowCount(0);
//            
//            while (rs.next()) {
//                Object[] rowData = {
//                    // KOREKSI: rs.getString() menggunakan nama kolom KAPITAL yang benar
//                    rs.getString("FLIGHT_ID"),
//                    rs.getString("AIRLINE"),
//                    rs.getString("DEPARTURE"), 
//                    rs.getString("DESTINATION"),
//                    rs.getString("TANGGAL_BERANGKAT"),
//                    rs.getString("WAKTU_BERANGKAT"),
//                    rs.getString("TANGGAL_TIBA"),
//                    rs.getString("WAKTU_TIBA"),
//                    "Rp " + rs.getString("HARGA"),  // <-- Menggunakan HARGA
//                    rs.getString("JUMLAH_KURSI")    // <-- Menggunakan JUMLAH_KURSI
//                };
//                tableModel.addRow(rowData);
//            }
//            
//            rs.close();
//            stmt.close();
//            conn.close();
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error saat memuat data: " + ex.getMessage());
//        }
//    }
//    
//   
//}
//
//    private void loadFlightData() {
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            
//            String sql = "SELECT flight_id, airline, departure, destination, " +
//                        "TO_CHAR(departure_time, 'YYYY-MM-DD') as tgl_berangkat, " +
//                        "TO_CHAR(departure_time, 'HH24:MI') as waktu_berangkat, " +
//                        "TO_CHAR(arrival_time, 'HH24:MI') as waktu_tiba, " +
//                        "price, available_seats " +
//                        "FROM flight ORDER BY departure_time";
//            
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(sql);
//            
//            tableModel.setRowCount(0); // Clear existing data
//            
//            while (rs.next()) {
//                Object[] rowData = {
//                    rs.getString("flight_id"),
//                    rs.getString("airline"),
//                    rs.getString("departure"),
//                    rs.getString("destination"),
//                    rs.getString("tgl_berangkat"),
//                    rs.getString("waktu_berangkat"),
//                    rs.getString("waktu_tiba"),
//                    String.format("Rp %,.0f", rs.getDouble("price")),
//                    rs.getInt("available_seats")
//                };
//                tableModel.addRow(rowData);
//            }
//            
//            rs.close();
//            stmt.close();
//            conn.close();
//            
//            JOptionPane.showMessageDialog(this, "Data berhasil dimuat!");
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
//        }
//    }

