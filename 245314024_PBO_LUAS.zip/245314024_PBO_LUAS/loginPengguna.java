package Projek_PBOL.images.projec_PBOL.pengguna;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class loginPengguna extends JFrame {

    JTextField txtEmail, txtNoTelp, txtID, txtNama;
    JPasswordField txtPass;
    JButton btnAksi1, btnAksi2;
    JLabel lblTitle, lblID, lblNama;
    
    boolean isLoginMode = true; // true = login mode, false = registrasi mode

    public loginPengguna() {
        setTitle("LOGIN PENGGUNA");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        ImageIcon logo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
        ImageIcon logologo = new ImageIcon(getClass().getResource("tiket.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);
        Container contentPane = this.getContentPane();
   
   
        
        // 2. Tentukan Warna Biru Muda (Bisa disesuaikan dengan nilai RGB dari gambar)
        // RGB (173, 216, 230) adalah warna Light Blue/Biru Muda
        Color lightBlue = new Color(173, 216, 230); // Atau gunakan nilai Color dari gambar yang lebih akurat
        
        // Asumsi warna dari gambar yang Anda berikan mirip dengan (135, 206, 250) (Sky Blue)
        // Kita akan pakai warna yang mirip dengan warna di gambar: RGB (135, 206, 250)
        Color skyBlue = new Color(135, 206, 250); 
        
        // 3. Atur Warna Background pada Content Pane
        contentPane.setBackground(skyBlue);

        setLayout(new GridLayout(7, 2, 10, 10));

        // Title
        lblTitle = new JLabel("LOGIN PENGGUNA", JLabel.CENTER);
        add(lblTitle);
        add(new JLabel("")); // placeholder

        // Field untuk registrasi (disembunyikan di mode login)
        lblID = new JLabel("ID:");
        add(lblID);
        txtID = new JTextField();
        add(txtID);

        lblNama = new JLabel("Nama:");
        add(lblNama);
        txtNama = new JTextField();
        add(txtNama);

        // Field untuk login & registrasi
        add(new JLabel("Email:"));
        txtEmail = new JTextField();
        add(txtEmail);

        add(new JLabel("No Telepon:"));
        txtNoTelp = new JTextField();
        add(txtNoTelp);

        add(new JLabel("Password:"));
        txtPass = new JPasswordField();
        add(txtPass);

        // Tombol aksi
        btnAksi1 = new JButton("Login");
        btnAksi2 = new JButton("Daftar");

        add(btnAksi1);
        add(btnAksi2);

        // Set mode awal (login)
        setLoginMode();

        btnAksi1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (isLoginMode) {
                    loginUser();
                } else {
                    daftarUser();
                }
            }
        });

        btnAksi2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (isLoginMode) {
                    setRegistrasiMode();
                } else {
                    setLoginMode();
                }
            }
        });

        setVisible(true);
    }

    // SET MODE LOGIN
    private void setLoginMode() {
        isLoginMode = true;
        setTitle("LOGIN");
        lblTitle.setText("PENGGUNA");
        
        // Sembunyikan field registrasi
        lblID.setVisible(false);
        txtID.setVisible(false);
        lblNama.setVisible(false);
        txtNama.setVisible(false);
        
        // Set tombol
        btnAksi1.setText("Login");
        btnAksi2.setText("Daftar");
        
        clearFields();
    }

    // SET MODE REGISTRASI
    private void setRegistrasiMode() {
        isLoginMode = false;
        setTitle("DAFTAR AKUN PENGGUNA");
        lblTitle.setText("DAFTAR AKUN PENGGUNA");
        
        // Tampilkan field registrasi
        lblID.setVisible(true);
        txtID.setVisible(true);
        lblNama.setVisible(true);
        txtNama.setVisible(true);
        
        // Set tombol
        btnAksi1.setText("Daftar");
        btnAksi2.setText("Kembali");
        
        clearFields();
    }

    // PROSES LOGIN
    private void loginUser() {
        String email = txtEmail.getText().trim();
        String noTelp = txtNoTelp.getText().trim();
        String pass = String.valueOf(txtPass.getPassword()).trim();

        if (email.isEmpty() || noTelp.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email, No Telepon dan Password wajib diisi!");
            return;
        }

        if (!noTelp.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "No Telepon harus berupa angka!");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

            // Di loginUser()
String sql = "SELECT * FROM PENGGUNA WHERE (\"EMAIL\" = ? OR \"NO_TELEPON\" = ?) AND \"PASSWORD\" = ?";
PreparedStatement pst = conn.prepareStatement(sql);
pst.setString(1, email);
pst.setString(2, noTelp);
pst.setString(3, pass);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

    // ======== SIMPAN SESSION DI SINI ========
    String idPengguna = rs.getString("ID");
    Session.setUserID(idPengguna);
    // =========================================

    JOptionPane.showMessageDialog(this, "Login berhasil!");
    new MenuAwalPembeliGUI();
    dispose();

} else {
    JOptionPane.showMessageDialog(this, "Email/No Telepon atau Password salah!");
}


            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }

   // PROSES REGISTRASI - DENGAN PENCEGAHAN DUPLIKAT
private void daftarUser() {
    String id = txtID.getText().trim();
    String nama = txtNama.getText().trim();
    String email = txtEmail.getText().trim();
    String noTelp = txtNoTelp.getText().trim();
    String password = String.valueOf(txtPass.getPassword()).trim();

    if (id.isEmpty() || nama.isEmpty() || email.isEmpty() || noTelp.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!");
        return;
    }

    if (!noTelp.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "No Telepon harus berupa angka!");
        return;
    }

    // CEK APAKAH DATA SUDAH ADA DI DATABASE
    if (isDataSudahAda(id, email, noTelp)) {
        JOptionPane.showMessageDialog(this, 
            "DATA SUDAH TERDAFTAR!\n\n" +
            "ID/Email/No Telepon tidak bisa digunakan lagi.\n" +
            "Silakan gunakan data yang berbeda.");
        return;
    }

    // JIKA DATA BELUM ADA, SIMPAN KE DATABASE
    try {
        Connection conn = DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
        );

        // KOREKSI UTAMA: Mengganti "NAMA" menjadi "NAME" dan MENGHILANGKAN TANDA KUTIP GANDA
        String insertSql = "INSERT INTO PENGGUNA (ID, NAME, EMAIL, NO_TELEPON, PASSWORD) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(insertSql);

        pst.setString(1, id);
        pst.setString(2, nama); // Nama (dari JTextField) dipetakan ke kolom NAME (di DB)
        pst.setString(3, email);
        pst.setString(4, noTelp);
        pst.setString(5, password);

        int rowsAffected = pst.executeUpdate();
        
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, 
                " DAFTAR AKUN TELAH BERHASIL!\n\n" +
                "Data Anda telah disimpan.\n" +
                "ID/Email/No Telepon tidak bisa didaftarkan lagi.");
            // setLoginMode(); // Uncomment jika Anda punya method ini
        } else {
            JOptionPane.showMessageDialog(this, "daftar aku gagal!");
        }

        conn.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        ex.printStackTrace(); // Tambahkan ini untuk melihat detail error di konsol
    }
}
    // METHOD UNTUK CEK DUPLIKAT DATA
    private boolean isDataSudahAda(String id, String email, String noTelp) {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );
// Di isDataSudahAda()
String sql = "SELECT * FROM PENGGUNA WHERE \"ID\" = ? OR \"EMAIL\" = ? OR \"NO_TELEPON\" = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.setString(2, email);
            pst.setString(3, noTelp);

            ResultSet rs = pst.executeQuery();
            boolean sudahAda = rs.next();
            
            conn.close();
            return sudahAda;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error cek data: " + ex.getMessage());
            return true; // Untuk safety
        }
    }

    // CLEAR FIELDS
    private void clearFields() {
        txtID.setText("");
        txtNama.setText("");
        txtEmail.setText("");
        txtNoTelp.setText("");
        txtPass.setText("");
    }
}



//package Projek_PBOL.images.projec_PBOL.pengguna;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class loginPengguna extends JFrame {
//
//    JTextField txtEmail, txtNoTelp, txtID, txtNama;
//    JPasswordField txtPass;
//    JButton btnAksi1, btnAksi2;
//    JLabel lblTitle, lblID, lblNama;
//    
//    boolean isLoginMode = true; // true = login mode, false = registrasi mode
//
//    public loginPengguna() {
//        setTitle("LOGIN PENGGUNA");
//        setSize(400, 300);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//        setLayout(new GridLayout(7, 2, 10, 10));
//
//        // Title
//        lblTitle = new JLabel("LOGIN PENGGUNA", JLabel.CENTER);
//        add(lblTitle);
//        add(new JLabel("")); // placeholder
//
//        // Field untuk registrasi (disembunyikan di mode login)
//        lblID = new JLabel("ID:");
//        add(lblID);
//        txtID = new JTextField();
//        add(txtID);
//
//        lblNama = new JLabel("Nama:");
//        add(lblNama);
//        txtNama = new JTextField();
//        add(txtNama);
//
//        // Field untuk login & registrasi
//        add(new JLabel("Email:"));
//        txtEmail = new JTextField();
//        add(txtEmail);
//
//        add(new JLabel("No Telepon:"));
//        txtNoTelp = new JTextField();
//        add(txtNoTelp);
//
//        add(new JLabel("Password:"));
//        txtPass = new JPasswordField();
//        add(txtPass);
//
//        // Tombol aksi
//        btnAksi1 = new JButton("Login");
//        btnAksi2 = new JButton("Daftar");
//
//        add(btnAksi1);
//        add(btnAksi2);
//
//        // Set mode awal (login)
//        setLoginMode();
//
//        btnAksi1.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                if (isLoginMode) {
//                    loginUser();
//                } else {
//                    daftarUser();
//                }
//            }
//        });
//
//        btnAksi2.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                if (isLoginMode) {
//                    setRegistrasiMode();
//                } else {
//                    setLoginMode();
//                }
//            }
//        });
//
//        setVisible(true);
//    }
//
//    // SET MODE LOGIN
//    private void setLoginMode() {
//        isLoginMode = true;
//        setTitle("LOGIN PENGGUNA");
//        lblTitle.setText("LOGIN PENGGUNA");
//        
//        // Sembunyikan field registrasi
//        lblID.setVisible(false);
//        txtID.setVisible(false);
//        lblNama.setVisible(false);
//        txtNama.setVisible(false);
//        
//        // Set tombol
//        btnAksi1.setText("Login");
//        btnAksi2.setText("Daftar");
//        
//        clearFields();
//    }
//
//    // SET MODE REGISTRASI
//    private void setRegistrasiMode() {
//        isLoginMode = false;
//        setTitle("DAFTAR AKUN PENGGUNA");
//        lblTitle.setText("DAFTAR AKUN PENGGUNA");
//        
//        // Tampilkan field registrasi
//        lblID.setVisible(true);
//        txtID.setVisible(true);
//        lblNama.setVisible(true);
//        txtNama.setVisible(true);
//        
//        // Set tombol
//        btnAksi1.setText("Daftar");
//        btnAksi2.setText("Kembali");
//        
//        clearFields();
//    }
//
//    // PROSES LOGIN
//    private void loginUser() {
//        String email = txtEmail.getText().trim();
//        String noTelp = txtNoTelp.getText().trim();
//        String pass = String.valueOf(txtPass.getPassword()).trim();
//
//        if (email.isEmpty() || noTelp.isEmpty() || pass.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Email, No Telepon dan Password wajib diisi!");
//            return;
//        }
//
//        if (!noTelp.matches("\\d+")) {
//            JOptionPane.showMessageDialog(this, "No Telepon harus berupa angka!");
//            return;
//        }
//
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//
//            // Di loginUser()
//String sql = "SELECT * FROM PENGGUNA WHERE (\"EMAIL\" = ? OR \"NO_TELEPON\" = ?) AND \"PASSWORD\" = ?";
//PreparedStatement pst = conn.prepareStatement(sql);
//pst.setString(1, email);
//pst.setString(2, noTelp);
//pst.setString(3, pass);
//
//            ResultSet rs = pst.executeQuery();
//
//            if (rs.next()) {
//
//    // ======== SIMPAN SESSION DI SINI ========
//    String idPengguna = rs.getString("ID");
//    Session.setUserID(idPengguna);
//    // =========================================
//
//    JOptionPane.showMessageDialog(this, "Login berhasil!");
//    new MenuAwalPembeliGUI();
//    dispose();
//
//} else {
//    JOptionPane.showMessageDialog(this, "Email/No Telepon atau Password salah!");
//}
//
//
//            conn.close();
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
//        }
//    }
//
//   // PROSES REGISTRASI - DENGAN PENCEGAHAN DUPLIKAT
//private void daftarUser() {
//    String id = txtID.getText().trim();
//    String nama = txtNama.getText().trim();
//    String email = txtEmail.getText().trim();
//    String noTelp = txtNoTelp.getText().trim();
//    String password = String.valueOf(txtPass.getPassword()).trim();
//
//    if (id.isEmpty() || nama.isEmpty() || email.isEmpty() || noTelp.isEmpty() || password.isEmpty()) {
//        JOptionPane.showMessageDialog(this, "Semua kolom harus diisi!");
//        return;
//    }
//
//    if (!noTelp.matches("\\d+")) {
//        JOptionPane.showMessageDialog(this, "No Telepon harus berupa angka!");
//        return;
//    }
//
//    // CEK APAKAH DATA SUDAH ADA DI DATABASE
//    if (isDataSudahAda(id, email, noTelp)) {
//        JOptionPane.showMessageDialog(this, 
//            "DATA SUDAH TERDAFTAR!\n\n" +
//            "ID/Email/No Telepon tidak bisa digunakan lagi.\n" +
//            "Silakan gunakan data yang berbeda.");
//        return;
//    }
//
//    // JIKA DATA BELUM ADA, SIMPAN KE DATABASE
//    try {
//        Connection conn = DriverManager.getConnection(
//            "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//        );
//
//        // KOREKSI UTAMA: Mengganti "NAMA" menjadi "NAME" dan MENGHILANGKAN TANDA KUTIP GANDA
//        String insertSql = "INSERT INTO PENGGUNA (ID, NAME, EMAIL, NO_TELEPON, PASSWORD) VALUES (?, ?, ?, ?, ?)";
//        PreparedStatement pst = conn.prepareStatement(insertSql);
//
//        pst.setString(1, id);
//        pst.setString(2, nama); // Nama (dari JTextField) dipetakan ke kolom NAME (di DB)
//        pst.setString(3, email);
//        pst.setString(4, noTelp);
//        pst.setString(5, password);
//
//        int rowsAffected = pst.executeUpdate();
//        
//        if (rowsAffected > 0) {
//            JOptionPane.showMessageDialog(this, 
//                " DAFTAR AKUN TELAH BERHASIL!\n\n" +
//                "Data Anda telah disimpan.\n" +
//                "ID/Email/No Telepon tidak bisa didaftarkan lagi.");
//            // setLoginMode(); // Uncomment jika Anda punya method ini
//        } else {
//            JOptionPane.showMessageDialog(this, "daftar aku gagal!");
//        }
//
//        conn.close();
//    } catch (SQLException ex) {
//        JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
//        ex.printStackTrace(); // Tambahkan ini untuk melihat detail error di konsol
//    }
//}
//    // METHOD UNTUK CEK DUPLIKAT DATA
//    private boolean isDataSudahAda(String id, String email, String noTelp) {
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//// Di isDataSudahAda()
//String sql = "SELECT * FROM PENGGUNA WHERE \"ID\" = ? OR \"EMAIL\" = ? OR \"NO_TELEPON\" = ?";
//            PreparedStatement pst = conn.prepareStatement(sql);
//            pst.setString(1, id);
//            pst.setString(2, email);
//            pst.setString(3, noTelp);
//
//            ResultSet rs = pst.executeQuery();
//            boolean sudahAda = rs.next();
//            
//            conn.close();
//            return sudahAda;
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error cek data: " + ex.getMessage());
//            return true; // Untuk safety
//        }
//    }
//
//    // CLEAR FIELDS
//    private void clearFields() {
//        txtID.setText("");
//        txtNama.setText("");
//        txtEmail.setText("");
//        txtNoTelp.setText("");
//        txtPass.setText("");
//    }
//}