package Projek_PBOL;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UbdateDataFlight extends JFrame {
    private JTextField txtFlightId, txtAirline, txtDeparture, txtDestination,
            txtTanggalBerangkat, txtWaktuBerangkat, 
            txtTanggalTiba, txtWaktuTiba, txtPrice, txtSeats;
    private JButton btnCari, btnUpdate, btnBack;
    
    public UbdateDataFlight() {
        setTitle("Update Data Penerbangan");
        setSize(500, 500);
        setLocationRelativeTo(null);
        
        ImageIcon logo = new ImageIcon(getClass().getResource("orang.jpeg"));
        setIconImage(logo.getImage());

        JPanel panelCenter = new JPanel(new BorderLayout(10, 10));
         ImageIcon logologo = new ImageIcon(getClass().getResource("orang.jpeg"));
        JLabel labelGambar = new JLabel(logo);
        labelGambar.setHorizontalAlignment(JLabel.CENTER);
        panelCenter.add(labelGambar, BorderLayout.CENTER);

        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(12, 2, 10, 10)); 
        
        Container contentPane = this.getContentPane();
        
        Color lightBlue = new Color(173, 216, 230); 
        Color skyBlue = new Color(135, 206, 250); 
        
        contentPane.setBackground(skyBlue);
        
        add(new JLabel("Flight ID:"));
        JPanel panelFlightId = new JPanel(new BorderLayout());
        txtFlightId = new JTextField();
        btnCari = new JButton("Cari");
        panelFlightId.add(txtFlightId, BorderLayout.CENTER);
        panelFlightId.add(btnCari, BorderLayout.EAST);
        add(panelFlightId);
        
        add(new JLabel("Maskapai:"));
        txtAirline = new JTextField();
        add(txtAirline);
        
        add(new JLabel("Keberangkatan:"));
        txtDeparture = new JTextField();
        add(txtDeparture);
        
        add(new JLabel("Tujuan:"));
        txtDestination = new JTextField();
        add(txtDestination);
        
        // Tanggal & Waktu Berangkat
        add(new JLabel("Tanggal Berangkat (YYYY-MM-DD):"));
        txtTanggalBerangkat = new JTextField();
        add(txtTanggalBerangkat);
        
        add(new JLabel("Waktu Berangkat (HH:MI):"));
        txtWaktuBerangkat = new JTextField();
        add(txtWaktuBerangkat);
        
        // Tanggal & Waktu Tiba  
        add(new JLabel("Tanggal Tiba (YYYY-MM-DD):"));
        txtTanggalTiba = new JTextField();
        add(txtTanggalTiba);
        
        add(new JLabel("Waktu Tiba (HH:MI):"));
        txtWaktuTiba = new JTextField();
        add(txtWaktuTiba);
        
        add(new JLabel("Harga:"));
        txtPrice = new JTextField();
        add(txtPrice);
        
        add(new JLabel("Kapasitas Penumpang:"));
        txtSeats = new JTextField();
        add(txtSeats);
        
        btnUpdate = new JButton("Update Data");
        btnUpdate.setEnabled(false);
        btnBack = new JButton("Kembali");
        
        add(btnUpdate);
        add(btnBack);
        
        // Event handlers
        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cariFlight();
            }
        });
        
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateFlight();
            }
        });
        
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu();
                dispose();
            }
        });
        
        setVisible(true);
    }
    
    private void cariFlight() {
        String flightId = txtFlightId.getText().trim();
        if (flightId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan Flight ID terlebih dahulu!");
            return;
        }
        
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );
            
          String sql = "SELECT * FROM FLIGHT WHERE FLIGHT_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, flightId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                txtAirline.setText(rs.getString("AIRLINE"));
    txtDeparture.setText(rs.getString("DEPARTURE")); 
    txtDestination.setText(rs.getString("DESTINATION"));
                
              txtTanggalBerangkat.setText(rs.getString("TANGGAL_BERANGKAT"));
    txtWaktuBerangkat.setText(rs.getString("WAKTU_BERANGKAT"));
    txtTanggalTiba.setText(rs.getString("TANGGAL_TIBA"));
    txtWaktuTiba.setText(rs.getString("WAKTU_TIBA"));
                
               txtPrice.setText(String.valueOf(rs.getDouble("HARGA"))); 
    txtSeats.setText(String.valueOf(rs.getInt("JUMLAH_KURSI")));
                
                btnUpdate.setEnabled(true);
                JOptionPane.showMessageDialog(this, "Data flight ditemukan!");
            } else {
                JOptionPane.showMessageDialog(this, "Flight dengan ID '" + flightId + "' tidak ditemukan!");
                clearFields();
                btnUpdate.setEnabled(false);
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void updateFlight() {
        try {
            String flightId = txtFlightId.getText();
            String airline = txtAirline.getText();
            String departure = txtDeparture.getText();
            String destination = txtDestination.getText();
            String tanggalBerangkat = txtTanggalBerangkat.getText();
            String waktuBerangkat = txtWaktuBerangkat.getText();
            String tanggalTiba = txtTanggalTiba.getText();
            String waktuTiba = txtWaktuTiba.getText();

            // Handle harga dengan format yang fleksibel
            String hargaInput = txtPrice.getText().replace(".", "").replace(",", ".");
            double price = Double.parseDouble(hargaInput);
            int seats = Integer.parseInt(txtSeats.getText());

            // Validasi semua field
            if (flightId.isEmpty() || airline.isEmpty() || departure.isEmpty()
                    || destination.isEmpty() || tanggalBerangkat.isEmpty() || waktuBerangkat.isEmpty()
                    || tanggalTiba.isEmpty() || waktuTiba.isEmpty() || txtPrice.getText().isEmpty()
                    || txtSeats.getText().isEmpty()) {

                JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
                return;
            }

            //  format tanggal (YYYY-MM-DD)
            if (!tanggalBerangkat.matches("\\d{4}-\\d{2}-\\d{2}") || !tanggalTiba.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Format tanggal harus YYYY-MM-DD (contoh: 2024-01-15)");
                return;
            }

            //  format waktu (HH:MI)
            if (!waktuBerangkat.matches("\\d{2}:\\d{2}") || !waktuTiba.matches("\\d{2}:\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Format waktu harus HH:MI (contoh: 14:30)");
                return;
            }

            Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
            );

String sql = "UPDATE FLIGHT SET AIRLINE = ?, DEPARTURE = ?, DESTINATION = ?, " +
             "TANGGAL_BERANGKAT = ?, WAKTU_BERANGKAT = ?, " +
             "TANGGAL_TIBA = ?, WAKTU_TIBA = ?, " +
             "HARGA = ?, JUMLAH_KURSI = ? " +
             "WHERE FLIGHT_ID = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, airline);
            pstmt.setString(2, departure);
            pstmt.setString(3, destination);
            pstmt.setString(4, tanggalBerangkat);
            pstmt.setString(5, waktuBerangkat);
            pstmt.setString(6, tanggalTiba);
            pstmt.setString(7, waktuTiba);
            pstmt.setDouble(8, price);
            pstmt.setInt(9, seats);
            pstmt.setString(10, flightId);

            int result = pstmt.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Data penerbangan berhasil diupdate!");
                clearFields();
                btnUpdate.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "Gagal mengupdate data penerbangan!");
            }

            pstmt.close();
            conn.close();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Harga dan jumlah kursi harus berupa angka!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    private void clearFields() {
        txtAirline.setText("");
        txtDeparture.setText("");
        txtDestination.setText("");
        txtTanggalBerangkat.setText("");
        txtWaktuBerangkat.setText("");
        txtTanggalTiba.setText("");
        txtWaktuTiba.setText("");
        txtPrice.setText("");
        txtSeats.setText("");
    }
}
//package Projek_PBOL;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//
//public class UbdateDataFlight extends JFrame {
//    private JTextField txtFlightId, txtAirline, txtDeparture, txtDestination,
//            txtTanggalBerangkat, txtWaktuBerangkat, 
//            txtTanggalTiba, txtWaktuTiba, txtPrice, txtSeats;
//    private JButton btnCari, btnUpdate, btnBack;
//    
//    public UbdateDataFlight() {
//        setTitle("Update Data Penerbangan");
//        setSize(500, 500);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new GridLayout(12, 2, 10, 10)); // Row disesuaikan
//        
//        // Komponen form
//        add(new JLabel("Flight ID:"));
//        JPanel panelFlightId = new JPanel(new BorderLayout());
//        txtFlightId = new JTextField();
//        btnCari = new JButton("Cari");
//        panelFlightId.add(txtFlightId, BorderLayout.CENTER);
//        panelFlightId.add(btnCari, BorderLayout.EAST);
//        add(panelFlightId);
//        
//        add(new JLabel("Maskapai:"));
//        txtAirline = new JTextField();
//        add(txtAirline);
//        
//        add(new JLabel("Keberangkatan:"));
//        txtDeparture = new JTextField();
//        add(txtDeparture);
//        
//        add(new JLabel("Tujuan:"));
//        txtDestination = new JTextField();
//        add(txtDestination);
//        
//        // Tanggal & Waktu Berangkat
//        add(new JLabel("Tanggal Berangkat (YYYY-MM-DD):"));
//        txtTanggalBerangkat = new JTextField();
//        add(txtTanggalBerangkat);
//        
//        add(new JLabel("Waktu Berangkat (HH:MI):"));
//        txtWaktuBerangkat = new JTextField();
//        add(txtWaktuBerangkat);
//        
//        // Tanggal & Waktu Tiba  
//        add(new JLabel("Tanggal Tiba (YYYY-MM-DD):"));
//        txtTanggalTiba = new JTextField();
//        add(txtTanggalTiba);
//        
//        add(new JLabel("Waktu Tiba (HH:MI):"));
//        txtWaktuTiba = new JTextField();
//        add(txtWaktuTiba);
//        
//        add(new JLabel("Harga:"));
//        txtPrice = new JTextField();
//        add(txtPrice);
//        
//        add(new JLabel("Kapasitas Penumpang:"));
//        txtSeats = new JTextField();
//        add(txtSeats);
//        
//        btnUpdate = new JButton("Update Data");
//        btnUpdate.setEnabled(false);
//        btnBack = new JButton("Kembali");
//        
//        add(btnUpdate);
//        add(btnBack);
//        
//        // Event handlers
//        btnCari.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                cariFlight();
//            }
//        });
//        
//        btnUpdate.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                updateFlight();
//            }
//        });
//        
//        btnBack.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                new AdminMenu();
//                dispose();
//            }
//        });
//        
//        setVisible(true);
//    }
//    
//    private void cariFlight() {
//        String flightId = txtFlightId.getText().trim();
//        if (flightId.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Masukkan Flight ID terlebih dahulu!");
//            return;
//        }
//        
//        try {
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//            
//          String sql = "SELECT * FROM FLIGHT WHERE FLIGHT_ID = ?";
//            PreparedStatement pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, flightId);
//            ResultSet rs = pstmt.executeQuery();
//            
//            if (rs.next()) {
//                txtAirline.setText(rs.getString("AIRLINE")); // Ganti airline -> AIRLINE
//    txtDeparture.setText(rs.getString("DEPARTURE")); // Ganti departure -> DEPARTURE
//    txtDestination.setText(rs.getString("DESTINATION"));
//                
//              txtTanggalBerangkat.setText(rs.getString("TANGGAL_BERANGKAT"));
//    txtWaktuBerangkat.setText(rs.getString("WAKTU_BERANGKAT"));
//    txtTanggalTiba.setText(rs.getString("TANGGAL_TIBA"));
//    txtWaktuTiba.setText(rs.getString("WAKTU_TIBA"));
//                
//               txtPrice.setText(String.valueOf(rs.getDouble("HARGA"))); 
//    // Ganti available_seats -> JUMLAH_KURSI
//    txtSeats.setText(String.valueOf(rs.getInt("JUMLAH_KURSI")));
//                
//                btnUpdate.setEnabled(true);
//                JOptionPane.showMessageDialog(this, "Data flight ditemukan!");
//            } else {
//                JOptionPane.showMessageDialog(this, "Flight dengan ID '" + flightId + "' tidak ditemukan!");
//                clearFields();
//                btnUpdate.setEnabled(false);
//            }
//            
//            rs.close();
//            pstmt.close();
//            conn.close();
//            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
//            ex.printStackTrace();
//        }
//    }
//    
//    private void updateFlight() {
//        try {
//            String flightId = txtFlightId.getText();
//            String airline = txtAirline.getText();
//            String departure = txtDeparture.getText();
//            String destination = txtDestination.getText();
//            String tanggalBerangkat = txtTanggalBerangkat.getText();
//            String waktuBerangkat = txtWaktuBerangkat.getText();
//            String tanggalTiba = txtTanggalTiba.getText();
//            String waktuTiba = txtWaktuTiba.getText();
//
//            // Handle harga dengan format yang fleksibel
//            String hargaInput = txtPrice.getText().replace(".", "").replace(",", ".");
//            double price = Double.parseDouble(hargaInput);
//            int seats = Integer.parseInt(txtSeats.getText());
//
//            // Validasi semua field
//            if (flightId.isEmpty() || airline.isEmpty() || departure.isEmpty()
//                    || destination.isEmpty() || tanggalBerangkat.isEmpty() || waktuBerangkat.isEmpty()
//                    || tanggalTiba.isEmpty() || waktuTiba.isEmpty() || txtPrice.getText().isEmpty()
//                    || txtSeats.getText().isEmpty()) {
//
//                JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
//                return;
//            }
//
//            // Validasi format tanggal (YYYY-MM-DD)
//            if (!tanggalBerangkat.matches("\\d{4}-\\d{2}-\\d{2}") || !tanggalTiba.matches("\\d{4}-\\d{2}-\\d{2}")) {
//                JOptionPane.showMessageDialog(this, "Format tanggal harus YYYY-MM-DD (contoh: 2024-01-15)");
//                return;
//            }
//
//            // Validasi format waktu (HH:MI)
//            if (!waktuBerangkat.matches("\\d{2}:\\d{2}") || !waktuTiba.matches("\\d{2}:\\d{2}")) {
//                JOptionPane.showMessageDialog(this, "Format waktu harus HH:MI (contoh: 14:30)");
//                return;
//            }
//
//            // Update ke database - SESUAIKAN DENGAN STRUKTUR TABEL ANDA
//            Connection conn = DriverManager.getConnection(
//                "jdbc:oracle:thin:@localhost:1521:XE", "Delvitri", "180406"
//            );
//
//           // Baris 204: Ganti nama kolom SQL sesuai uppercase
//String sql = "UPDATE FLIGHT SET AIRLINE = ?, DEPARTURE = ?, DESTINATION = ?, " +
//             "TANGGAL_BERANGKAT = ?, WAKTU_BERANGKAT = ?, " +
//             "TANGGAL_TIBA = ?, WAKTU_TIBA = ?, " +
//             "HARGA = ?, JUMLAH_KURSI = ? " + // Ganti price & available_seats
//             "WHERE FLIGHT_ID = ?";
//            
//            PreparedStatement pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, airline);
//            pstmt.setString(2, departure);
//            pstmt.setString(3, destination);
//            pstmt.setString(4, tanggalBerangkat);
//            pstmt.setString(5, waktuBerangkat);
//            pstmt.setString(6, tanggalTiba);
//            pstmt.setString(7, waktuTiba);
//            pstmt.setDouble(8, price);
//            pstmt.setInt(9, seats);
//            pstmt.setString(10, flightId);
//
//            int result = pstmt.executeUpdate();
//
//            if (result > 0) {
//                JOptionPane.showMessageDialog(this, "Data penerbangan berhasil diupdate!");
//                clearFields();
//                btnUpdate.setEnabled(false);
//            } else {
//                JOptionPane.showMessageDialog(this, "Gagal mengupdate data penerbangan!");
//            }
//
//            pstmt.close();
//            conn.close();
//
//        } catch (NumberFormatException ex) {
//            JOptionPane.showMessageDialog(this, "Harga dan jumlah kursi harus berupa angka!");
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error database: " + ex.getMessage());
//            ex.printStackTrace();
//        }
//    }
//    
//    // Method untuk membersihkan field
//    private void clearFields() {
//        txtAirline.setText("");
//        txtDeparture.setText("");
//        txtDestination.setText("");
//        txtTanggalBerangkat.setText("");
//        txtWaktuBerangkat.setText("");
//        txtTanggalTiba.setText("");
//        txtWaktuTiba.setText("");
//        txtPrice.setText("");
//        txtSeats.setText("");
//    }
//}
